## install packages ###
from Bio import SeqIO
import sys
import os

## arguments ###

    # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 6:
    sys.exit("ERROR : need 5 arguments : [1]exon name [2]fasta file which contains sequences in AA [3]fasta file which contains sequences in NT [4]name of the out fasta file which will contains the sequences without those with a stop codon [5]name of csv file which will contain the names of sequences with stop codon")
    # recuperer les arguments
exon_name = sys.argv[1] #nom de l'exon
in_seq_AA = sys.argv[2] #séquence de l'exon en acide aminé 
in_seq_NT = sys.argv[3] #séquence en nuclotides
out_folder = sys.argv[4] #séquence de sorties
csv_out_file = sys.argv[5] 

base_name = os.path.splitext(os.path.basename(in_seq_NT))[0]  # Enlève l'extension
out_seq = os.path.join(out_folder, f"{base_name}.fasta")



## script ###

#1# list of seq with stop codon
list_seq_stop = [] ###on crée une liste vide en premier lieu qui contiendra le nom des exons ayant un codon STOP
with open(csv_out_file, 'w') as out: # open csv file to write results
    ### ouvre le fichier csv en moe écriture 
    for seq_read in SeqIO.parse(in_seq_AA, 'fasta'): # for each seq read seq
        #la boucle parcout les séquences AA et si on a un codon stop, elle met le nom de l'exon dans la liste
        #et enregistre le nom de l'exon et l'espèce dans le csv 
        if seq_read.seq.count('*') > 0: # if there is at least one stop codon in the seq
            sp = seq_read.id # get the seq name (=name of the specie)
            list_seq_stop.append(sp) # and add it to the list of seq with stop codons
            out.write(f'{in_seq_NT}\t{sp}\n')

#2# create the fasta file without seq stop codon
with open(out_seq, 'w') as out: # open the fasta file to write seq
    for seq_read in SeqIO.parse(in_seq_NT, 'fasta'): # for each seq
        #la boucle va pour chaque exon, regarder les séquences et si cette séquence n'est pas présente dans la liste des séquences 
        #qui disposent d'un codon stop et bien elles vont ê écrite dans le fichier de sorties out seq (${GENE}_${EXON}_${POS}_final_align_NT_wt_ref_filtered_wt_stop.fasta)
        sp = seq_read.id # get the sp name (seq name)
        if sp not in list_seq_stop: # if the seq doesn't have a stop codon
            seq = seq_read.seq # get the seq
            out.write(f'>{sp}\n') # write the id of the seq in the out fasta file
            out.write(f'{seq}\n') # write the seq in the out fasta file
