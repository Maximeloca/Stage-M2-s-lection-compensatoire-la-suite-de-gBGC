## install packages ###
import sys
import pandas as pd
import random

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]path to table of substitutions positions [2]threshold of distance [3]number of randomisations")
# recuperer les arguments
tab_name = sys.argv[1] ###grand tableau concaténer avec toutes les infos sur les subst del et compe
dist_seuil = sys.argv[2] ###seuil de distance entre délétère et compensatoire --> 3
nb_random = sys.argv[3] ###nb de randomisation --> 1000

## script ###

dist_seuil = int(dist_seuil)
nb_random = int(nb_random)

tab_pos = pd.read_csv(tab_name, sep=',', header=None) ###récupère le tableau et nomme les colonnes 
tab_pos.columns = ["Exon", "Lg_seq", "Ep_uniq", "Br_ep", "Br_postep", "Nb_NS_WS_ep", "Nb_NS_WS_postep", "Nb_NS_SW_postep", "Nb_NS_SS_postep", "Nb_NS_WW_postep", "Nb_NS_tot_postep", "pos_NS_delet", "pos_NS_comp"]

tab_pos_1_1 = tab_pos[(tab_pos["Nb_NS_WS_ep"] == 1) & (tab_pos["Nb_NS_tot_postep"] == 1)] ###récupère les lignes ou on a une subst délétères du à la gBGC et une subst compensatoire

nb_dist_inf_seuil_list = []
for i in range(1, nb_random+1): ###pour chaque randomisation
    dist_list = []
    for index, row in tab_pos_1_1.iterrows(): #pour chaque ligne du tableau 
        pos_delet = row['pos_NS_delet'] #position de la subst délétère
        lg_seq = row['Lg_seq'] #longueur de l'exon
        nb_sites = int(lg_seq)/3 #nombre de sites correspond au nb de codons donc on prend la longueur de la séquence et on la divise par 3
        pos_comp_random = random.randint(1,int(nb_sites)) ##on tire une position alétoire entre toutes les positions
        dist = abs(pos_delet - pos_comp_random) #distance entre la subst délétère et la position aléatoire
        dist_list.append(dist) #on ajoute la distance à la liste 
    dist_inf_seuil = [dist for dist in dist_list if dist <= dist_seuil] ###on va créer une liste ou on a les cas ou une simulation est inférieur au seuil, ce qui va nous donner une valeur attendu qu'on pourra comparer à notre observer, ca va nous donner une distribution encore une fois 
    nb_dist_inf_seuil = len(dist_inf_seuil)
    nb_dist_inf_seuil_list.append(nb_dist_inf_seuil)
        
tab = pd.DataFrame({'Nb_dist_inf_seuil_random' : nb_dist_inf_seuil_list})

tab.to_csv('tab_nb_dist_random_comp_delet_inf_seuil.csv', index=False)

