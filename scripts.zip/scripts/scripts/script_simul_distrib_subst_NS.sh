#! /bin/bash

# Arguments ###

EXON=$1
TRIBE=$2
NB_SIMUL=$3

# Script ###

GENE=$(grep -w ${EXON} ~/Murinae/Reference_exons/gene_exon_position_ref_all.txt | cut -f1)

#if [[ ! -e Br_lg_tables/${GENE}_br_len.csv ]] ;then
#cd Br_lg_tables ;
#~/bin/num_br_lg/tpn ~/Murinae/${TRIBE}/Phylogeny/gene_tree/${GENE}_tree.treefile ${GENE}_br_len.csv ;
#cd .. ;
#fi


echo -e "exon : $EXON"
echo -e "nb simul : $NB_SIMUL"

#cd distrib_NS
python3 ~/scripts/simul_distrib_subst_NS_V2.py ~/Murinae/${TRIBE}/Detecting_gBGC/Detection/episodes/${GENE}_episodes_detection.csv ~/Murinae/${TRIBE}/Impact_episodes_NS/${EXON}_stat_nb_subst_NS.csv ~/Murinae/${TRIBE}/Randomisations/Br_lg_tables/${GENE}_br_len.csv $EXON $NB_SIMUL
#cd ..
