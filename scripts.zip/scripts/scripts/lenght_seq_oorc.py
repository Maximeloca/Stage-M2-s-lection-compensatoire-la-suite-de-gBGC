### Install packages ###
import sys
import os
from Bio import SeqIO

## Vérification des arguments ###
if len(sys.argv) != 5:
    sys.exit("ERROR : need 4 arguments: [1]alignment [2]output folder path [3]id_list file")

# Récupère les arguments
align = sys.argv[1]  # Fichier FASTA
foldr_align2 = sys.argv[2]
out_folder = sys.argv[3]  # Dossier de sortie
specie = sys.argv[4]

base_name = os.path.splitext(os.path.basename(align))[0]  # Récupère uniquement le nom du fichier sans extension, ca va split en deux en mode 'nom_fichier' '.fasta' et vu qu'on récupère que le nom_fichier on met [0]
align2 = os.path.join(foldr_align2, f"{base_name}_wt_gap_unique.fasta") 

# Création du nom du fichier de sortie
out_file_name = os.path.join(out_folder, f"list_fichier_taill_diff.txt")  # Définit le fichier de sortie, chemin + nom du fichier

# Initialisation des variables
leng1, leng2 = None, None  # Initialisation des variables longueur
filtered_sequences = []  # Liste des séquences filtrées

# Stocke les séquences filtrées avant d'écrire le fichier
for seq_read in SeqIO.parse(align, "fasta"):
    seq_id1 = seq_read.id
    if seq_id1 == specie: #garde uniquement les séquences dont l'ID figure dans la liste des id 
        seq_seq1 = seq_read.seq
        leng1=len(seq_seq1)

for seq_read in SeqIO.parse(align2, "fasta"):
    seq_id2 = seq_read.id
    if seq_id2 == specie: #garde uniquement les séquences dont l'ID figure dans la liste des id 
        seq_seq2 = seq_read.seq
        leng2=len(seq_seq2)

# Ajoute le nom de l'alignement à la liste si les longueurs diffèrent
if leng1 != leng2:  # seulement si les longueurs sont différentes
    filtered_sequences.append(f"{base_name}\n")  # Ajouter le nom du fichier (base_name) à la liste

# Écrit toutes les séquences filtrées dans le fichier de sortie
if filtered_sequences:
    with open(out_file_name, "a") as out:  # "a" pour ajouter à la fin du fichier
        out.writelines(filtered_sequences)  # Écrire dans le fichier de sortie