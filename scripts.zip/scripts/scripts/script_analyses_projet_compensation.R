# load packages

library(ggplot2)
library(tidyr)
library(dplyr)
library(ggpubr)

# set working directory

#setwd("~/Documents/Thèse/Projet_murinae/18_Compensation/")

### general informations ###
setwd("~/Documents/Darwin2/M2/S2/Stage/Stage gBC/Rattini")

## table of all data
tab <- read.csv("tab_recap_all_genes.csv", header=FALSE, sep="\t")
colnames(tab) <- c("Exon_ep","exon_pos", "Lg_seq","GC12","GC3","Br_ep","Br_lg","Br_Asc","Br_Desc1","Br_Desc2","Episode","Nb_subst_S_WS","signif_nb_subst_S_WS","Nb_subst_S_SW","Nb_subst_S_WW","Nb_subst_S_SS","Nb_subst_NS_WS","Nb_subst_NS_SW","Nb_subst_NS_SS","Nb_subst_NS_WW")

tab <- tab[tab$Br_lg > 0, ]

# retrieve paralog exons and error align
exons_paralog <- read.csv("paralog_exons_hydromyini.txt", header=F)
exons_aln_error <- read.table("List_exons_error_aln.csv", header=T)

tab_sans_paralog <- tab[!tab$Exon %in% exons_paralog$V1, ]
tab_sans_paralog <- tab_sans_paralog[!tab_sans_paralog$Exon %in% exons_aln_error$Exon, ]

# add GC-content
tab$AT12 <- 100 - tab$GC12
tab$AT3 <- 100 - tab$GC3

## number of episodes
tab_ep <- tab[tab$Episode == 'YES', ]
nb <- nrow(tab_ep)
nb

# in internal branches (=episodes after which we can search for compensation)
tab_ep_sans_term <- tab_ep[!is.na(tab_ep$Br_Desc1), ]
tab_ep_br_int <- tab_ep_sans_term[!is.na(tab_ep_sans_term$Br_Asc), ]
nb <- nrow(tab_ep_br_int)
nb

# with at least 1 NS-WS substitution
	
tab_ep_NS_WS <- tab_ep[tab_ep$Nb_subst_NS_WS > 0.9, ]
nb <- nrow(tab_ep_NS_WS)
nb

tab_ep_NS_WS_br_int <- tab_ep_br_int[tab_ep_br_int$Nb_subst_NS_WS > 0.9, ]
nb <- nrow(tab_ep_NS_WS_br_int)
nb

## distributions of exon length, branch length, GC12 and GC3 ## FIGURE S1 ##

# in all exons
tab_exon_info <- tab[, c("Exon_ep", "Lg_seq", "Br_lg", "GC3", "GC12")]
tab_exon_lg_seq <- distinct(tab_exon_info, Exon_ep, Lg_seq)
tab_exon_GC3 <- distinct(tab_exon_info, Exon_ep, GC3, GC12)

moy_lg_seq_all <- mean(tab_exon_lg_seq$Lg_seq)
plot_distrib_lg_seq_all <- ggplot(tab_exon_lg_seq, aes(Lg_seq)) +
  geom_histogram(binwidth=50, fill="azure3", color="black", size=0.3) +
  xlim(0,1000) +
  theme_linedraw() +
  xlab("") +
  ylab("counts") +
  geom_vline(xintercept = moy_lg_seq_all, size=0.8)
plot_distrib_lg_seq_all

moy_br_lg_all <- mean(tab_exon_info$Br_lg)
moy_het <- 0.0026
plot_distrib_br_lg_all <- ggplot(tab_exon_info, aes(Br_lg)) +
  geom_histogram(fill="azure3", color="black", size=0.3, binwidth = 0.001) +
  theme_linedraw() +
  xlab("") +
  ylab("") +
  geom_vline(xintercept = moy_br_lg_all, size=0.8)+
  geom_vline(xintercept = moy_het, size=0.8, linetype = "longdash")
plot_distrib_br_lg_all

moy_GC3_all <- mean(tab_exon_GC3$GC3)
plot_distrib_GC3_all <- ggplot(tab_exon_GC3, aes(GC3)) +
  geom_histogram(fill="azure3", color="black", size=0.3, binwidth=5) +
  theme_linedraw() +
  xlab("") +
  ylab("") +
  geom_vline(xintercept = moy_GC3_all, size=0.8) +
  xlim(0,100)
plot_distrib_GC3_all

moy_GC12_all <- mean(tab_exon_GC3$GC12)
plot_distrib_GC12_all <- ggplot(tab_exon_GC3, aes(GC12)) +
  geom_histogram(fill="azure3", color="black", size=0.3, binwidth=5) +
  theme_linedraw() +
  xlab("") +
  ylab("") +
  geom_vline(xintercept = moy_GC12_all, size=0.8) +
  xlim(0,100)
plot_distrib_GC12_all

plot_distrib_all <- ggarrange(plot_distrib_lg_seq_all, plot_distrib_br_lg_all, plot_distrib_GC3_all, plot_distrib_GC12_all, ncol = 4)
plot_distrib_all

# in exons with gBGC episodes

tab_exon_ep_info <- tab_ep[, c("Exon_ep", "Lg_seq", "Br_lg", "GC3", "GC12")]
tab_exon_ep_lg_seq <- distinct(tab_exon_ep_info, Exon_ep, Lg_seq)
tab_exon_ep_GC123 <- distinct(tab_exon_ep_info, Exon_ep, GC3, GC12)

moy_lg_seq_ep <- mean(tab_exon_ep_lg_seq$Lg_seq)
plot_distrib_lg_seq_ep <- ggplot(tab_exon_ep_lg_seq, aes(Lg_seq)) +
  geom_histogram(binwidth=50, fill="coral2", color="black", size=0.3) +
  xlim(0,1000) +
  theme_linedraw() +
  xlab("exon lengths") +
  ylab("counts") +
  geom_vline(xintercept = moy_lg_seq_ep, size=0.8)
plot_distrib_lg_seq_ep

moy_br_lg_ep <- mean(tab_exon_ep_info$Br_lg)
mean_het <- 0.0030
plot_distrib_br_lg_ep <- ggplot(tab_exon_ep_info, aes(Br_lg)) +
  geom_histogram(fill="coral2", color="black", size=0.3, binwidth=0.001) +
  theme_linedraw() +
  xlab("branch lengths") +
  ylab("") +
  geom_vline(xintercept = moy_br_lg_ep, size=0.8) +
  geom_vline(xintercept = mean_het, size=0.8, linetype = "longdash")
plot_distrib_br_lg_ep

moy_GC3_ep <- mean(tab_exon_ep_GC123$GC3)
plot_distrib_GC3_ep <- ggplot(tab_exon_ep_GC123, aes(GC3)) +
  geom_histogram(fill="coral2", color="black", size=0.3, binwidth=5) +
  theme_linedraw() +
  xlab("GC3") +
  ylab("") +
  geom_vline(xintercept = moy_GC3_ep, size=0.8) +
  xlim(0,100)
plot_distrib_GC3_ep

moy_GC12_ep <- mean(tab_exon_ep_GC123$GC12)
plot_distrib_GC12_ep <- ggplot(tab_exon_ep_GC123, aes(GC12)) +
  geom_histogram(fill="coral2", color="black", size=0.3, binwidth=5) +
  theme_linedraw() +
  xlab("GC12") +
  ylab("") +
  geom_vline(xintercept = moy_GC12_ep, size=0.8) +
  xlim(0,100)
plot_distrib_GC12_ep

plot_distrib_ep <- ggarrange(plot_distrib_lg_seq_ep, plot_distrib_br_lg_ep, plot_distrib_GC3_ep, plot_distrib_GC12_ep, ncol=4)
plot_distrib_ep


nb_sup_2 = sum(tab$Nb_subst_S_WS >= 1.8)



# final plot with two types of exons

plot_distrib_all_plus_ep <- ggarrange(plot_distrib_all, plot_distrib_ep, nrow=2, labels=c("A", "B"))
plot_distrib_all_plus_ep

ggsave("~/Documents/Thèse/Projet_murinae/Figures/resultats_generaux/hydromyini/plot_distrib.png", plot_distrib_all_plus_ep, width=10, height=5)

## mean number of substitutions ## TABLE S1 ##

# in branches with all types of episodes

mean(tab_ep$Nb_subst_S_WS) # we choose this way of calculation
#mean(tab_ep$Nb_subst_S_WS/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(tab_ep$Nb_subst_S_WS/(tab_ep$Lg_seq*0.33*(tab_ep$AT3/100)*tab_ep$Br_lg))
mean(tab_ep$Nb_subst_S_SW)
#mean(tab_ep$Nb_subst_S_SW/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(tab_ep$Nb_subst_S_SW/(tab_ep$Lg_seq*0.33*(tab_ep$GC3/100)*tab_ep$Br_lg))
mean(c(tab_ep$Nb_subst_S_SS, tab_ep$Nb_subst_S_WW))
#mean(c(tab_ep$Nb_subst_S_SS, tab_ep$Nb_subst_S_WW)/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(c((tab_ep$Nb_subst_S_SS/(tab_ep$Lg_seq*0.33*(tab_ep$GC3/100)*tab_ep$Br_lg)), (tab_ep$Nb_subst_S_WW/(tab_ep$Lg_seq*0.33*(tab_ep$AT3/100)*tab_ep$Br_lg))))
mean(tab_ep$Nb_subst_NS_WS)
#mean(tab_ep$Nb_subst_NS_WS/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(tab_ep$Nb_subst_NS_WS/(tab_ep$Lg_seq*0.67*(tab_ep$AT12/100)*tab_ep$Br_lg))
mean(tab_ep$Nb_subst_NS_SW)
#mean(tab_ep$Nb_subst_NS_SW/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(tab_ep$Nb_subst_NS_SW/(tab_ep$Lg_seq*0.67*(tab_ep$GC12/100)*tab_ep$Br_lg))
mean(c(tab_ep$Nb_subst_NS_SS, tab_ep$Nb_subst_NS_WW))
#mean(c(tab_ep$Nb_subst_NS_SS, tab_ep$Nb_subst_NS_WW))/mean(tab_ep$Lg_seq*tab_ep$Br_lg)
#mean(c((tab_ep$Nb_subst_NS_SS/(tab_ep$Lg_seq*0.67*(tab_ep$GC12/100)*tab_ep$Br_lg)), (tab_ep$Nb_subst_NS_WW/(tab_ep$Lg_seq*0.67*(tab_ep$AT12/100)*tab_ep$Br_lg))))

# in branches without episodes

tab_noep <- tab_sans_paralog[tab_sans_paralog$Episode != 'YES', ]

tab_noep <- tab_noep[!is.na(tab_noep$Br_Desc1), ] # retrieve terminal branches (to compare to punctual episodes which are not in term br)

mean(tab_noep$Nb_subst_S_WS)
#mean(tab_noep$Nb_subst_S_WS/(tab_noep$Lg_seq*tab_noep$Br_lg))
#mean(tab_noep$Nb_subst_S_WS/(tab_noep$Lg_seq*0.33*(tab_noep$AT3/100)*tab_noep$Br_lg))
mean(tab_noep$Nb_subst_S_SW)  
#mean(tab_noep$Nb_subst_S_SW/(tab_noep$Lg_seq*tab_noep$Br_lg))
#mean(tab_noep$Nb_subst_S_SW/(tab_noep$Lg_seq*0.33*(tab_noep$GC3/100)*tab_noep$Br_lg))
mean(tab_noep$Nb_subst_S_SS+tab_noep$Nb_subst_S_WW)
#mean((tab_noep$Nb_subst_S_SS+tab_noep$Nb_subst_S_WW)/(tab_noep$Lg_seq*0.33*tab_noep$Br_lg))
#mean(c((tab_noep$Nb_subst_S_SS/(tab_noep$Lg_seq*0.33*(tab_noep$GC3/100)*tab_noep$Br_lg)), (tab_noep$Nb_subst_S_WW/(tab_noep$Lg_seq*0.33*(tab_noep$AT3/100)*tab_noep$Br_lg))))
mean(tab_noep$Nb_subst_NS_WS)
#mean(tab_noep$Nb_subst_NS_WS/(tab_noep$Lg_seq*tab_noep$Br_lg))
#mean(tab_noep$Nb_subst_NS_WS/(tab_noep$Lg_seq*0.67*(tab_noep$AT12/100)*tab_noep$Br_lg))
mean(tab_noep$Nb_subst_NS_SW)
#mean(tab_noep$Nb_subst_NS_SW/(tab_noep$Lg_seq*tab_noep$Br_lg))
#mean(tab_noep$Nb_subst_NS_SW/(tab_noep$Lg_seq*0.67*(tab_noep$GC12/100)*tab_noep$Br_lg))
mean(tab_noep$Nb_subst_NS_SS+ tab_noep$Nb_subst_NS_WW)
#mean((tab_noep$Nb_subst_NS_SS+ tab_noep$Nb_subst_NS_WW)/(tab_noep$Lg_seq*0.67*tab_noep$Br_lg))
#mean(c((tab_noep$Nb_subst_NS_SS/(tab_noep$Lg_seq*0.67*(tab_noep$GC12/100)*tab_noep$Br_lg)), (tab_noep$Nb_subst_NS_WW/(tab_noep$Lg_seq*0.67*(tab_noep$AT12/100)*tab_noep$Br_lg))))

# in branches with punctual episodes

tab_tri_ep <- read.csv("classification_episodes_ML/posterior_episodes_optimum_hydromyini.csv", header=T, sep=",") # load the table of episodes classification
colnames(tab_tri_ep) <- c("Gene", "Exon_ep", "Br_ep", "true_type", "post1", "post2", "post3", "GoF")
tab_tri_ep <- tab_tri_ep[tab_tri_ep$GoF > 0.2, ] # retrieve episodes with gof <= 0.2
tab_tri_ep$punctual <- ifelse(tab_tri_ep$post1 > tab_tri_ep$post2 & tab_tri_ep$post1 > tab_tri_ep$post3, "YES", "NO") # add information of if episode in punctual
tab_ep_punctual <- tab_tri_ep[tab_tri_ep$punctual=="YES", ] # keep only punctuals
exons_paralog <- read.csv("paralog_exons_hydromyini.txt", header=F)
exons_aln_error <- read.table("List_exons_error_aln.csv", header=T)
tab_ep_punctual <- tab_ep_punctual[!tab_ep_punctual$Exon %in% exons_paralog$V1, ] # retrieve paralog exons
tab_ep_punctual <- tab_ep_punctual[!tab_ep_punctual$Exon %in% exons_aln_error$Exon, ] # retrieve aln arror exons

	# merge the table of punctual episodes with the table of informations on episodes
tab_ep_punctual <- merge(tab_ep_br_int, tab_ep_punctual, by=c("Exon_ep","Br_ep"))
	# total number of punctual episodes
nrow(tab_ep_punctual)	
	# number of punctual episodes with at least 1 NS-WS
nrow(tab_ep_punctual[tab_ep_punctual$Nb_subst_NS_WS > 0.9, ])
	# number of punctual episodes without NS-WS
nrow(tab_ep_punctual[tab_ep_punctual$Nb_subst_NS_WS < 0.1, ])

	# mean number of substitutions
mean(tab_ep_punctual$Nb_subst_S_WS)
#mean(tab_ep_punctual$Nb_subst_S_WS/(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg))
#mean(tab_ep_punctual$Nb_subst_S_WS/(tab_ep_punctual$Lg_seq*0.33*(tab_ep_punctual$AT3/100)*tab_ep_punctual$Br_lg))
mean(tab_ep_punctual$Nb_subst_S_SW)
#mean(tab_ep_punctual$Nb_subst_S_SW/(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg))
#mean(tab_ep_punctual$Nb_subst_S_SW/(tab_ep_punctual$Lg_seq*0.33*(tab_ep_punctual$GC3/100)*tab_ep_punctual$Br_lg))
mean(tab_ep_punctual$Nb_subst_S_SS+tab_ep_punctual$Nb_subst_S_WW)
#mean((tab_ep_punctual$Nb_subst_S_SS+ tab_ep_punctual$Nb_subst_S_WW)/(tab_ep_punctual$Lg_seq*0.33*tab_ep_punctual$Br_lg))
#mean(c((tab_ep_punctual$Nb_subst_S_SS/(tab_ep_punctual$Lg_seq*0.33*(tab_ep_punctual$GC3/100)*tab_ep_punctual$Br_lg)), (tab_ep_punctual$Nb_subst_S_WW/(tab_ep_punctual$Lg_seq*0.33*(tab_ep_punctual$AT3/100)*tab_ep_punctual$Br_lg))))
mean(tab_ep_punctual$Nb_subst_NS_WS)
#mean(tab_ep_punctual$Nb_subst_NS_WS/(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg)) # 0.90
#mean(tab_ep_punctual$Nb_subst_NS_WS/(tab_ep_punctual$Lg_seq*0.67*(tab_ep_punctual$AT12/100)*tab_ep_punctual$Br_lg))
mean(tab_ep_punctual$Nb_subst_NS_SW)
#mean(tab_ep_punctual$Nb_subst_NS_SW/(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg)) # 0.24
#mean(tab_ep_punctual$Nb_subst_NS_SW/(tab_ep_punctual$Lg_seq*0.67*(tab_ep_punctual$GC12/100)*tab_ep_punctual$Br_lg))
mean(tab_ep_punctual$Nb_subst_NS_SS+ tab_ep_punctual$Nb_subst_NS_WW)
#mean(c(tab_ep_punctual$Nb_subst_NS_SS, tab_ep_punctual$Nb_subst_NS_WW))/#mean(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg) # 0.07
#mean(c((tab_ep_punctual$Nb_subst_NS_SS/(tab_ep_punctual$Lg_seq*0.67*(tab_ep_punctual$GC12/100)*tab_ep_punctual$Br_lg)), (tab_ep_punctual$Nb_subst_NS_WW/(tab_ep_punctual$Lg_seq*0.67*(tab_ep_punctual$AT12/100)*tab_ep_punctual$Br_lg))))


## S-WS in function of S-SW ## FIGURE 3 ##

	# in branches without episodes

tab_pas_ep <- tab_sans_paralog[tab_sans_paralog$Episode != "YES", ]
nrow(tab_pas_ep)
tab_subset_pas_ep <- sample_n(tab_pas_ep, 100000) # tab of a random sample for the plot

plot_pas_ep <- ggplot(tab_subset_pas_ep, aes(x=Nb_subst_S_SW/(0.33*Lg_seq*(GC3/100)), y=Nb_subst_S_WS/(0.33*Lg_seq*(AT3/100)))) +
  geom_point(color="grey",size=2, alpha=0.5) +
  xlim(0,0.5) +
  ylim(0,0.5) +
  theme_linedraw() +
  xlab("dS(SW)") +
  ylab("dS(WS)") +
  ggtitle("No episode") +
  geom_abline(slope=1, intercept = 0) +
  theme(plot.title = element_text(hjust = 0.5))
plot_pas_ep

	# in branches with all types of episodes

tab_all_ep <- tab_sans_paralog[tab_sans_paralog$Episode == "YES", ]
nrow(tab_all_ep)
tab_subset_all_ep <- sample_n(tab_all_ep, 1000)

plot_all_ep <- ggplot(tab_subset_all_ep, aes(x=Nb_subst_S_SW/(0.33*Lg_seq*(GC3/100)), y=Nb_subst_S_WS/(0.33*Lg_seq*(AT3/100)))) +
  geom_point(color="red",size=2, alpha=0.5) +
  xlim(0,0.5) +
  ylim(0,0.5) +
  theme_linedraw() +
  xlab("dS(SW)") +
  ylab("dS(WS)") +
  ggtitle("All episodes") +
  geom_abline(slope=1, intercept = 0) +
  theme(plot.title = element_text(hjust = 0.5))
plot_all_ep

	# in branches with punctual episodes
tab_tri_ep <- read.csv("classification_episodes_ML/posterior_episodes_optimum_hydromyini.csv", header=T, sep=",")
colnames(tab_tri_ep) <- c("Gene", "Exon_ep", "Br_ep", "true_type", "post1", "post2", "post3", "GoF")
tab_tri_ep <- tab_tri_ep[tab_tri_ep$GoF > 0.2, ] # retrieve lines with gof <= 0.2
tab_tri_ep$punctual <- ifelse(tab_tri_ep$post1 > tab_tri_ep$post2 & tab_tri_ep$post1 > tab_tri_ep$post3, "YES", "NO") # add a column of is the episode punctual
tab_sans_paralog_tri_ep <- merge(tab_sans_paralog, tab_tri_ep, by=c("Exon_ep", "Br_ep"), all.x=TRUE) # merge this table with the general informations table
tab_sans_paralog_tri_ep$punctual <- ifelse(is.na(tab_sans_paralog_tri_ep$punctual), "NO", tab_sans_paralog_tri_ep$punctual) # fill the NA with NO in the column of is the episode punctual
tab_ep_punctual <- tab_sans_paralog_tri_ep[tab_sans_paralog_tri_ep$punctual == "YES", ] # keep only the lines with punctual episodes
tab_subset_ep_punctual <- sample_n(tab_ep_punctual, 300) # take a random sample of this table
  
plot_ep_punctual <- ggplot(tab_subset_ep_punctual, aes(x=Nb_subst_S_SW/(0.33*Lg_seq*(GC3/100)), y=Nb_subst_S_WS/(0.33*Lg_seq*(AT3/100)))) +
  geom_point(color="red", size=2, alpha=0.5) +
  xlim(0,0.5) +
  ylim(0,0.5) +
  theme_linedraw() +
  xlab("dS(SW)") +
  ylab("dS(WS)") +
  ggtitle("Punctual episodes") +
  geom_abline(slope=1, intercept = 0) +
  theme(plot.title = element_text(hjust = 0.5))
plot_ep_punctual

plot_final <- ggarrange(plot_pas_ep, plot_all_ep, plot_ep_punctual, ncol=3)
plot_final

ggsave("~/Documents/Thèse/Projet_murinae/Figures/resultats_generaux/hydromyini/plot_SWS_fct_SSW_V2.png", plot_final, width=8, height = 2.5)





### compensation analyses ###

## Episode classification

tab_tri_ep <- read.csv("classification_episodes_ML/posterior_episodes_optimum_hydromyini.csv", header=T, sep=",")
colnames(tab_tri_ep) <- c("Gene", "Exon_ep", "Br_ep", "true_type", "post1", "post2", "post3", "GoF")
	# retrieve paralog exonx and aln with potential error
exons_paralog <- read.csv("paralog_exons_hydromyini.txt", header=F)
exons_aln_error <- read.table("List_exons_error_aln.csv", header=T)
tab_tri_ep <- tab_tri_ep[!tab_tri_ep$Exon %in% exons_paralog$V1, ]
tab_tri_ep <- tab_tri_ep[!tab_tri_ep$Exon %in% exons_aln_error$Exon, ]
	# retrieve episodes with gof < 0.2
tab_tri_ep <- tab_tri_ep[tab_tri_ep$GoF > 0.2, ]
	# table of punctual episodes
tab_ep_ponctual <- subset(tab_tri_ep, post1 > post2 & post1 > post3)
	# table of two-branches episodes
tab_ep_twobr <- subset(tab_tri_ep, post2 > post1 & post2 > post3)
	# table of all-exons episodes
tab_ep_allex <- subset(tab_tri_ep, post3 > post1 & post3 > post2)


## test for compensation ## FIGURE 5 ##

# NS after episodes with at least 1 NS-WS #

	## WS

# load table
tab_random_NS_WS_postepNS <- read.csv("tab_analyse_randomNS_hydromyini/tab_all_genes/tab_NS_WS_after_epNS_with_random.csv", header=T, sep=',')
colnames(tab_random_NS_WS_postepNS) <- c(c("Exon_ep", "dNdS", "Lg_seq", "GC12", "GC3", "Br"," Br_lg", "Episode", "Nb_subst_S_WS", "Nb_subst_NS_WS"), as.character(seq(1,1000)), "Br_ep", "Br_asc_lg", "Ep_uniq")

# retrive lines where there is an episode
tab_random_NS_WS_postepNS <- tab_random_NS_WS_postepNS[tab_random_NS_WS_postepNS$Episode != 'YES', ]

# select a type of episode
tab_random_NS_WS_postepNS <- merge(tab_ep_ponctual, tab_random_NS_WS_postepNS, by = c("Exon_ep", "Br_ep")) # punctual
tab_random_NS_WS_postepNS <- merge(tab_ep_twobr, tab_random_NS_WS_postepNS, by = c("Exon_ep", "Br_ep")) # two-branches
tab_random_NS_WS_postepNS <- merge(tab_ep_allex, tab_random_NS_WS_postepNS, by = c("Exon_ep", "Br_ep")) # all-exons

# count nunber of episodes
tab_count_ep <- tab_random_NS_WS_postepNS[, c("Exon_ep", "Br_ep")]
nrow(distinct(tab_count_ep))

# sum all the NS substitutions observed in post-episode branches
nb_NS_WS_obs_tot_postepNS <- sum(tab_random_NS_WS_postepNS$Nb_subst_NS_WS)

# sum all of the NS substitutions expected in post-episode branches, for each of the 1000 randomisations (it gives a vector of 1000 values)
distrib_nb_NS_att_WS_postepNS <- as.data.frame(colSums(tab_random_NS_WS_postepNS[, 18:1017]))
colnames(distrib_nb_NS_att_WS_postepNS) <- c("WS")

# p-value
(1000-sum(nb_NS_WS_obs_tot_postepNS > distrib_nb_NS_att_WS_postepNS$WS))/1000 # if excess
(1000-sum(nb_NS_WS_obs_tot_postepNS < distrib_nb_NS_att_WS_postepNS$WS))/1000 # if deficit

	## SW

# load table
tab_random_NS_SW_postepNS <- read.csv("tab_analyse_randomNS_hydromyini/tab_all_genes/tab_NS_SW_after_epNS_with_random.csv", header=T, sep=',')
colnames(tab_random_NS_SW_postepNS) <- c(c("Exon_ep", "dNdS", "Lg_seq", "GC12", "GC3", "Br"," Br_lg", "Episode", "Nb_subst_S_WS", "Nb_subst_NS_SW"), as.character(seq(1,1000)), "Br_ep", "Br_asc_lg", "Ep_uniq")

# retrive lines where there is an episode
tab_random_NS_SW_postepNS <- tab_random_NS_SW_postepNS[tab_random_NS_SW_postepNS$Episode != 'YES', ]

# select a type of episode
tab_random_NS_SW_postepNS <- merge(tab_ep_ponctual, tab_random_NS_SW_postepNS, by = c("Exon_ep", "Br_ep")) # punctual
tab_random_NS_SW_postepNS <- merge(tab_ep_twobr, tab_random_NS_SW_postepNS, by = c("Exon_ep", "Br_ep")) # two-branches
tab_random_NS_SW_postepNS <- merge(tab_ep_allex, tab_random_NS_SW_postepNS, by = c("Exon_ep", "Br_ep")) # all-exons

# count nunber of episodes
tab_count_ep <- tab_random_NS_SW_postepNS[, c("Exon_ep", "Br_ep")]
nrow(distinct(tab_count_ep))

# sum all the NS substitutions observed in post-episode branches
nb_NS_SW_obs_tot_postepNS <- sum(tab_random_NS_SW_postepNS$Nb_subst_NS_SW)

# sum all of the NS substitutions expected in post-episode branches, for each of the 1000 randomisations (it gives a vector of 1000 values)
distrib_nb_NS_att_SW_postepNS <- as.data.frame(colSums(tab_random_NS_SW_postepNS[, 18:1017]))
colnames(distrib_nb_NS_att_SW_postepNS) <- c("SW")

# p-value
(1000-sum(nb_NS_SW_obs_tot_postepNS > distrib_nb_NS_att_SW_postepNS$SW))/1000 # if excess
(1000-sum(nb_NS_SW_obs_tot_postepNS < distrib_nb_NS_att_SW_postepNS$SW))/1000 # if deficit
	
	## SS

# load table
tab_random_NS_SS_postepNS <- read.csv("tab_analyse_randomNS_hydromyini/tab_all_genes/tab_NS_SS_after_epNS_with_random.csv", header=T, sep=',')
colnames(tab_random_NS_SS_postepNS) <- c(c("Exon_ep", "dNdS", "Lg_seq", "GC12", "GC3", "Br"," Br_lg", "Episode", "Nb_subst_S_WS", "Nb_subst_NS_SS"), as.character(seq(1,1000)), "Br_ep", "Br_asc_lg", "Ep_uniq")

# retrive lines where there is an episode
tab_random_NS_SS_postepNS <- tab_random_NS_SS_postepNS[tab_random_NS_SS_postepNS$Episode != 'YES', ]

# select a type of episode
tab_random_NS_SS_postepNS <- merge(tab_ep_ponctual, tab_random_NS_SS_postepNS, by = c("Exon_ep", "Br_ep")) # punctual
tab_random_NS_SS_postepNS <- merge(tab_ep_twobr, tab_random_NS_SS_postepNS, by = c("Exon_ep", "Br_ep")) # two-branches
tab_random_NS_SS_postepNS <- merge(tab_ep_allex, tab_random_NS_SS_postepNS, by = c("Exon_ep", "Br_ep")) # all-exons

# count nunber of episodes
tab_count_ep <- tab_random_NS_SS_postepNS[, c("Exon_ep", "Br_ep")]
nrow(distinct(tab_count_ep))

# sum all the NS substitutions observed in post-episode branches
nb_NS_SS_obs_tot_postepNS <- sum(tab_random_NS_SS_postepNS$Nb_subst_NS_SS)

# sum all of the NS substitutions expected in post-episode branches, for each of the 1000 randomisations (it gives a vector of 1000 values)
distrib_nb_NS_att_SS_postepNS <- as.data.frame(colSums(tab_random_NS_SS_postepNS[, 18:1017]))
colnames(distrib_nb_NS_att_SS_postepNS) <- c("SS")
	
	## WW

# load table
tab_random_NS_WW_postepNS <- read.csv("tab_analyse_randomNS_hydromyini/tab_all_genes/tab_NS_WW_after_epNS_with_random.csv", header=T, sep=',')
colnames(tab_random_NS_WW_postepNS) <- c(c("Exon_ep", "dNdS", "Lg_seq", "GC12", "GC3", "Br"," Br_lg", "Episode", "Nb_subst_S_WS", "Nb_subst_NS_WW"), as.character(seq(1,1000)), "Br_ep", "Br_asc_lg", "Ep_uniq")

# retrive lines where there is an episode
tab_random_NS_WW_postepNS <- tab_random_NS_WW_postepNS[tab_random_NS_WW_postepNS$Episode != 'YES', ]

# select a type of episode
tab_random_NS_WW_postepNS <- merge(tab_ep_ponctual, tab_random_NS_WW_postepNS, by = c("Exon_ep", "Br_ep")) # punctual
tab_random_NS_WW_postepNS <- merge(tab_ep_twobr, tab_random_NS_WW_postepNS, by = c("Exon_ep", "Br_ep")) # two-branches
tab_random_NS_WW_postepNS <- merge(tab_ep_allex, tab_random_NS_WW_postepNS, by = c("Exon_ep", "Br_ep")) # all-exons

# count nunber of episodes
tab_count_ep <- tab_random_NS_WW_postepNS[, c("Exon_ep", "Br_ep")]
nrow(distinct(tab_count_ep))

# sum all the NS substitutions observed in post-episode branches
nb_NS_WW_obs_tot_postepNS <- sum(tab_random_NS_WW_postepNS$Nb_subst_NS_WW)

# sum all of the NS substitutions expected in post-episode branches, for each of the 1000 randomisations (it gives a vector of 1000 values)
distrib_nb_NS_att_WW_postepNS <- as.data.frame(colSums(tab_random_NS_WW_postepNS[, 18:1017]))
colnames(distrib_nb_NS_att_WW_postepNS) <- c("WW")

	## SS+WW
# observed
nb_NS_SSWW_obs_tot_postepNS <- nb_NS_SS_obs_tot_postepNS + nb_NS_WW_obs_tot_postepNS
# expected
tot_NS_att_SSWW_postepNS <- as.data.frame(distrib_nb_NS_att_SS_postepNS + distrib_nb_NS_att_WW_postepNS)
colnames(tot_NS_att_SSWW_postepNS) <- c("SSWW")
# p-value
(1000-sum(nb_NS_SSWW_obs_tot_postepNS > tot_NS_att_SSWW_postepNS))/1000 # if excess
(1000-sum(nb_NS_SSWW_obs_tot_postepNS < tot_NS_att_SSWW_postepNS))/1000 # if deficit

	## total NS = WS+SW+SSWW
# observed
tot_NS_obs_postepNS <- nb_NS_WS_obs_tot_postepNS + nb_NS_SW_obs_tot_postepNS + nb_NS_SSWW_obs_tot_postepNS
# expected
tot_NS_att_postepNS <- as.data.frame(distrib_nb_NS_att_WS_postepNS + distrib_nb_NS_att_SW_postepNS + distrib_nb_NS_att_WW_postepNS + distrib_nb_NS_att_SS_postepNS)
colnames(tot_NS_att_postepNS) <- c("total")
# p-value
(1000-sum(tot_NS_obs_postepNS > tot_NS_att_postepNS$total))/1000 # if excess
1000-sum(tot_NS_obs_postepNS < tot_NS_att_postepNS$total))/1000 # if deficit

	## plots
# WS
plot_NS_WS_ponctual <- ggplot(distrib_nb_NS_att_WS_postepNS, aes(WS)) +
  geom_density(color="black", fill="coral2", size=0.3) +
  geom_vline(xintercept = nb_NS_WS_obs_tot_postepNS, color = "black", size=0.6) +
  xlab("") +
  ylab("density") +
  theme_linedraw() +
  theme(axis.title.x = element_text(size = 10), axis.title.y = element_text(size=10))
plot_NS_WS_ponctual
# SW
plot_NS_SW_ponctual <- ggplot(distrib_nb_NS_att_SW_postepNS, aes(SW)) +
  geom_density(color="black", fill="cornflowerblue", size=0.3) +
  geom_vline(xintercept = nb_NS_SW_obs_tot_postepNS, color = "black", size=0.6) +
  xlab("") +
  ylab("") +
  theme_linedraw() +
  theme(axis.title.x = element_text(size = 10), axis.title.y = element_text(size=10)) 
plot_NS_SW_ponctual
# SSWW
plot_NS_SSWW_ponctual <- ggplot(tot_NS_att_SSWW_postepNS, aes(SSWW)) +
  geom_density(color="black", fill="darkseagreen", size=0.3) +
  geom_vline(xintercept = nb_NS_SSWW_obs_tot_postepNS, color = "black", size=0.6) +
  xlab("") +
  ylab("") +
  theme_linedraw() +
  theme(axis.title.x = element_text(size = 10), axis.title.y = element_text(size=10)) 
plot_NS_SSWW_ponctual
# Total (WS+SW+SSWW)
plot_NS_tot_ponctual <- ggplot(tot_NS_att_postepNS, aes(total)) +
  geom_density(color="black", fill="plum3", size=0.3) +
  geom_vline(xintercept = tot_NS_obs_postepNS, color = "black", size=0.6) +
  xlab("") +
  ylab("density") +
  theme_linedraw() +
  theme(axis.title.x = element_text(size = 10), axis.title.y = element_text(size=10)) 
plot_NS_tot_ponctual
# merge all this plot
plot_NS_types_postepNS <- ggarrange(plot_NS_WS_ponctual, plot_NS_SW_ponctual, plot_NS_SSWW_ponctual, ncol = 3)
plot_NS_types_postepNS




####Cetaces####
setwd("~/Documents/Darwin2/M2/S2/Stage/Stage gBC/donnees_cetace")



## table of all data
tab <- read.csv("tab_recap_all_genes.csv", header=FALSE, sep="\t")
colnames(tab) <- c("Exon_ep", "Lg_seq","GC12","GC3","Br_ep","Br_lg","Br_Asc","Br_Desc1","Br_Desc2","Episode","Nb_subst_S_WS","signif_nb_subst_S_WS","Nb_subst_S_SW","Nb_subst_S_WW","Nb_subst_S_SS","Nb_subst_NS_WS","Nb_subst_NS_SW","Nb_subst_NS_SS","Nb_subst_NS_WW")

tab <- tab[tab$Br_lg > 0, ]

# retrieve paralog exons and error align
#exons_paralog <- read.csv("paralog_exons_hydromyini.txt", header=F)
#xons_aln_error <- read.table("List_exons_error_aln.csv", header=T)

##tab_sans_paralog <- tab[!tab$Exon %in% exons_paralog$V1, ]
#tab_sans_paralog <- tab_sans_paralog[!tab_sans_paralog$Exon %in% exons_aln_error$Exon, ]

# add GC-content
#tab_sans_paralog$AT12 <- 100 - tab_sans_paralog$GC12
#tab_sans_paralog$AT3 <- 100 - tab_sans_paralog$GC3

## number of episodes
tab_ep <- tab[tab$Episode == 'YES', ]
nb <- nrow(tab_ep)
nb

# in internal branches (=episodes after which we can search for compensation)
tab_ep_sans_term <- tab_ep[!is.na(tab_ep$Br_Desc1), ]
tab_ep_br_int <- tab_ep_sans_term[!is.na(tab_ep_sans_term$Br_Asc), ]
nb <- nrow(tab_ep_br_int)
nb

# with at least 1 NS-WS substitution

tab_ep_NS_WS <- tab_ep[tab_ep$Nb_subst_NS_WS > 0.9, ]
nb <- nrow(tab_ep_NS_WS)
nb

tab_ep_NS_WS_br_int <- tab_ep_br_int[tab_ep_br_int$Nb_subst_NS_WS > 0.9, ]
nb <- nrow(tab_ep_NS_WS_br_int)
nb

## distributions of exon length, branch length, GC12 and GC3 ## FIGURE S1 ##

# in all exons
tab_exon_info <- tab[, c("Exon_ep", "Lg_seq", "Br_lg", "GC3", "GC12")]
tab_exon_lg_seq <- distinct(tab_exon_info, Exon_ep, Lg_seq)
tab_exon_GC3 <- distinct(tab_exon_info, Exon_ep, GC3, GC12)

moy_lg_seq_all <- mean(tab_exon_lg_seq$Lg_seq)
plot_distrib_lg_seq_all <- ggplot(tab_exon_lg_seq, aes(Lg_seq)) +
  geom_histogram(binwidth=50, fill="azure3", color="black", size=0.3) +
  xlim(0,1000) +
  theme_linedraw() +
  xlab("") +
  ylab("counts") +
  geom_vline(xintercept = moy_lg_seq_all, size=0.8)
plot_distrib_lg_seq_all

moy_br_lg_all <- mean(tab_exon_info$Br_lg)
moy_het <- 0.0026
plot_distrib_br_lg_all <- ggplot(tab_exon_info, aes(Br_lg)) +
  geom_histogram(fill="azure3", color="black", size=0.3, binwidth = 0.001) +
  theme_linedraw() +
  xlab("") +
  ylab("") +
  geom_vline(xintercept = moy_br_lg_all, size=0.8)+
  geom_vline(xintercept = moy_het, size=0.8, linetype = "longdash")
plot_distrib_br_lg_all

tot = sum(tab$Nb_subst_S_WS) + sum(tab$Nb_subst_S_SW) + sum(tab$Nb_subst_S_SS) + sum(tab$Nb_subst_S_WW) + sum(tab$Nb_subst_NS_WS) + sum(tab$Nb_subst_NS_SW) + sum(tab$Nb_subst_NS_SS) + sum(tab$Nb_subst_NS_WW)
tot


moy_GC3_all <- mean(tab_exon_GC3$GC3)
plot_distrib_GC3_all <- ggplot(tab_exon_GC3, aes(GC3)) +
  geom_histogram(fill="azure3", color="black", size=0.3, binwidth=5) +
  theme_linedraw() +
  xlab("") +
  ylab("") +
  geom_vline(xintercept = moy_GC3_all, size=0.8) +
  xlim(0,100)
plot_distrib_GC3_all

moy_GC12_all <- mean(tab_exon_GC3$GC12)
plot_distrib_GC12_all <- ggplot(tab_exon_GC3, aes(GC12)) +
  geom_histogram(fill="azure3", color="black", size=0.3, binwidth=5) +
  theme_linedraw() +
  xlab("") +
  ylab("") +
  geom_vline(xintercept = moy_GC12_all, size=0.8) +
  xlim(0,100)
plot_distrib_GC12_all

plot_distrib_all <- ggarrange(plot_distrib_lg_seq_all, plot_distrib_br_lg_all, plot_distrib_GC3_all, plot_distrib_GC12_all, ncol = 4)
plot_distrib_all

# in exons with gBGC episodes

tab_exon_ep_info <- tab_ep[, c("Exon", "Lg_seq", "Br_lg", "GC3", "GC12")]
tab_exon_ep_lg_seq <- distinct(tab_exon_ep_info, Exon, Lg_seq)
tab_exon_ep_GC123 <- distinct(tab_exon_ep_info, Exon, GC3, GC12)

moy_lg_seq_ep <- mean(tab_exon_ep_lg_seq$Lg_seq)
plot_distrib_lg_seq_ep <- ggplot(tab_exon_ep_lg_seq, aes(Lg_seq)) +
  geom_histogram(binwidth=50, fill="coral2", color="black", size=0.3) +
  xlim(0,1000) +
  theme_linedraw() +
  xlab("exon lengths") +
  ylab("counts") +
  geom_vline(xintercept = moy_lg_seq_ep, size=0.8)
plot_distrib_lg_seq_ep

moy_br_lg_ep <- mean(tab_exon_ep_info$Br_lg)
mean_het <- 0.0030
plot_distrib_br_lg_ep <- ggplot(tab_exon_ep_info, aes(Br_lg)) +
  geom_histogram(fill="coral2", color="black", size=0.3, binwidth=0.001) +
  theme_linedraw() +
  xlab("branch lengths") +
  ylab("") +
  geom_vline(xintercept = moy_br_lg_ep, size=0.8) +
  geom_vline(xintercept = mean_het, size=0.8, linetype = "longdash")
plot_distrib_br_lg_ep

moy_GC3_ep <- mean(tab_exon_ep_GC123$GC3)
plot_distrib_GC3_ep <- ggplot(tab_exon_ep_GC123, aes(GC3)) +
  geom_histogram(fill="coral2", color="black", size=0.3, binwidth=5) +
  theme_linedraw() +
  xlab("GC3") +
  ylab("") +
  geom_vline(xintercept = moy_GC3_ep, size=0.8) +
  xlim(0,100)
plot_distrib_GC3_ep

moy_GC12_ep <- mean(tab_exon_ep_GC123$GC12)
plot_distrib_GC12_ep <- ggplot(tab_exon_ep_GC123, aes(GC12)) +
  geom_histogram(fill="coral2", color="black", size=0.3, binwidth=5) +
  theme_linedraw() +
  xlab("GC12") +
  ylab("") +
  geom_vline(xintercept = moy_GC12_ep, size=0.8) +
  xlim(0,100)
plot_distrib_GC12_ep

plot_distrib_ep <- ggarrange(plot_distrib_lg_seq_ep, plot_distrib_br_lg_ep, plot_distrib_GC3_ep, plot_distrib_GC12_ep, ncol=4)
plot_distrib_ep

# final plot with two types of exons

plot_distrib_all_plus_ep <- ggarrange(plot_distrib_all, plot_distrib_ep, nrow=2, labels=c("A", "B"))
plot_distrib_all_plus_ep

ggsave("~/Documents/Thèse/Projet_murinae/Figures/resultats_generaux/hydromyini/plot_distrib.png", plot_distrib_all_plus_ep, width=10, height=5)

## mean number of substitutions ## TABLE S1 ##

# in branches with all types of episodes

mean(tab_ep$Nb_subst_S_WS) # we choose this way of calculation
#mean(tab_ep$Nb_subst_S_WS/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(tab_ep$Nb_subst_S_WS/(tab_ep$Lg_seq*0.33*(tab_ep$AT3/100)*tab_ep$Br_lg))
mean(tab_ep$Nb_subst_S_SW)
#mean(tab_ep$Nb_subst_S_SW/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(tab_ep$Nb_subst_S_SW/(tab_ep$Lg_seq*0.33*(tab_ep$GC3/100)*tab_ep$Br_lg))
mean(c(tab_ep$Nb_subst_S_SS, tab_ep$Nb_subst_S_WW))
#mean(c(tab_ep$Nb_subst_S_SS, tab_ep$Nb_subst_S_WW)/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(c((tab_ep$Nb_subst_S_SS/(tab_ep$Lg_seq*0.33*(tab_ep$GC3/100)*tab_ep$Br_lg)), (tab_ep$Nb_subst_S_WW/(tab_ep$Lg_seq*0.33*(tab_ep$AT3/100)*tab_ep$Br_lg))))
mean(tab_ep$Nb_subst_NS_WS)
#mean(tab_ep$Nb_subst_NS_WS/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(tab_ep$Nb_subst_NS_WS/(tab_ep$Lg_seq*0.67*(tab_ep$AT12/100)*tab_ep$Br_lg))
mean(tab_ep$Nb_subst_NS_SW)
#mean(tab_ep$Nb_subst_NS_SW/(tab_ep$Lg_seq*tab_ep$Br_lg))
#mean(tab_ep$Nb_subst_NS_SW/(tab_ep$Lg_seq*0.67*(tab_ep$GC12/100)*tab_ep$Br_lg))
mean(c(tab_ep$Nb_subst_NS_SS, tab_ep$Nb_subst_NS_WW))
#mean(c(tab_ep$Nb_subst_NS_SS, tab_ep$Nb_subst_NS_WW))/mean(tab_ep$Lg_seq*tab_ep$Br_lg)
#mean(c((tab_ep$Nb_subst_NS_SS/(tab_ep$Lg_seq*0.67*(tab_ep$GC12/100)*tab_ep$Br_lg)), (tab_ep$Nb_subst_NS_WW/(tab_ep$Lg_seq*0.67*(tab_ep$AT12/100)*tab_ep$Br_lg))))

# in branches without episodes

tab_noep <- tab_sans_paralog[tab_sans_paralog$Episode != 'YES', ]

tab_noep <- tab_noep[!is.na(tab_noep$Br_Desc1), ] # retrieve terminal branches (to compare to punctual episodes which are not in term br)

mean(tab_noep$Nb_subst_S_WS)
#mean(tab_noep$Nb_subst_S_WS/(tab_noep$Lg_seq*tab_noep$Br_lg))
#mean(tab_noep$Nb_subst_S_WS/(tab_noep$Lg_seq*0.33*(tab_noep$AT3/100)*tab_noep$Br_lg))
mean(tab_noep$Nb_subst_S_SW)  
#mean(tab_noep$Nb_subst_S_SW/(tab_noep$Lg_seq*tab_noep$Br_lg))
#mean(tab_noep$Nb_subst_S_SW/(tab_noep$Lg_seq*0.33*(tab_noep$GC3/100)*tab_noep$Br_lg))
mean(tab_noep$Nb_subst_S_SS+tab_noep$Nb_subst_S_WW)
#mean((tab_noep$Nb_subst_S_SS+tab_noep$Nb_subst_S_WW)/(tab_noep$Lg_seq*0.33*tab_noep$Br_lg))
#mean(c((tab_noep$Nb_subst_S_SS/(tab_noep$Lg_seq*0.33*(tab_noep$GC3/100)*tab_noep$Br_lg)), (tab_noep$Nb_subst_S_WW/(tab_noep$Lg_seq*0.33*(tab_noep$AT3/100)*tab_noep$Br_lg))))
mean(tab_noep$Nb_subst_NS_WS)
#mean(tab_noep$Nb_subst_NS_WS/(tab_noep$Lg_seq*tab_noep$Br_lg))
#mean(tab_noep$Nb_subst_NS_WS/(tab_noep$Lg_seq*0.67*(tab_noep$AT12/100)*tab_noep$Br_lg))
mean(tab_noep$Nb_subst_NS_SW)
#mean(tab_noep$Nb_subst_NS_SW/(tab_noep$Lg_seq*tab_noep$Br_lg))
#mean(tab_noep$Nb_subst_NS_SW/(tab_noep$Lg_seq*0.67*(tab_noep$GC12/100)*tab_noep$Br_lg))
mean(tab_noep$Nb_subst_NS_SS+ tab_noep$Nb_subst_NS_WW)
#mean((tab_noep$Nb_subst_NS_SS+ tab_noep$Nb_subst_NS_WW)/(tab_noep$Lg_seq*0.67*tab_noep$Br_lg))
#mean(c((tab_noep$Nb_subst_NS_SS/(tab_noep$Lg_seq*0.67*(tab_noep$GC12/100)*tab_noep$Br_lg)), (tab_noep$Nb_subst_NS_WW/(tab_noep$Lg_seq*0.67*(tab_noep$AT12/100)*tab_noep$Br_lg))))

# in branches with punctual episodes

tab_tri_ep <- read.csv("classification_episodes_ML/posterior_episodes_optimum_hydromyini.csv", header=T, sep=",") # load the table of episodes classification
colnames(tab_tri_ep) <- c("Gene", "Exon_ep", "Br_ep", "true_type", "post1", "post2", "post3", "GoF")
tab_tri_ep <- tab_tri_ep[tab_tri_ep$GoF > 0.2, ] # retrieve episodes with gof <= 0.2
tab_tri_ep$punctual <- ifelse(tab_tri_ep$post1 > tab_tri_ep$post2 & tab_tri_ep$post1 > tab_tri_ep$post3, "YES", "NO") # add information of if episode in punctual
tab_ep_punctual <- tab_tri_ep[tab_tri_ep$punctual=="YES", ] # keep only punctuals
exons_paralog <- read.csv("paralog_exons_hydromyini.txt", header=F)
exons_aln_error <- read.table("List_exons_error_aln.csv", header=T)
tab_ep_punctual <- tab_ep_punctual[!tab_ep_punctual$Exon %in% exons_paralog$V1, ] # retrieve paralog exons
tab_ep_punctual <- tab_ep_punctual[!tab_ep_punctual$Exon %in% exons_aln_error$Exon, ] # retrieve aln arror exons

# merge the table of punctual episodes with the table of informations on episodes
tab_ep_punctual <- merge(tab_ep_br_int, tab_ep_punctual, by=c("Exon_ep","Br_ep"))
# total number of punctual episodes
nrow(tab_ep_punctual)	
# number of punctual episodes with at least 1 NS-WS
nrow(tab_ep_punctual[tab_ep_punctual$Nb_subst_NS_WS > 0.9, ])
# number of punctual episodes without NS-WS
nrow(tab_ep_punctual[tab_ep_punctual$Nb_subst_NS_WS < 0.1, ])

# mean number of substitutions
mean(tab_ep_punctual$Nb_subst_S_WS)
#mean(tab_ep_punctual$Nb_subst_S_WS/(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg))
#mean(tab_ep_punctual$Nb_subst_S_WS/(tab_ep_punctual$Lg_seq*0.33*(tab_ep_punctual$AT3/100)*tab_ep_punctual$Br_lg))
mean(tab_ep_punctual$Nb_subst_S_SW)
#mean(tab_ep_punctual$Nb_subst_S_SW/(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg))
#mean(tab_ep_punctual$Nb_subst_S_SW/(tab_ep_punctual$Lg_seq*0.33*(tab_ep_punctual$GC3/100)*tab_ep_punctual$Br_lg))
mean(tab_ep_punctual$Nb_subst_S_SS+tab_ep_punctual$Nb_subst_S_WW)
#mean((tab_ep_punctual$Nb_subst_S_SS+ tab_ep_punctual$Nb_subst_S_WW)/(tab_ep_punctual$Lg_seq*0.33*tab_ep_punctual$Br_lg))
#mean(c((tab_ep_punctual$Nb_subst_S_SS/(tab_ep_punctual$Lg_seq*0.33*(tab_ep_punctual$GC3/100)*tab_ep_punctual$Br_lg)), (tab_ep_punctual$Nb_subst_S_WW/(tab_ep_punctual$Lg_seq*0.33*(tab_ep_punctual$AT3/100)*tab_ep_punctual$Br_lg))))
mean(tab_ep_punctual$Nb_subst_NS_WS)
#mean(tab_ep_punctual$Nb_subst_NS_WS/(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg)) # 0.90
#mean(tab_ep_punctual$Nb_subst_NS_WS/(tab_ep_punctual$Lg_seq*0.67*(tab_ep_punctual$AT12/100)*tab_ep_punctual$Br_lg))
mean(tab_ep_punctual$Nb_subst_NS_SW)
#mean(tab_ep_punctual$Nb_subst_NS_SW/(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg)) # 0.24
#mean(tab_ep_punctual$Nb_subst_NS_SW/(tab_ep_punctual$Lg_seq*0.67*(tab_ep_punctual$GC12/100)*tab_ep_punctual$Br_lg))
mean(tab_ep_punctual$Nb_subst_NS_SS+ tab_ep_punctual$Nb_subst_NS_WW)
#mean(c(tab_ep_punctual$Nb_subst_NS_SS, tab_ep_punctual$Nb_subst_NS_WW))/#mean(tab_ep_punctual$Lg_seq*tab_ep_punctual$Br_lg) # 0.07
#mean(c((tab_ep_punctual$Nb_subst_NS_SS/(tab_ep_punctual$Lg_seq*0.67*(tab_ep_punctual$GC12/100)*tab_ep_punctual$Br_lg)), (tab_ep_punctual$Nb_subst_NS_WW/(tab_ep_punctual$Lg_seq*0.67*(tab_ep_punctual$AT12/100)*tab_ep_punctual$Br_lg))))


## S-WS in function of S-SW ## FIGURE 3 ##

# in branches without episodes

tab_pas_ep <- tab_sans_paralog[tab_sans_paralog$Episode != "YES", ]
nrow(tab_pas_ep)
tab_subset_pas_ep <- sample_n(tab_pas_ep, 100000) # tab of a random sample for the plot

plot_pas_ep <- ggplot(tab_subset_pas_ep, aes(x=Nb_subst_S_SW/(0.33*Lg_seq*(GC3/100)), y=Nb_subst_S_WS/(0.33*Lg_seq*(AT3/100)))) +
  geom_point(color="grey",size=2, alpha=0.5) +
  xlim(0,0.5) +
  ylim(0,0.5) +
  theme_linedraw() +
  xlab("dS(SW)") +
  ylab("dS(WS)") +
  ggtitle("No episode") +
  geom_abline(slope=1, intercept = 0) +
  theme(plot.title = element_text(hjust = 0.5))
plot_pas_ep

# in branches with all types of episodes

tab_all_ep <- tab_sans_paralog[tab_sans_paralog$Episode == "YES", ]
nrow(tab_all_ep)
tab_subset_all_ep <- sample_n(tab_all_ep, 1000)

plot_all_ep <- ggplot(tab_subset_all_ep, aes(x=Nb_subst_S_SW/(0.33*Lg_seq*(GC3/100)), y=Nb_subst_S_WS/(0.33*Lg_seq*(AT3/100)))) +
  geom_point(color="red",size=2, alpha=0.5) +
  xlim(0,0.5) +
  ylim(0,0.5) +
  theme_linedraw() +
  xlab("dS(SW)") +
  ylab("dS(WS)") +
  ggtitle("All episodes") +
  geom_abline(slope=1, intercept = 0) +
  theme(plot.title = element_text(hjust = 0.5))
plot_all_ep

# in branches with punctual episodes
tab_tri_ep <- read.csv("classification_episodes_ML/posterior_episodes_optimum_hydromyini.csv", header=T, sep=",")
colnames(tab_tri_ep) <- c("Gene", "Exon_ep", "Br_ep", "true_type", "post1", "post2", "post3", "GoF")
tab_tri_ep <- tab_tri_ep[tab_tri_ep$GoF > 0.2, ] # retrieve lines with gof <= 0.2
tab_tri_ep$punctual <- ifelse(tab_tri_ep$post1 > tab_tri_ep$post2 & tab_tri_ep$post1 > tab_tri_ep$post3, "YES", "NO") # add a column of is the episode punctual
tab_sans_paralog_tri_ep <- merge(tab_sans_paralog, tab_tri_ep, by=c("Exon_ep", "Br_ep"), all.x=TRUE) # merge this table with the general informations table
tab_sans_paralog_tri_ep$punctual <- ifelse(is.na(tab_sans_paralog_tri_ep$punctual), "NO", tab_sans_paralog_tri_ep$punctual) # fill the NA with NO in the column of is the episode punctual
tab_ep_punctual <- tab_sans_paralog_tri_ep[tab_sans_paralog_tri_ep$punctual == "YES", ] # keep only the lines with punctual episodes
tab_subset_ep_punctual <- sample_n(tab_ep_punctual, 300) # take a random sample of this table

plot_ep_punctual <- ggplot(tab_subset_ep_punctual, aes(x=Nb_subst_S_SW/(0.33*Lg_seq*(GC3/100)), y=Nb_subst_S_WS/(0.33*Lg_seq*(AT3/100)))) +
  geom_point(color="red", size=2, alpha=0.5) +
  xlim(0,0.5) +
  ylim(0,0.5) +
  theme_linedraw() +
  xlab("dS(SW)") +
  ylab("dS(WS)") +
  ggtitle("Punctual episodes") +
  geom_abline(slope=1, intercept = 0) +
  theme(plot.title = element_text(hjust = 0.5))
plot_ep_punctual

plot_final <- ggarrange(plot_pas_ep, plot_all_ep, plot_ep_punctual, ncol=3)
plot_final

ggsave("~/Documents/Thèse/Projet_murinae/Figures/resultats_generaux/hydromyini/plot_SWS_fct_SSW_V2.png", plot_final, width=8, height = 2.5)





### compensation analyses ###

## Episode classification

tab_tri_ep <- read.csv("classification_episodes_ML/posterior_episodes_optimum_hydromyini.csv", header=T, sep=",")
colnames(tab_tri_ep) <- c("Gene", "Exon_ep", "Br_ep", "true_type", "post1", "post2", "post3", "GoF")
# retrieve paralog exonx and aln with potential error
exons_paralog <- read.csv("paralog_exons_hydromyini.txt", header=F)
exons_aln_error <- read.table("List_exons_error_aln.csv", header=T)
tab_tri_ep <- tab_tri_ep[!tab_tri_ep$Exon %in% exons_paralog$V1, ]
tab_tri_ep <- tab_tri_ep[!tab_tri_ep$Exon %in% exons_aln_error$Exon, ]
# retrieve episodes with gof < 0.2
tab_tri_ep <- tab_tri_ep[tab_tri_ep$GoF > 0.2, ]
# table of punctual episodes
tab_ep_ponctual <- subset(tab_tri_ep, post1 > post2 & post1 > post3)
# table of two-branches episodes
tab_ep_twobr <- subset(tab_tri_ep, post2 > post1 & post2 > post3)
# table of all-exons episodes
tab_ep_allex <- subset(tab_tri_ep, post3 > post1 & post3 > post2)


## test for compensation ## FIGURE 5 ##

# NS after episodes with at least 1 NS-WS #

## WS

# load table
tab_random_NS_WS_postepNS <- read.csv("tab_analyse_randomNS_hydromyini/tab_all_genes/tab_NS_WS_after_epNS_with_random.csv", header=T, sep=',')
colnames(tab_random_NS_WS_postepNS) <- c(c("Exon_ep", "dNdS", "Lg_seq", "GC12", "GC3", "Br"," Br_lg", "Episode", "Nb_subst_S_WS", "Nb_subst_NS_WS"), as.character(seq(1,1000)), "Br_ep", "Br_asc_lg", "Ep_uniq")

# retrive lines where there is an episode
tab_random_NS_WS_postepNS <- tab_random_NS_WS_postepNS[tab_random_NS_WS_postepNS$Episode != 'YES', ]

# select a type of episode
tab_random_NS_WS_postepNS <- merge(tab_ep_ponctual, tab_random_NS_WS_postepNS, by = c("Exon_ep", "Br_ep")) # punctual
tab_random_NS_WS_postepNS <- merge(tab_ep_twobr, tab_random_NS_WS_postepNS, by = c("Exon_ep", "Br_ep")) # two-branches
tab_random_NS_WS_postepNS <- merge(tab_ep_allex, tab_random_NS_WS_postepNS, by = c("Exon_ep", "Br_ep")) # all-exons

# count nunber of episodes
tab_count_ep <- tab_random_NS_WS_postepNS[, c("Exon_ep", "Br_ep")]
nrow(distinct(tab_count_ep))

# sum all the NS substitutions observed in post-episode branches
nb_NS_WS_obs_tot_postepNS <- sum(tab_random_NS_WS_postepNS$Nb_subst_NS_WS)

# sum all of the NS substitutions expected in post-episode branches, for each of the 1000 randomisations (it gives a vector of 1000 values)
distrib_nb_NS_att_WS_postepNS <- as.data.frame(colSums(tab_random_NS_WS_postepNS[, 18:1017]))
colnames(distrib_nb_NS_att_WS_postepNS) <- c("WS")

# p-value
(1000-sum(nb_NS_WS_obs_tot_postepNS > distrib_nb_NS_att_WS_postepNS$WS))/1000 # if excess
(1000-sum(nb_NS_WS_obs_tot_postepNS < distrib_nb_NS_att_WS_postepNS$WS))/1000 # if deficit

## SW

# load table
tab_random_NS_SW_postepNS <- read.csv("tab_analyse_randomNS_hydromyini/tab_all_genes/tab_NS_SW_after_epNS_with_random.csv", header=T, sep=',')
colnames(tab_random_NS_SW_postepNS) <- c(c("Exon_ep", "dNdS", "Lg_seq", "GC12", "GC3", "Br"," Br_lg", "Episode", "Nb_subst_S_WS", "Nb_subst_NS_SW"), as.character(seq(1,1000)), "Br_ep", "Br_asc_lg", "Ep_uniq")

# retrive lines where there is an episode
tab_random_NS_SW_postepNS <- tab_random_NS_SW_postepNS[tab_random_NS_SW_postepNS$Episode != 'YES', ]

# select a type of episode
tab_random_NS_SW_postepNS <- merge(tab_ep_ponctual, tab_random_NS_SW_postepNS, by = c("Exon_ep", "Br_ep")) # punctual
tab_random_NS_SW_postepNS <- merge(tab_ep_twobr, tab_random_NS_SW_postepNS, by = c("Exon_ep", "Br_ep")) # two-branches
tab_random_NS_SW_postepNS <- merge(tab_ep_allex, tab_random_NS_SW_postepNS, by = c("Exon_ep", "Br_ep")) # all-exons

# count nunber of episodes
tab_count_ep <- tab_random_NS_SW_postepNS[, c("Exon_ep", "Br_ep")]
nrow(distinct(tab_count_ep))

# sum all the NS substitutions observed in post-episode branches
nb_NS_SW_obs_tot_postepNS <- sum(tab_random_NS_SW_postepNS$Nb_subst_NS_SW)

# sum all of the NS substitutions expected in post-episode branches, for each of the 1000 randomisations (it gives a vector of 1000 values)
distrib_nb_NS_att_SW_postepNS <- as.data.frame(colSums(tab_random_NS_SW_postepNS[, 18:1017]))
colnames(distrib_nb_NS_att_SW_postepNS) <- c("SW")

# p-value
(1000-sum(nb_NS_SW_obs_tot_postepNS > distrib_nb_NS_att_SW_postepNS$SW))/1000 # if excess
(1000-sum(nb_NS_SW_obs_tot_postepNS < distrib_nb_NS_att_SW_postepNS$SW))/1000 # if deficit

## SS

# load table
tab_random_NS_SS_postepNS <- read.csv("tab_analyse_randomNS_hydromyini/tab_all_genes/tab_NS_SS_after_epNS_with_random.csv", header=T, sep=',')
colnames(tab_random_NS_SS_postepNS) <- c(c("Exon_ep", "dNdS", "Lg_seq", "GC12", "GC3", "Br"," Br_lg", "Episode", "Nb_subst_S_WS", "Nb_subst_NS_SS"), as.character(seq(1,1000)), "Br_ep", "Br_asc_lg", "Ep_uniq")

# retrive lines where there is an episode
tab_random_NS_SS_postepNS <- tab_random_NS_SS_postepNS[tab_random_NS_SS_postepNS$Episode != 'YES', ]

# select a type of episode
tab_random_NS_SS_postepNS <- merge(tab_ep_ponctual, tab_random_NS_SS_postepNS, by = c("Exon_ep", "Br_ep")) # punctual
tab_random_NS_SS_postepNS <- merge(tab_ep_twobr, tab_random_NS_SS_postepNS, by = c("Exon_ep", "Br_ep")) # two-branches
tab_random_NS_SS_postepNS <- merge(tab_ep_allex, tab_random_NS_SS_postepNS, by = c("Exon_ep", "Br_ep")) # all-exons

# count nunber of episodes
tab_count_ep <- tab_random_NS_SS_postepNS[, c("Exon_ep", "Br_ep")]
nrow(distinct(tab_count_ep))

# sum all the NS substitutions observed in post-episode branches
nb_NS_SS_obs_tot_postepNS <- sum(tab_random_NS_SS_postepNS$Nb_subst_NS_SS)

# sum all of the NS substitutions expected in post-episode branches, for each of the 1000 randomisations (it gives a vector of 1000 values)
distrib_nb_NS_att_SS_postepNS <- as.data.frame(colSums(tab_random_NS_SS_postepNS[, 18:1017]))
colnames(distrib_nb_NS_att_SS_postepNS) <- c("SS")

## WW

# load table
tab_random_NS_WW_postepNS <- read.csv("tab_analyse_randomNS_hydromyini/tab_all_genes/tab_NS_WW_after_epNS_with_random.csv", header=T, sep=',')
colnames(tab_random_NS_WW_postepNS) <- c(c("Exon_ep", "dNdS", "Lg_seq", "GC12", "GC3", "Br"," Br_lg", "Episode", "Nb_subst_S_WS", "Nb_subst_NS_WW"), as.character(seq(1,1000)), "Br_ep", "Br_asc_lg", "Ep_uniq")

# retrive lines where there is an episode
tab_random_NS_WW_postepNS <- tab_random_NS_WW_postepNS[tab_random_NS_WW_postepNS$Episode != 'YES', ]

# select a type of episode
tab_random_NS_WW_postepNS <- merge(tab_ep_ponctual, tab_random_NS_WW_postepNS, by = c("Exon_ep", "Br_ep")) # punctual
tab_random_NS_WW_postepNS <- merge(tab_ep_twobr, tab_random_NS_WW_postepNS, by = c("Exon_ep", "Br_ep")) # two-branches
tab_random_NS_WW_postepNS <- merge(tab_ep_allex, tab_random_NS_WW_postepNS, by = c("Exon_ep", "Br_ep")) # all-exons

# count nunber of episodes
tab_count_ep <- tab_random_NS_WW_postepNS[, c("Exon_ep", "Br_ep")]
nrow(distinct(tab_count_ep))

# sum all the NS substitutions observed in post-episode branches
nb_NS_WW_obs_tot_postepNS <- sum(tab_random_NS_WW_postepNS$Nb_subst_NS_WW)

# sum all of the NS substitutions expected in post-episode branches, for each of the 1000 randomisations (it gives a vector of 1000 values)
distrib_nb_NS_att_WW_postepNS <- as.data.frame(colSums(tab_random_NS_WW_postepNS[, 18:1017]))
colnames(distrib_nb_NS_att_WW_postepNS) <- c("WW")

## SS+WW
# observed
nb_NS_SSWW_obs_tot_postepNS <- nb_NS_SS_obs_tot_postepNS + nb_NS_WW_obs_tot_postepNS
# expected
tot_NS_att_SSWW_postepNS <- as.data.frame(distrib_nb_NS_att_SS_postepNS + distrib_nb_NS_att_WW_postepNS)
colnames(tot_NS_att_SSWW_postepNS) <- c("SSWW")
# p-value
(1000-sum(nb_NS_SSWW_obs_tot_postepNS > tot_NS_att_SSWW_postepNS))/1000 # if excess
(1000-sum(nb_NS_SSWW_obs_tot_postepNS < tot_NS_att_SSWW_postepNS))/1000 # if deficit

## total NS = WS+SW+SSWW
# observed
tot_NS_obs_postepNS <- nb_NS_WS_obs_tot_postepNS + nb_NS_SW_obs_tot_postepNS + nb_NS_SSWW_obs_tot_postepNS
# expected
tot_NS_att_postepNS <- as.data.frame(distrib_nb_NS_att_WS_postepNS + distrib_nb_NS_att_SW_postepNS + distrib_nb_NS_att_WW_postepNS + distrib_nb_NS_att_SS_postepNS)
colnames(tot_NS_att_postepNS) <- c("total")
# p-value
(1000-sum(tot_NS_obs_postepNS > tot_NS_att_postepNS$total))/1000 # if excess
1000-sum(tot_NS_obs_postepNS < tot_NS_att_postepNS$total))/1000 # if deficit

## plots
# WS
plot_NS_WS_ponctual <- ggplot(distrib_nb_NS_att_WS_postepNS, aes(WS)) +
  geom_density(color="black", fill="coral2", size=0.3) +
  geom_vline(xintercept = nb_NS_WS_obs_tot_postepNS, color = "black", size=0.6) +
  xlab("") +
  ylab("density") +
  theme_linedraw() +
  theme(axis.title.x = element_text(size = 10), axis.title.y = element_text(size=10))
plot_NS_WS_ponctual
# SW
plot_NS_SW_ponctual <- ggplot(distrib_nb_NS_att_SW_postepNS, aes(SW)) +
  geom_density(color="black", fill="cornflowerblue", size=0.3) +
  geom_vline(xintercept = nb_NS_SW_obs_tot_postepNS, color = "black", size=0.6) +
  xlab("") +
  ylab("") +
  theme_linedraw() +
  theme(axis.title.x = element_text(size = 10), axis.title.y = element_text(size=10)) 
plot_NS_SW_ponctual
# SSWW
plot_NS_SSWW_ponctual <- ggplot(tot_NS_att_SSWW_postepNS, aes(SSWW)) +
  geom_density(color="black", fill="darkseagreen", size=0.3) +
  geom_vline(xintercept = nb_NS_SSWW_obs_tot_postepNS, color = "black", size=0.6) +
  xlab("") +
  ylab("") +
  theme_linedraw() +
  theme(axis.title.x = element_text(size = 10), axis.title.y = element_text(size=10)) 
plot_NS_SSWW_ponctual
# Total (WS+SW+SSWW)
plot_NS_tot_ponctual <- ggplot(tot_NS_att_postepNS, aes(total)) +
  geom_density(color="black", fill="plum3", size=0.3) +
  geom_vline(xintercept = tot_NS_obs_postepNS, color = "black", size=0.6) +
  xlab("") +
  ylab("density") +
  theme_linedraw() +
  theme(axis.title.x = element_text(size = 10), axis.title.y = element_text(size=10)) 
plot_NS_tot_ponctual
# merge all this plot
plot_NS_types_postepNS <- ggarrange(plot_NS_WS_ponctual, plot_NS_SW_ponctual, plot_NS_SSWW_ponctual, ncol = 3)
plot_NS_types_postepNS






































