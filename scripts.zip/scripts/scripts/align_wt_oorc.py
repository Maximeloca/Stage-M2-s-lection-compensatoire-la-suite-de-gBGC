### Install packages ###
import sys
import os
from Bio import SeqIO

## Vérification des arguments ###
if len(sys.argv) != 3:
    sys.exit("ERROR : need 2 arguments: [1]alignment [2]output folder path")

# Récupère les arguments
align = sys.argv[1]  # Fichier FASTA
out_folder = sys.argv[2]  # Dossier de sortie

# Création du nom du fichier de sortie
base_name = os.path.splitext(os.path.basename(align))[0]  # Récupère uniquement le nom du fichier sans extension
out_file_name = os.path.join(out_folder, f"{base_name}.fasta")  # Définit le fichier de sortie

# Stocke les séquences filtrées avant d'écrire le fichier
filtered_sequences = []
for seq_read in SeqIO.parse(align, "fasta"):
    seq_id = seq_read.id
    seq_seq = seq_read.seq
    if seq_id != "Oorc":  # Garde uniquement les séquences dont l'ID ne correspond pas à "Oorc"
        filtered_sequences.append(f">{seq_id}\n{seq_seq}\n")  # \n indique un saut de ligne

# Écrit uniquement si des séquences ont été trouvées
if filtered_sequences:  # Seulement si filtered_sequences n'est pas vide
    with open(out_file_name, "w") as out:
        out.writelines(filtered_sequences)
