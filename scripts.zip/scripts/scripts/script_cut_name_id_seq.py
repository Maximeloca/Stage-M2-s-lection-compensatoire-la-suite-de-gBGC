## Install packages ###
import sys
import os
from Bio import SeqIO

## Arguments ###
# Vérifie que le nombre d'arguments est correct
if len(sys.argv) != 4:
    sys.exit("ERROR : need 2 arguments: [1]alignment [2]output folder path")

# Récupère les arguments
align = sys.argv[1]  # fichier FASTA
out_folder = sys.argv[2]    # Dossier où enregistrer les fichiers modifiés
liste_fichier_sp_id = sys.argv[3]

# Crée le nom du fichier de sortie
base_name = os.path.splitext(align)[0]  #### Récupère le nom sans extension
out_file_name = os.path.join(out_folder, f"{base_name}_corrected.fasta") ###défini le fichier de sortie comme le basename_corrected.fasta

        # Ouvre le fichier de sortie et écrit les séquences modifiées
with open(out_file_name, "w") as out:
    for seq_read in SeqIO.parse(align, 'fasta'):
        seq_id = seq_read.id
        seq_seq = seq_read.seq
        SPECIE=$(grep -w ${seq_id} (liste_fichier_sp_id) | cut -f1)  # Récupère le nom de l'espèce
        new_id = SPECIE  # Garde uniquement les 4 premières lettres du nom
        out.write(f'>{new_id}\n')
        out.write(f'{seq_seq}\n')