#! /bin/bash

# Arguments ###

EXON=$1
TRIBE=$2
TH_LG=$3
TH_SIGNIF=$4

# Script ###

grep $EXON ~/${TRIBE}/Substitutions_mapping/exon_lenseq_mapping_ok.txt > ${EXON}_exons_lg_seq.csv

python3 ~/scripts/detection_episodes_cetace.py ${EXON}_exons_lg_seq.csv ~/${TRIBE}/Detecting_gBGC/Detection/signif_stat/ $TH_LG $TH_SIGNIF ${EXON}_episodes_detection.csv

rm ${EXON}_exons_lg_seq.csv
