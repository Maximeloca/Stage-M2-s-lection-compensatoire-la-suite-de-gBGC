#! /bin/bash

# Arguments ###

GENE=$1
TRIBE=$2

# Script ###

EXON=$(grep ${GENE} ~/Murinae/${TRIBE}/Substitutions_mapping/list_genes_exons_mapping_ok.txt | head -1 | cut -f2)
python3 ~/scripts/num_nodes_tree.py ~/Murinae/${TRIBE}/Substitutions_mapping/${EXON}_ml.dnd_1 ~/Murinae/${TRIBE}/Randomisations/Br_lg_tables/${GENE}_br_len.csv ${GENE}_rel_br.csv
#on prend la topologie de _ml.dnd_1 car c'est ceux là qui ont les numéros de branches et pas ceux d'iqtree
