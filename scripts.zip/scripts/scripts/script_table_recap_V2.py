## install packages ###
import sys
import pandas as pd

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 11:
    sys.exit("ERROR : need 10 arguments : [1]gene name [2]path to the table of gene and exon name and position of exon and length of sequences [3]path to the table of branches relations [4]path to the table of branch lengths [5]path to the table of WS episodes detection [6]directory of the tables of distrib subst S [7]directory of the tables of signif stat [8]directory of the tables of distrib subst NS [9]directory of the tables of GC content [10]csv out name")
    # recuperer les arguments
gene_name = sys.argv[1]
tab_exons_name_lg_path = sys.argv[2] #tableau gene, exon, position, longueur
tab_br_rel_path = sys.argv[3]
tab_br_len_path = sys.argv[4]
tab_ep_detection_path = sys.argv[5]
tab_distrib_substS_dir = sys.argv[6]
tab_signif_stat_dir = sys.argv[7] #tableau ou on voit quand est ce que c'est significatif ou non
tab_distrib_substNS_dir = sys.argv[8]
tab_GC_content_dir = sys.argv[9]
out_file_name = sys.argv[10]

## script ###

# read tables for the gene
tab_exons_name_lg = pd.read_csv(tab_exons_name_lg_path, sep='\t', header=None)
tab_exons_name_lg.columns = ["gene", "exon", "exon_position", "exon_length"]
tab_br_rel = pd.read_csv(tab_br_rel_path, sep='\t')
tab_br_len = pd.read_csv(tab_br_len_path, sep=',')
tab_ep_detection = pd.read_csv(tab_ep_detection_path, sep=',')

# number of branches
nb_br = len(tab_br_rel) #nombre de branches

# list exons
exons_list = list(tab_exons_name_lg[tab_exons_name_lg['gene'] == gene_name]['exon']) #crée une liste des exons associés au gènes

# get branches relations
br_num = list(tab_br_rel['Br_num'])
br_asc = list(tab_br_rel['Asc_Br'])
br_desc1 = list(tab_br_rel['Desc_Br_1'])
br_desc2 = list(tab_br_rel['Desc_Br_2'])

# get branches lengths
br_len = list(tab_br_len['lg']) #liste des longueurs de branches

# for each exon
for exon in exons_list:
    # get list of the exon name
    exon_name = [exon] * nb_br #on multiplie par le nb de branche car on aura plein de fois le nom de l'exon puisqu'on a plein de branches 
    # get exon position
    exon_position = tab_exons_name_lg[tab_exons_name_lg['exon'] == exon]['exon_position'].iloc[0]
    # get exon length
    lg_seq = tab_exons_name_lg[tab_exons_name_lg['exon'] == exon]['exon_length'].iloc[0]
    # get episodes
    episodes = list(tab_ep_detection[tab_ep_detection['Exon'] == exon]['Episode'])
    # get distrib subst S
    tab_distrib_substS_name = tab_distrib_substS_dir + exon + "_stat_nb_subst.csv"
    tab_distrib_substS = pd.read_csv(tab_distrib_substS_name, sep='\t')
    list_distrib_substS_WS = []
    list_distrib_substS_SW = []
    list_distrib_substS_WW = []
    list_distrib_substS_SS = []
    for br in range(0, nb_br): #pour chaque branche
        tab_br = tab_distrib_substS[tab_distrib_substS['branches'] == br] #ligne associé à la branche donc avec les SSW SWS, ...
        nb_subst_WS = tab_br['nb_subst_WS'].iloc[0]
        nb_subst_SW = tab_br['nb_subst_SW'].iloc[0]
        nb_subst_SS = tab_br['nb_subst_SS'].iloc[0]
        nb_subst_WW = tab_br['nb_subst_WW'].iloc[0]
        list_distrib_substS_WS.append(nb_subst_WS)
        list_distrib_substS_SW.append(nb_subst_SW)
        list_distrib_substS_SS.append(nb_subst_SS)
        list_distrib_substS_WW.append(nb_subst_WW)
    # get signif distrib substS WS
    tab_signif_stat_name = tab_signif_stat_dir + exon + "_tab_signif_stat.csv"
    tab_signif_stat = pd.read_csv(tab_signif_stat_name, sep=',')
    signif_distrib_substS = list(tab_signif_stat['signif_nb_WS'])
            
    
    # get distrib subst NS
    tab_distrib_substNS_name = tab_distrib_substNS_dir + exon + "_stat_nb_subst_NS.csv"
    tab_distrib_substNS = pd.read_csv(tab_distrib_substNS_name, sep='\t')
    distrib_substNS_WS = []
    distrib_substNS_SW =[]
    distrib_substNS_SS = []
    distrib_substNS_WW = []
    for br in range(0,nb_br):
        tab_br = tab_distrib_substNS[tab_distrib_substNS['branches'] == br]
        nb_subst_WS = tab_br['nb_subst_WS'].iloc[0]
        nb_subst_SW = tab_br['nb_subst_SW'].iloc[0]
        nb_subst_WW = tab_br['nb_subst_WW'].iloc[0]
        nb_subst_SS = tab_br['nb_subst_SS'].iloc[0]
        distrib_substNS_WS.append(nb_subst_WS)
        distrib_substNS_SW.append(nb_subst_SW)
        distrib_substNS_SS.append(nb_subst_SS)
        distrib_substNS_WW.append(nb_subst_WW)
    
    # get GC12 and GC3 contents
    tab_GC_content_name = tab_GC_content_dir + exon + "_GC_content.csv"
    tab_GC_content = pd.read_csv(tab_GC_content_name, sep='\t', header=None)
    tab_GC_content.columns = ["exon", "GC12", "GC3"]
    GC12 = tab_GC_content[tab_GC_content['exon'] == exon]['GC12'].iloc[0]
    GC3 = tab_GC_content[tab_GC_content['exon'] == exon]['GC3'].iloc[0]
    GC12_tab = [GC12] * nb_br #multiplie par le nb de branche car c'est qu'une valeur pour tout l'arbre
    GC3_tab = [GC3] * nb_br
    
    # make the table
    if exon == exons_list[0]: ###on commence par crée le tab_final car on ne peut pas concaténer tout
        tab_final = pd.DataFrame({'Exon': exon_name,
                             'exon_pos':exon_position,
                             'Lg_seq':lg_seq,
                             'GC12':GC12_tab,
                             'GC3':GC3_tab,
                             'Br':br_num,
                             'Br_lg': br_len,
                             'Br_Asc':br_asc,
                             'Br_Desc1':br_desc1,
                             'Br_Desc2':br_desc2,
                             'Episode':episodes,
                             'Nb_subst_S_WS':list_distrib_substS_WS,
                             'signif_nb_subst_S_WS':signif_distrib_substS,
                             'Nb_subst_S_SW': list_distrib_substS_SW,
                             'Nb_subst_S_WW': list_distrib_substS_WW,
                             'Nb_subst_S_SS': list_distrib_substS_SS,
                             'Nb_subst_NS_WS':distrib_substNS_WS,
                             'Nb_subst_NS_SW':distrib_substNS_SW,
                             'Nb_subst_NS_SS':distrib_substNS_SS,
                             'Nb_subst_NS_WW':distrib_substNS_WW})
    else:
        tab = pd.DataFrame({'Exon': exon_name,
                            'exon_pos':exon_position,
                            'Lg_seq':lg_seq,
                            'GC12':GC12_tab,
                            'GC3':GC3_tab,
                            'Br':br_num,
                            'Br_lg': br_len,
                            'Br_Asc':br_asc,
                            'Br_Desc1':br_desc1,
                            'Br_Desc2':br_desc2,
                            'Episode':episodes,
                            'Nb_subst_S_WS':list_distrib_substS_WS,
                            'signif_nb_subst_S_WS':signif_distrib_substS,
                            'Nb_subst_S_SW': list_distrib_substS_SW,
                            'Nb_subst_S_WW': list_distrib_substS_WW,
                            'Nb_subst_S_SS': list_distrib_substS_SS,
                            'Nb_subst_NS_WS':distrib_substNS_WS,
                            'Nb_subst_NS_SW':distrib_substNS_SW,
                            'Nb_subst_NS_SS':distrib_substNS_SS,
                            'Nb_subst_NS_WW':distrib_substNS_WW})
        tab_final = pd.concat([tab_final, tab], ignore_index=True)

tab_final.to_csv(out_file_name, sep='\t', index=False, na_rep='NA')
