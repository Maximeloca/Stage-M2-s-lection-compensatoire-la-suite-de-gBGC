mkdir tab_all_genes

for file in *_tab_S_WS_after_ep.csv ; do sed 1d $file ; done > tab_all_genes/tab_S_WS_after_ep.csv
for file in *_tab_S_SW_after_ep.csv ; do sed 1d $file ; done > tab_all_genes/tab_S_SW_after_ep.csv
for file in *_tab_S_SS_after_ep.csv ; do sed 1d $file ; done > tab_all_genes/tab_S_SS_after_ep.csv
for file in *_tab_S_WW_after_ep.csv ; do sed 1d $file ; done > tab_all_genes/tab_S_WW_after_ep.csv

for file in *_tab_S_WS_during_ep_otherexons.csv ; do sed 1d $file ; done > tab_all_genes/tab_S_WS_during_ep_otherexons.csv
for file in *_tab_S_SW_during_ep_otherexons.csv ; do sed 1d $file ; done > tab_all_genes/tab_S_SW_during_ep_otherexons.csv
for file in *_tab_S_SS_during_ep_otherexons.csv ; do sed 1d $file ; done > tab_all_genes/tab_S_SS_during_ep_otherexons.csv
for file in *_tab_S_WW_during_ep_otherexons.csv ; do sed 1d $file ; done > tab_all_genes/tab_S_WW_during_ep_otherexons.csv
