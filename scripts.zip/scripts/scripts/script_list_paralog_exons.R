#!/usr/bin/env Rscript

args = commandArgs(trailingOnly=TRUE)
print(args)

if (length(args)<1) {
  stop("1 arguments must be supplied : [1] path to the tab of trees lengths for the supplementary filter of paralogs", call.=FALSE)
}

tab_path = args[1]

library(tidyr)

tab <- read.table(tab_path, header=F, sep="\t")
colnames(tab) <- c("gene", "exon","lg_seq","lg_arbre_G", "lg_arbre_E")
tab <-tab %>% drop_na() #on enlève les na car on a des arbres ou on a pas assez d'info dans les séquences donc on a rien

tab$LGsurLE <- tab$lg_arbre_G/tab$lg_arbre_E
##on crée une colonne ou on divise la somme de la longueur des branches de l'arbre général divisé sur la longueur des branches de l'arbre des exons 

tab_1.5 <- tab[tab$LGsurLE > 1.5, ] ###1.5 est un seuil permettant de détecter les paralogies si on est au dessus on considère que les deux arbres sont discordants et que l'exon est donc un paralogue 

paralog_exons <- tab_1.5$exon

write.table(paralog_exons, file="paralog_exons.txt", row.names=F, col.names=F, quote=F)