### Install packages ###
import sys
import os
from Bio import SeqIO

## Vérification des arguments ###
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments: [1]alignment [2]output folder path [3]id_list file")

# Récupère les arguments
align = sys.argv[1]  # Fichier FASTA
out_folder = sys.argv[2]  # Dossier de sortie
id_file = sys.argv[3]  # Fichier contenant les identifiants

# Lecture de la liste des identifiants Delphinidae
with open(id_file, "r") as f:
    id_list = {line.strip() for line in f}  #line.strip, permet d'enlever les espaces et les sauts de lignes inutiles 

# Création du nom du fichier de sortie
base_name = os.path.splitext(os.path.basename(align))[0]  # Récupère uniquement le nom du fichier sans extension, ca va split en deux en mode 'nom_fichier' '.fasta' et vu qu'on récupère que le nom_fichier on met [0]
out_file_name = os.path.join(out_folder, f"{base_name}.fasta")  # Définit le fichier de sortie, chemin + nom du fichier

# Stocke les séquences filtrées avant d'écrire le fichier
filtered_sequences = []
for seq_read in SeqIO.parse(align, "fasta"):
    seq_id = seq_read.id
    seq_seq = seq_read.seq
    if seq_id in id_list: #garde uniquement les séquences dont l'ID figure dans la liste des id 
        filtered_sequences.append(f">{seq_id}\n{seq_seq}\n") #\n indique un saut de ligne 

# Écrit uniquement si des séquences ont été trouvées
if filtered_sequences: #seulement si filtered_sequences n'est pas vide 
    with open(out_file_name, "w") as out:
        out.writelines(filtered_sequences)
