import pandas as pd
import re

text = """Peponocephala_electra=[Pele], Balaenoptera_musculus=[Bmus49099], Inia_geoffrensis=[Igeo], Stenella_coeruleoalba=[Scoe], Balaenoptera_acutorostrata=[Bacu], Cephalorhynchus_heavisidii=[Chea7320], Lagenorhynchus_australis=[Laus], Kogia_brevirostris=[Kbre], Balaenoptera_edeni=[BedeAUS, Bede66737], Lipotes_vexillifer=[Lvex], Mesoplodon_perrini=[Mpni], Steno_bredanensis=[Sbre116871, Sbre18437], Bos_taurus=[Btau], Orcaella_brevirostris=[Obre], Tursiops_truncatus=[Ttru], Lagenodelphis_hosei=[Lhos452, Lhos30470], Physeter_macrocephalus=[Pmac], Ovis_aries=[Oari], Phocoena_phocoena=[Ppho], Globicephala_melas=[Gmel], Feresa_attenuata=[Fatt], Orcaella_heinsohnii=[Ohei], Balaenoptera_physalus=[Bphy_baits, Bphy], Mesoplodon_hectori=[Mhec], Lagenorhynchus_obscurus=[Lobs], Neophocaena_phocaenoides=[Npho], Balaenoptera_borealis=[Bbor], Phocoenoides_dalli=[Pdal], Mesolpodon_stejnegeri=[Mste], Vicugna_pacos=[Vpac], Orcinus_orca=[Oorc], Delphinapterus_leucas=[Dleu], Balaenoptera_bonaerensis=[BbonAUS], Equus_caballus=[Ecab], Gazella_arabica=[Gaar], Eubalaena_japonica=[Ejap43864], Hippopotamus_amphibius=[Hippo], Eubalaena_glacialis=[Egla13086], Grampus_griseus=[Ggri], Eubalaena_australis=[EausAUS], Sotalia_guianensis=[Sflu9837], Kogia_sima=[Ksim], Hyperoodon_ampullatus=[Hamp], Mesoplodon_bowdoini=[Mbow], Berardius_bairdii=[Bbai76728], Sus_scrofa=[Sscr], Stenella_clymene=[Scly1726, Scly1724], Lagenorhynchus_acutus=[Lacu], Balaena_mysticetus=[Bmys], Lissodelphis_peroni=[LperAUS], Lagenorhynchus_obliquidens=[Lobl], Phocoena_spinnipinis=[Pspi], Mesoplodon_carlhubbsi=[Mcar], Mesoplodon_grayii=[MgraAUS], Mesoplodon_gingkodens=[Mgin], Mesoplodon_densirostris=[Mden], Eschrictius_robustus=[Erob133443], Panthalops_hodgsonii=[Phod], Oryx_leucoryx=[Orle], Monodon_monoceros=[Mmon], Pontoporia_blainvillei=[Pbla7349], Caperea_marginata=[Cmar59905], Mesoplodon_layardi=[MlayAUS], Stenella_frontalis=[Sfro7782, Sfro7784], Camelus_bactrianus=[Cbac], Berardius_arnouxii=[Barn], Choeropsis_liberiensis=[Clib], Megaptera_novaeangliae=[Mnov], Lissodelphis_borealis=[Lbor], Mesoplodon_europaeus=[Meur], Mesoplodon_bidens=[Mbid], Globicephala_macrorhynchus=[Gmac39091], Stenella_attenuata=[Satt38219, Satt18473], Mesoplodon_peruvianus=[Mper], Lagenorhynchus_albirostris=[Lalb], Stenella_longirostris=[Slon24923, Slon16012], Sousa_chinensis=[Schi], Tursiops_aduncus=[Tadu79924], Pseudorca_crassidens=[Pcra123188], Ziphius_cavirostris=[Zcav], Phocoena_dioptrica=[Pdio], Tragelaphus_eurycerus=[Treu2], Tasmacetus_shepherdi=[Tshe], Cephalorhynchus_commersoni=[Ccom40], Hyperoodon_planifrons=[Hpla9120], Delphinus_delphis=[Dcap108471, Dcap79929, Ddeltrop4525, DdelSJR], Mesoplodon_mirus=[Mmir]"""

# Extraction des noms d'espèces et des identifiants
matches = re.findall(r'(\w+)=\[([^\]]+)\]', text)

# Création du tableau
species_list = []
identifiers_list = []

for species, identifiers in matches:
    for identifier in identifiers.split(', '):
        species_list.append(species)
        identifiers_list.append(identifier)

# Création du DataFrame
df = pd.DataFrame({'Species': species_list, 'Identifier': identifiers_list})

# Affichage du tableau
print(df)

# Sauvegarde en TSV sans noms de colonnes
df.to_csv("tab_species_id.csv", index=False, sep='\t', quoting=3, header=False)

