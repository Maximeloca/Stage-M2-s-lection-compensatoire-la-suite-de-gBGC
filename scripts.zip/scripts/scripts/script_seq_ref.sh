#! /bin/bash

# parametres ##

exon=$1

# script ##

# recuperer nom seq exon ref
grep -w $exon ~/Murinae/Reference_exons/Mouse_exons_ref_coding_seq_lgmin100.fasta > ${exon}_seqname.txt
sed -i 's/>//g' ${exon}_seqname.txt
# récupérer seq de l'exon ref
seqkit grep -n -f ${exon}_seqname.txt ~/Murinae/Reference_exons/Mouse_exons_ref_coding_seq_lgmin100.fasta -o ${exon}_seq_ref.fasta
