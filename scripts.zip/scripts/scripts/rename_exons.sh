#!/bin/bash

# Fichier contenant les métadonnées
metadata_file="metadata.tsv"

# Dossiers contenant les fichiers fasta et destination
fasta_source_dir="~/Donnees_Cetaces/Baits_Genes_Corrected"
fasta_dest_dir="~/Cetacea/Sequence"



# Trier les exons par gène et position génomique, puis attribuer un numéro d’ordre
sort -k3,3 -k1,1V "$metadata_file" | awk -F'\t' '
    {
        gene_id = $3
        exon_position = $1
        exon_name = $1

        gsub("_test.fa", "", exon_name)
        if (gene_id in count) {
            count[gene_id]++
        } else {
            count[gene_id] = 1
        }
        printf "%s\t%s\t%d\n", exon_name, gene_id, count[gene_id]
    }
' > sorted_exons.csv