#!/bin/bash

EXON=$1

# Utilisation de find pour récupérer le CDS à partir du nom de l'exon
#CDS=$(find -maxdepth 1 -type f -name "$EXON" | cut -f2 -d"=" | cut -f1 -d"_" | cut -f2 -d"/")
CDS=$(basename "$EXON" | cut -d"=" -f2 | cut -d"_" -f1)


# Affichage de l'exon et du CDS dans un fichier CSV
echo -e "$EXON\t$CDS", header  = Exon , Gene >> tab_exon_cds.csv