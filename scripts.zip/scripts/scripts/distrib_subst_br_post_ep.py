import sys
import pandas as pd

# Vérification des arguments
if len(sys.argv) != 5:
    sys.exit("Usage : [1]gene_name [2]tab_recap_dir [3]tab_randomNS_dir [4]paralogs_list_file")

# Récupération des arguments
gene_name = sys.argv[1]
tab_recap_dir = sys.argv[2]
tab_randomNS_dir = sys.argv[3]
paralogs_list_file = sys.argv[4]

# Lire la liste des exons paralogiques
with open(paralogs_list_file, "r") as f:
    paralogs_list = f.read().strip().split()

# Lire le tableau récapitulatif
tab_recap_path = f"{tab_recap_dir}_tab_recap.csv"
tab_recap = pd.read_csv(tab_recap_path, sep="\t")

# Retirer les exons paralogiques
tab_recap = tab_recap[~tab_recap["Exon"].isin(paralogs_list)]

# Garder les lignes correspondant à des épisodes 
tab_ep = tab_recap[(tab_recap["Episode"] == "YES") & (pd.notna(tab_recap["Br_Asc"])) & (pd.notna(tab_recap["Br_Desc1"]))]

# Sélectionner les colonnes utiles
tab_ep_final = tab_ep[["Exon", "Br", "Nb_subst_NS_WS"]]

tab_ep_final.to_csv(gene_name + '_tab_NS.csv', index=False)

