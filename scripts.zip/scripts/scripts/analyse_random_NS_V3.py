## install packages ###
import sys
import pandas as pd
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 5:
    sys.exit("ERROR : need 4 arguments : [1]gene name [2]directory of the tab recap [3]directory of the tab random NS [4]list of paralogs exons")
# recuperer les arguments
gene_name = sys.argv[1]
tab_recap_dir = sys.argv[2]
tab_randomNS_dir = sys.argv[3]
paralogs_list_file = sys.argv[4]

## script ###

# get the paralogs list
with open(paralogs_list_file, "r") as file_paralogs_list:
    file_paralogs_list_read = file_paralogs_list.read().strip()
    paralogs_list = file_paralogs_list_read.split()

gene = gene_name
print(gene)
# read the table
tab_recap_name = tab_recap_dir + gene + "_tab_recap.csv"
tab_recap_with_paralogs = pd.read_csv(tab_recap_name, sep='\t')
    
# remove paralogs exons
tab_recap = tab_recap_with_paralogs[~tab_recap_with_paralogs.Exon.isin(paralogs_list)]

# list of exons
exons_list = list(tab_recap['Exon'])
exons_list = set(exons_list) # equivalent of uniq
exons_list = list(exons_list) # equivalent of uniq
print(exons_list)
    
# list of exons with episodes
exons_episodes = list(tab_recap[(tab_recap['Episode'] == 'YES') & (pd.notna(tab_recap['Br_Asc']))]['Exon'])
exons_episodes = set(exons_episodes) # equivalent of uniq
exons_episodes = list(exons_episodes) # equivalent of uniq
print(exons_episodes)


exons_post_epNS = []
exons_post_epnoNS = []

exons_otherex_durepNS = []
otherex_otherex_durepNS = []
exons_otherex_durepnoNS = []
otherex_otherex_durepnoNS = []

exons_otherex_postepNS = []
otherex_otherex_postepNS = []
exons_otherex_postepnoNS = []
otherex_otherex_postepnoNS = []

for exon in exons_list:
    print(exon)
    # list other exons of the same gene
    other_exons_list = list(exons_list)
    other_exons_list.remove(exon)
    # list of branches with episodes
    tab_exon = tab_recap[tab_recap['Exon'] == exon]
    pos_exon = int(list(tab_exon['exon_pos'])[0])
    print(pos_exon)
    tab_exon_ep = tab_exon[(tab_exon['Episode'] == 'YES') & (pd.notna(tab_exon['Br_Asc'])) & (pd.notna(tab_exon['Br_Desc1']))]
    br_ep = list(tab_exon_ep['Br'])
    print(br_ep)   
            
    ##### NS after the episodes with at least 1 subst NS WS #####
    # list of the branches after the episodes NS & no episode in these branches
    tab_exon_epNS = tab_exon_ep[tab_exon_ep['Nb_subst_NS_WS'] > 0.9]
    br_epNS = list(tab_exon_epNS['Br'])
    print(br_epNS)
    br_postepNS = []
    ep_uniq_exon = []
    for br in br_epNS:
        br_desc1 = tab_exon[tab_exon['Br'] == br]['Br_Desc1'].iloc[0]
        br_desc2 = tab_exon[tab_exon['Br'] == br]['Br_Desc2'].iloc[0]
        br_postepNS.append(br_desc1)
        br_postepNS.append(br_desc2)
        # counter of nb ep in same br of other ex initiates at zero 
        nb_ep_other_ex = 0
        # search if ep in same br in other ex
        for other_exon in other_exons_list:
            tab_other_exon = tab_recap[tab_recap['Exon'] == other_exon]
            pval = tab_other_exon[tab_other_exon['Br'] == br]['signif_nb_subst_S_WS'].iloc[0]
            if pval > 200:
                nb_ep_other_ex += 1
        if nb_ep_other_ex > 0:
            ep_uniq_exon.append('NO')
            ep_uniq_exon.append('NO')
        else:
            ep_uniq_exon.append('YES')
            ep_uniq_exon.append('YES')
    print(br_postepNS)
    print(ep_uniq_exon)
    if br_postepNS:
        exons_post_epNS.append(exon)
        # tab of br asc br desc ep (=br ep), lg br asc br desc ep (=br ep), and br br desc ep 
        br_post_list = []
        br_asc_list = []
        br_asc_lg_list = []
        for br in br_postepNS:
            br_asc = tab_exon[tab_exon['Br'] == br]['Br_Asc'].iloc[0]
            br_asc_lg = tab_exon[tab_exon['Br'] == br_asc]['Br_lg'].iloc[0]
            br_post_list.append(br)
            br_asc_list.append(br_asc)
            br_asc_lg_list.append(br_asc_lg)
        tab_br_asc_lg = pd.DataFrame({'Br': br_post_list,
        				'Br_asc': br_asc_list,
        				'Br_asc_lg': br_asc_lg_list,
        				'Ep_uniq_exon': ep_uniq_exon})
        # tab of exon with theses branches
        tab_exon_postepNS = tab_exon[tab_exon['Br'].isin(br_postepNS)]
        # observed nb of subst NS WS after the episodes
        tab_nb_obs_NS_WS_after_epNS = tab_exon_postepNS[['Exon', 'dNdS',  'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
        # observed nb of subst NS SW after the episodes
        tab_nb_obs_NS_SW_after_epNS = tab_exon_postepNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_SW']]
        # observed nb of subst NS SS after the episodes
        tab_nb_obs_NS_SS_after_epNS = tab_exon_postepNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_SS']]
        # observed nb of subst NS WW after the episodes
        tab_nb_obs_NS_WW_after_epNS = tab_exon_postepNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_WW']]
        # expected nb of subst NS WS after the episodes
        tab_randomNS_WS_exon_name = tab_randomNS_dir + exon + "_simul_distrib_subst_WS_NS.csv"
        tab_randomNS_WS_exon = pd.read_csv(tab_randomNS_WS_exon_name, sep=',')
        tab_randomNS_WS_exon_brpostepNS = tab_randomNS_WS_exon[tab_randomNS_WS_exon['branches'].isin(br_postepNS)]
        tab_randomNS_WS_exon_brpostepNS = tab_randomNS_WS_exon_brpostepNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS SW after the episodes
        tab_randomNS_SW_exon_name = tab_randomNS_dir + exon + "_simul_distrib_subst_SW_NS.csv"
        tab_randomNS_SW_exon = pd.read_csv(tab_randomNS_SW_exon_name, sep=',')
        tab_randomNS_SW_exon_brpostepNS = tab_randomNS_SW_exon[tab_randomNS_SW_exon['branches'].isin(br_postepNS)]
        tab_randomNS_SW_exon_brpostepNS = tab_randomNS_SW_exon_brpostepNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS SS after the episodes
        tab_randomNS_SS_exon_name = tab_randomNS_dir + exon + "_simul_distrib_subst_SS_NS.csv"
        tab_randomNS_SS_exon = pd.read_csv(tab_randomNS_SS_exon_name, sep=',')
        tab_randomNS_SS_exon_brpostepNS = tab_randomNS_SS_exon[tab_randomNS_SS_exon['branches'].isin(br_postepNS)]
        tab_randomNS_SS_exon_brpostepNS = tab_randomNS_SS_exon_brpostepNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS WW after the episodes
        tab_randomNS_WW_exon_name = tab_randomNS_dir + exon + "_simul_distrib_subst_WW_NS.csv"
        tab_randomNS_WW_exon = pd.read_csv(tab_randomNS_WW_exon_name, sep=',')
        tab_randomNS_WW_exon_brpostepNS = tab_randomNS_WW_exon[tab_randomNS_WW_exon['branches'].isin(br_postepNS)]
        tab_randomNS_WW_exon_brpostepNS = tab_randomNS_WW_exon_brpostepNS.rename(columns={'branches': 'Br'})
        # final tables for NS after ep
        if exon == exons_post_epNS[0]:
            # WS
            tab_NS_WS_after_epNS = pd.merge(tab_nb_obs_NS_WS_after_epNS, tab_randomNS_WS_exon_brpostepNS, how='left', on='Br')
            tab_NS_WS_after_epNS = pd.merge(tab_NS_WS_after_epNS, tab_br_asc_lg, how='left', on='Br')
            # SW
            tab_NS_SW_after_epNS = pd.merge(tab_nb_obs_NS_SW_after_epNS, tab_randomNS_SW_exon_brpostepNS, how='left', on='Br')
            tab_NS_SW_after_epNS = pd.merge(tab_NS_SW_after_epNS, tab_br_asc_lg, how='left', on='Br')
            # SS
            tab_NS_SS_after_epNS = pd.merge(tab_nb_obs_NS_SS_after_epNS, tab_randomNS_SS_exon_brpostepNS, how='left', on='Br')
            tab_NS_SS_after_epNS = pd.merge(tab_NS_SS_after_epNS, tab_br_asc_lg, how='left', on='Br')
            # WW
            tab_NS_WW_after_epNS = pd.merge(tab_nb_obs_NS_WW_after_epNS, tab_randomNS_WW_exon_brpostepNS, how='left', on='Br')
            tab_NS_WW_after_epNS = pd.merge(tab_NS_WW_after_epNS, tab_br_asc_lg, how='left', on='Br')
        else:
            # WS
            tab_exon_NS_WS_after_epNS = pd.merge(tab_nb_obs_NS_WS_after_epNS, tab_randomNS_WS_exon_brpostepNS, how='left', on='Br')
            tab_exon_NS_WS_after_epNS = pd.merge(tab_exon_NS_WS_after_epNS, tab_br_asc_lg, how='left', on='Br')
            tab_NS_WS_after_epNS = pd.concat([tab_NS_WS_after_epNS, tab_exon_NS_WS_after_epNS])
            # SW
            tab_exon_NS_SW_after_epNS = pd.merge(tab_nb_obs_NS_SW_after_epNS, tab_randomNS_SW_exon_brpostepNS, how='left', on='Br')
            tab_exon_NS_SW_after_epNS = pd.merge(tab_exon_NS_SW_after_epNS, tab_br_asc_lg, how='left', on='Br')
            tab_NS_SW_after_epNS = pd.concat([tab_NS_SW_after_epNS, tab_exon_NS_SW_after_epNS])
            # SS
            tab_exon_NS_SS_after_epNS = pd.merge(tab_nb_obs_NS_SS_after_epNS, tab_randomNS_SS_exon_brpostepNS, how='left', on='Br')
            tab_exon_NS_SS_after_epNS = pd.merge(tab_exon_NS_SS_after_epNS, tab_br_asc_lg, how='left', on='Br')
            tab_NS_SS_after_epNS = pd.concat([tab_NS_SS_after_epNS, tab_exon_NS_SS_after_epNS])
            # WW
            tab_exon_NS_WW_after_epNS = pd.merge(tab_nb_obs_NS_WW_after_epNS, tab_randomNS_WW_exon_brpostepNS, how='left', on='Br')
            tab_exon_NS_WW_after_epNS = pd.merge(tab_exon_NS_WW_after_epNS, tab_br_asc_lg, how='left', on='Br')
            tab_NS_WW_after_epNS = pd.concat([tab_NS_WW_after_epNS, tab_exon_NS_WW_after_epNS])
            

    ##### NS after the episodes with no subst NS WS #####
    # list of the branches after these episodes & no episodes in these branches
    tab_exon_epnoNS = tab_exon_ep[tab_exon_ep['Nb_subst_NS_WS'] < 0.1]
    br_epnoNS = list(tab_exon_epnoNS['Br'])
    print(br_epnoNS)
    br_postepnoNS = []
    ep_uniq_exon = []
    for br in br_epnoNS:
        br_desc1 = tab_exon[tab_exon['Br'] == br]['Br_Desc1'].iloc[0]
        br_desc2 = tab_exon[tab_exon['Br'] == br]['Br_Desc2'].iloc[0]
        br_postepnoNS.append(br_desc1)
        br_postepnoNS.append(br_desc2)
        # counter of nb ep in same br of other ex initiates at zero 
        nb_ep_other_ex = 0
        # search if ep in same br in other ex
        for other_exon in other_exons_list:
            tab_other_exon = tab_recap[tab_recap['Exon'] == other_exon]
            pval = tab_other_exon[tab_other_exon['Br'] == br]['signif_nb_subst_S_WS'].iloc[0]
            if pval > 200:
                nb_ep_other_ex += 1
        if nb_ep_other_ex > 0:
            ep_uniq_exon.append('NO')
            ep_uniq_exon.append('NO')
        else:
            ep_uniq_exon.append('YES')
            ep_uniq_exon.append('YES')
    print(br_postepnoNS)
    print(ep_uniq_exon)
    if br_postepnoNS:
        exons_post_epnoNS.append(exon)
        # tab of br asc br desc ep (=br ep), lg br asc br desc ep (=br ep), and br br desc ep 
        br_post_list = []
        br_asc_list = []
        br_asc_lg_list = []
        for br in br_postepnoNS:
            br_asc = tab_exon[tab_exon['Br'] == br]['Br_Asc'].iloc[0]
            br_asc_lg = tab_exon[tab_exon['Br'] == br_asc]['Br_lg'].iloc[0]
            br_post_list.append(br)
            br_asc_list.append(br_asc)
            br_asc_lg_list.append(br_asc_lg)
        tab_br_asc_lg = pd.DataFrame({'Br': br_post_list,
        				'Br_asc': br_asc_list,
        				'Br_asc_lg': br_asc_lg_list,
        				'Ep_uniq_exon': ep_uniq_exon})
        # tab of exon with theses branches
        tab_exon_postepnoNS = tab_exon[tab_exon['Br'].isin(br_postepnoNS)]
        # observed nb of subst NS WS after the episodes
        tab_nb_obs_NS_WS_after_epnoNS = tab_exon_postepnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
        # observed nb of subst NS SW after the episodes
        tab_nb_obs_NS_SW_after_epnoNS = tab_exon_postepnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_SW']]
        # observed nb of subst NS SS after the episodes
        tab_nb_obs_NS_SS_after_epnoNS = tab_exon_postepnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_SS']]
        # observed nb of subst NS WW after the episodes
        tab_nb_obs_NS_WW_after_epnoNS = tab_exon_postepnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_WW']]
        # expected nb of subst NS WS after the episodes
        tab_randomNS_WS_exon_name = tab_randomNS_dir + exon + "_simul_distrib_subst_WS_NS.csv"
        tab_randomNS_WS_exon = pd.read_csv(tab_randomNS_WS_exon_name, sep=',')
        tab_randomNS_WS_exon_brpostepnoNS = tab_randomNS_WS_exon[tab_randomNS_WS_exon['branches'].isin(br_postepnoNS)]
        tab_randomNS_WS_exon_brpostepnoNS = tab_randomNS_WS_exon_brpostepnoNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS SW after the episodes
        tab_randomNS_SW_exon_name = tab_randomNS_dir + exon + "_simul_distrib_subst_SW_NS.csv"
        tab_randomNS_SW_exon = pd.read_csv(tab_randomNS_SW_exon_name, sep=',')
        tab_randomNS_SW_exon_brpostepnoNS = tab_randomNS_SW_exon[tab_randomNS_SW_exon['branches'].isin(br_postepnoNS)]
        tab_randomNS_SW_exon_brpostepnoNS = tab_randomNS_SW_exon_brpostepnoNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS SS after the episodes
        tab_randomNS_SS_exon_name = tab_randomNS_dir + exon + "_simul_distrib_subst_SS_NS.csv"
        tab_randomNS_SS_exon = pd.read_csv(tab_randomNS_SS_exon_name, sep=',')
        tab_randomNS_SS_exon_brpostepnoNS = tab_randomNS_SS_exon[tab_randomNS_SS_exon['branches'].isin(br_postepnoNS)]
        tab_randomNS_SS_exon_brpostepnoNS = tab_randomNS_SS_exon_brpostepnoNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS WW after the episodes
        tab_randomNS_WW_exon_name = tab_randomNS_dir + exon + "_simul_distrib_subst_WW_NS.csv"
        tab_randomNS_WW_exon = pd.read_csv(tab_randomNS_WW_exon_name, sep=',')
        tab_randomNS_WW_exon_brpostepnoNS = tab_randomNS_WW_exon[tab_randomNS_WW_exon['branches'].isin(br_postepnoNS)]
        tab_randomNS_WW_exon_brpostepnoNS = tab_randomNS_WW_exon_brpostepnoNS.rename(columns={'branches': 'Br'})
        # final tables for NS after ep
        if exon == exons_post_epnoNS[0]:
            # WS
            tab_NS_WS_after_epnoNS = pd.merge(tab_nb_obs_NS_WS_after_epnoNS, tab_randomNS_WS_exon_brpostepnoNS, how='left', on='Br')
            tab_NS_WS_after_epnoNS = pd.merge(tab_NS_WS_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            # SW
            tab_NS_SW_after_epnoNS = pd.merge(tab_nb_obs_NS_SW_after_epnoNS, tab_randomNS_SW_exon_brpostepnoNS, how='left', on='Br')
            tab_NS_SW_after_epnoNS = pd.merge(tab_NS_SW_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            # SS
            tab_NS_SS_after_epnoNS = pd.merge(tab_nb_obs_NS_SS_after_epnoNS, tab_randomNS_SS_exon_brpostepnoNS, how='left', on='Br')
            tab_NS_SS_after_epnoNS = pd.merge(tab_NS_SS_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            # WW
            tab_NS_WW_after_epnoNS = pd.merge(tab_nb_obs_NS_WW_after_epnoNS, tab_randomNS_WW_exon_brpostepnoNS, how='left', on='Br')
            tab_NS_WW_after_epnoNS = pd.merge(tab_NS_WW_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
        else:
            # WS
            tab_exon_NS_WS_after_epnoNS = pd.merge(tab_nb_obs_NS_WS_after_epnoNS, tab_randomNS_WS_exon_brpostepnoNS, how='left', on='Br')
            tab_exon_NS_WS_after_epnoNS = pd.merge(tab_exon_NS_WS_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            tab_NS_WS_after_epnoNS = pd.concat([tab_NS_WS_after_epnoNS, tab_exon_NS_WS_after_epnoNS])
            # SW
            tab_exon_NS_SW_after_epnoNS = pd.merge(tab_nb_obs_NS_SW_after_epnoNS, tab_randomNS_SW_exon_brpostepnoNS, how='left', on='Br')
            tab_exon_NS_SW_after_epnoNS = pd.merge(tab_exon_NS_SW_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            tab_NS_SW_after_epnoNS = pd.concat([tab_NS_SW_after_epnoNS, tab_exon_NS_SW_after_epnoNS])
            # SS
            tab_exon_NS_SS_after_epnoNS = pd.merge(tab_nb_obs_NS_SS_after_epnoNS, tab_randomNS_SS_exon_brpostepnoNS, how='left', on='Br')
            tab_exon_NS_SS_after_epnoNS = pd.merge(tab_exon_NS_SS_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            tab_NS_SS_after_epnoNS = pd.concat([tab_NS_SS_after_epnoNS, tab_exon_NS_SS_after_epnoNS])
            # WW
            tab_exon_NS_WW_after_epnoNS = pd.merge(tab_nb_obs_NS_WW_after_epnoNS, tab_randomNS_WW_exon_brpostepnoNS, how='left', on='Br')
            tab_exon_NS_WW_after_epnoNS = pd.merge(tab_exon_NS_WW_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            tab_NS_WW_after_epnoNS = pd.concat([tab_NS_WW_after_epnoNS, tab_exon_NS_WW_after_epnoNS])     
            
            
    ### NS during episodes in other exons of the same gene
    for other_exon in other_exons_list:
        tab_other_exon = tab_recap[tab_recap['Exon'] == other_exon]
        pos_other_exon = int(list(tab_other_exon['exon_pos'])[0])
        print(pos_other_exon)
        diff_pos = abs(pos_exon - pos_other_exon)
        print(diff_pos)
        if diff_pos == 1:
            br_epNS_otherex = []
            br_epnoNS_otherex = []
            #
            for br in br_epNS:
                if tab_other_exon[tab_other_exon['Br'] == br]['Episode'].iloc[0] != 'YES':
                    br_epNS_otherex.append(br)
            print(br_epNS_otherex)
            #
            for br in br_epnoNS:
                if tab_other_exon[tab_other_exon['Br'] == br]['Episode'].iloc[0] != 'YES':
                    br_epnoNS_otherex.append(br)
            print(br_epnoNS_otherex)
            #
            if br_epNS_otherex:
                exons_otherex_durepNS.append(exon)
                otherex_otherex_durepNS.append(other_exon)
                # take exon ep name
                exon_ep_list = []
                br_ep_list = []
                for br in br_epNS_otherex:
                    br_ep_list.append(br)
                    exon_ep_list.append(exon)
                tab_br_asc_lg = pd.DataFrame({'Br': br_ep_list,
        	    			       'Exon_ep' : exon_ep_list})
                # take branches
                tab_otherex_during_epNS = tab_other_exon[tab_other_exon['Br'].isin(br_epNS_otherex)]
                # observed
                tab_nb_obs_NS_WS_during_epNS_otherex = tab_otherex_during_epNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
                tab_nb_obs_NS_SW_during_epNS_otherex = tab_otherex_during_epNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_SW']]
                tab_nb_obs_NS_SS_during_epNS_otherex = tab_otherex_during_epNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_SS']]
                tab_nb_obs_NS_WW_during_epNS_otherex = tab_otherex_during_epNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_WW']]
                # expected
                # WS
                tab_randomNS_WS_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_WS_NS.csv"
                tab_randomNS_WS_otherexon = pd.read_csv(tab_randomNS_WS_otherexon_name, sep=',')
                tab_randomNS_WS_during_epNS_otherex = tab_randomNS_WS_otherexon[tab_randomNS_WS_otherexon['branches'].isin(br_epNS_otherex)]
                tab_randomNS_WS_during_epNS_otherex = tab_randomNS_WS_during_epNS_otherex.rename(columns={'branches': 'Br'})
                # SW
                tab_randomNS_SW_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_SW_NS.csv"
                tab_randomNS_SW_otherexon = pd.read_csv(tab_randomNS_SW_otherexon_name, sep=',')
                tab_randomNS_SW_during_epNS_otherex = tab_randomNS_SW_otherexon[tab_randomNS_SW_otherexon['branches'].isin(br_epNS_otherex)]
                tab_randomNS_SW_during_epNS_otherex = tab_randomNS_SW_during_epNS_otherex.rename(columns={'branches': 'Br'})
                # SS
                tab_randomNS_SS_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_SS_NS.csv"
                tab_randomNS_SS_otherexon = pd.read_csv(tab_randomNS_SS_otherexon_name, sep=',')
                tab_randomNS_SS_during_epNS_otherex = tab_randomNS_SS_otherexon[tab_randomNS_SS_otherexon['branches'].isin(br_epNS_otherex)]
                tab_randomNS_SS_during_epNS_otherex = tab_randomNS_SS_during_epNS_otherex.rename(columns={'branches': 'Br'})
                # WW
                tab_randomNS_WW_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_WW_NS.csv"
                tab_randomNS_WW_otherexon = pd.read_csv(tab_randomNS_WW_otherexon_name, sep=',')
                tab_randomNS_WW_during_epNS_otherex = tab_randomNS_WW_otherexon[tab_randomNS_WW_otherexon['branches'].isin(br_epNS_otherex)]
                tab_randomNS_WW_during_epNS_otherex = tab_randomNS_WW_during_epNS_otherex.rename(columns={'branches': 'Br'})
                # final tables for NS after epNS
                if exon == exons_otherex_durepNS[0] and other_exon == otherex_otherex_durepNS[0]:
                    # WS
                    tab_NS_WS_during_epNS_otherexons = pd.merge(tab_nb_obs_NS_WS_during_epNS_otherex, tab_randomNS_WS_during_epNS_otherex, how='left', on='Br')
                    tab_NS_WS_during_epNS_otherexons = pd.merge(tab_NS_WS_during_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # SW
                    tab_NS_SW_during_epNS_otherexons = pd.merge(tab_nb_obs_NS_SW_during_epNS_otherex, tab_randomNS_SW_during_epNS_otherex, how='left', on='Br')
                    tab_NS_SW_during_epNS_otherexons = pd.merge(tab_NS_SW_during_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # SS
                    tab_NS_SS_during_epNS_otherexons = pd.merge(tab_nb_obs_NS_SS_during_epNS_otherex, tab_randomNS_SS_during_epNS_otherex, how='left', on='Br')
                    tab_NS_SS_during_epNS_otherexons = pd.merge(tab_NS_SS_during_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # WW
                    tab_NS_WW_during_epNS_otherexons = pd.merge(tab_nb_obs_NS_WW_during_epNS_otherex, tab_randomNS_WW_during_epNS_otherex, how='left', on='Br')
                    tab_NS_WW_during_epNS_otherexons = pd.merge(tab_NS_WW_during_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                else:
                    # WS 
                    tab_exon_NS_WS_during_epNS_otherexons = pd.merge(tab_nb_obs_NS_WS_during_epNS_otherex, tab_randomNS_WS_during_epNS_otherex, how='left', on='Br')
                    tab_exon_NS_WS_during_epNS_otherexons = pd.merge(tab_exon_NS_WS_during_epNS_otherexons, tab_br_asc_lg, how = 'left', on = 'Br')
                    tab_NS_WS_during_epNS_otherexons = pd.concat([tab_NS_WS_during_epNS_otherexons, tab_exon_NS_WS_during_epNS_otherexons])
                    # SW 
                    tab_exon_NS_SW_during_epNS_otherexons = pd.merge(tab_nb_obs_NS_SW_during_epNS_otherex, tab_randomNS_SW_during_epNS_otherex, how='left', on='Br')
                    tab_exon_NS_SW_during_epNS_otherexons = pd.merge(tab_exon_NS_SW_during_epNS_otherexons, tab_br_asc_lg, how = 'left', on = 'Br')
                    tab_NS_SW_during_epNS_otherexons = pd.concat([tab_NS_SW_during_epNS_otherexons, tab_exon_NS_SW_during_epNS_otherexons])
                    # SS 
                    tab_exon_NS_SS_during_epNS_otherexons = pd.merge(tab_nb_obs_NS_SS_during_epNS_otherex, tab_randomNS_SS_during_epNS_otherex, how='left', on='Br')
                    tab_exon_NS_SS_during_epNS_otherexons = pd.merge(tab_exon_NS_SS_during_epNS_otherexons, tab_br_asc_lg, how = 'left', on = 'Br')
                    tab_NS_SS_during_epNS_otherexons = pd.concat([tab_NS_SS_during_epNS_otherexons, tab_exon_NS_SS_during_epNS_otherexons])
                    # WW
                    tab_exon_NS_WW_during_epNS_otherexons = pd.merge(tab_nb_obs_NS_WW_during_epNS_otherex, tab_randomNS_WW_during_epNS_otherex, how='left', on='Br')
                    tab_exon_NS_WW_during_epNS_otherexons = pd.merge(tab_exon_NS_WW_during_epNS_otherexons, tab_br_asc_lg, how = 'left', on = 'Br')
                    tab_NS_WW_during_epNS_otherexons = pd.concat([tab_NS_WW_during_epNS_otherexons, tab_exon_NS_WW_during_epNS_otherexons])
            #
            if br_epnoNS_otherex:
                exons_otherex_durepnoNS.append(exon)
                otherex_otherex_durepnoNS.append(other_exon)
                # take exon ep name
                exon_ep_list = []
                br_ep_list = []
                for br in br_epnoNS_otherex:
                    br_ep_list.append(br)
                    exon_ep_list.append(exon)
                tab_br_asc_lg = pd.DataFrame({'Br': br_ep_list,
            				       'Exon_ep' : exon_ep_list})
                # take branches
                tab_otherex_during_epnoNS = tab_other_exon[tab_other_exon['Br'].isin(br_epnoNS_otherex)]
                # observed
                tab_nb_obs_NS_WS_during_epnoNS_otherex = tab_otherex_during_epnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
                tab_nb_obs_NS_SW_during_epnoNS_otherex = tab_otherex_during_epnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_SW']]
                tab_nb_obs_NS_SS_during_epnoNS_otherex = tab_otherex_during_epnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_SS']]
                tab_nb_obs_NS_WW_during_epnoNS_otherex = tab_otherex_during_epnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_WW']]
                # expected
                # WS
                tab_randomNS_WS_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_WS_NS.csv"
                tab_randomNS_WS_otherexon = pd.read_csv(tab_randomNS_WS_otherexon_name, sep=',')
                tab_randomNS_WS_during_epnoNS_otherex = tab_randomNS_WS_otherexon[tab_randomNS_WS_otherexon['branches'].isin(br_epnoNS_otherex)]
                tab_randomNS_WS_during_epnoNS_otherex = tab_randomNS_WS_during_epnoNS_otherex.rename(columns={'branches': 'Br'})
                # SW
                tab_randomNS_SW_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_SW_NS.csv"
                tab_randomNS_SW_otherexon = pd.read_csv(tab_randomNS_SW_otherexon_name, sep=',')
                tab_randomNS_SW_during_epnoNS_otherex = tab_randomNS_SW_otherexon[tab_randomNS_SW_otherexon['branches'].isin(br_epnoNS_otherex)]
                tab_randomNS_SW_during_epnoNS_otherex = tab_randomNS_SW_during_epnoNS_otherex.rename(columns={'branches': 'Br'})
                # SS
                tab_randomNS_SS_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_SS_NS.csv"
                tab_randomNS_SS_otherexon = pd.read_csv(tab_randomNS_SS_otherexon_name, sep=',')
                tab_randomNS_SS_during_epnoNS_otherex = tab_randomNS_SS_otherexon[tab_randomNS_SS_otherexon['branches'].isin(br_epnoNS_otherex)]
                tab_randomNS_SS_during_epnoNS_otherex = tab_randomNS_SS_during_epnoNS_otherex.rename(columns={'branches': 'Br'})
                # WW
                tab_randomNS_WW_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_WW_NS.csv"
                tab_randomNS_WW_otherexon = pd.read_csv(tab_randomNS_WW_otherexon_name, sep=',')
                tab_randomNS_WW_during_epnoNS_otherex = tab_randomNS_WW_otherexon[tab_randomNS_WW_otherexon['branches'].isin(br_epnoNS_otherex)]
                tab_randomNS_WW_during_epnoNS_otherex = tab_randomNS_WW_during_epnoNS_otherex.rename(columns={'branches': 'Br'})
                # final tables for NS after epnoNS
                if exon == exons_otherex_durepnoNS[0] and other_exon == otherex_otherex_durepnoNS[0]:
                    # WS
                    tab_NS_WS_during_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_WS_during_epnoNS_otherex, tab_randomNS_WS_during_epnoNS_otherex, how='left', on='Br')
                    tab_NS_WS_during_epnoNS_otherexons = pd.merge(tab_NS_WS_during_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # SW
                    tab_NS_SW_during_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_SW_during_epnoNS_otherex, tab_randomNS_SW_during_epnoNS_otherex, how='left', on='Br')
                    tab_NS_SW_during_epnoNS_otherexons = pd.merge(tab_NS_SW_during_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # SS
                    tab_NS_SS_during_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_SS_during_epnoNS_otherex, tab_randomNS_SS_during_epnoNS_otherex, how='left', on='Br')
                    tab_NS_SS_during_epnoNS_otherexons = pd.merge(tab_NS_SS_during_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # WW
                    tab_NS_WW_during_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_WW_during_epnoNS_otherex, tab_randomNS_WW_during_epnoNS_otherex, how='left', on='Br')
                    tab_NS_WW_during_epnoNS_otherexons = pd.merge(tab_NS_WW_during_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                else:
                    # WS 
                    tab_exon_NS_WS_during_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_WS_during_epnoNS_otherex, tab_randomNS_WS_during_epnoNS_otherex, how='left', on='Br')
                    tab_exon_NS_WS_during_epnoNS_otherexons = pd.merge(tab_exon_NS_WS_during_epnoNS_otherexons, tab_br_asc_lg, how = 'left', on = 'Br')
                    tab_NS_WS_during_epnoNS_otherexons = pd.concat([tab_NS_WS_during_epnoNS_otherexons, tab_exon_NS_WS_during_epnoNS_otherexons])
                    # SW 
                    tab_exon_NS_SW_during_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_SW_during_epnoNS_otherex, tab_randomNS_SW_during_epnoNS_otherex, how='left', on='Br')
                    tab_exon_NS_SW_during_epnoNS_otherexons = pd.merge(tab_exon_NS_SW_during_epnoNS_otherexons, tab_br_asc_lg, how = 'left', on = 'Br')
                    tab_NS_SW_during_epnoNS_otherexons = pd.concat([tab_NS_SW_during_epnoNS_otherexons, tab_exon_NS_SW_during_epnoNS_otherexons])
                    # SS 
                    tab_exon_NS_SS_during_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_SS_during_epnoNS_otherex, tab_randomNS_SS_during_epnoNS_otherex, how='left', on='Br')
                    tab_exon_NS_SS_during_epnoNS_otherexons = pd.merge(tab_exon_NS_SS_during_epnoNS_otherexons, tab_br_asc_lg, how = 'left', on = 'Br')
                    tab_NS_SS_during_epnoNS_otherexons = pd.concat([tab_NS_SS_during_epnoNS_otherexons, tab_exon_NS_SS_during_epnoNS_otherexons])
                    # WW
                    tab_exon_NS_WW_during_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_WW_during_epnoNS_otherex, tab_randomNS_WW_during_epnoNS_otherex, how='left', on='Br')
                    tab_exon_NS_WW_during_epnoNS_otherexons = pd.merge(tab_exon_NS_WW_during_epnoNS_otherexons, tab_br_asc_lg, how = 'left', on = 'Br')
                    tab_NS_WW_during_epnoNS_otherexons = pd.concat([tab_NS_WW_during_epnoNS_otherexons, tab_exon_NS_WW_during_epnoNS_otherexons])    
            
            
            
        ### NS after episodes in other exons of the same gene
    for other_exon in other_exons_list:
        tab_other_exon = tab_recap[tab_recap['Exon'] == other_exon]
        pos_other_exon = int(list(tab_other_exon['exon_pos'])[0])
        print(pos_other_exon)
        diff_pos = abs(pos_exon - pos_other_exon)
        print(diff_pos)
        if diff_pos == 1:
            br_postepNS_otherex = []
            br_postepnoNS_otherex = []
            #
            for br in br_epNS:
                br_desc1 = tab_other_exon[tab_other_exon['Br'] == br]['Br_Desc1'].iloc[0]
                br_desc2 = tab_other_exon[tab_other_exon['Br'] == br]['Br_Desc2'].iloc[0]
                if tab_other_exon[tab_other_exon['Br'] == br_desc1]['Episode'].iloc[0] != 'YES':
                    br_postepNS_otherex.append(br_desc1)
                if tab_other_exon[tab_other_exon['Br'] == br_desc2]['Episode'].iloc[0] != 'YES':
                    br_postepNS_otherex.append(br_desc2)
            print(br_postepNS_otherex)
            #
            for br in br_epnoNS:
                br_desc1 = tab_other_exon[tab_other_exon['Br'] == br]['Br_Desc1'].iloc[0]
                br_desc2 = tab_other_exon[tab_other_exon['Br'] == br]['Br_Desc2'].iloc[0]
                if tab_other_exon[tab_other_exon['Br'] == br_desc1]['Episode'].iloc[0] != 'YES':
                    br_postepnoNS_otherex.append(br_desc1)
                if tab_other_exon[tab_other_exon['Br'] == br_desc2]['Episode'].iloc[0] != 'YES':
                    br_postepnoNS_otherex.append(br_desc2)
            print(br_postepnoNS_otherex)        
            if br_postepNS_otherex:
                #
                exons_otherex_postepNS.append(exon)
                otherex_otherex_postepNS.append(other_exon)
                # take num & len of br ep
                exon_ep_list = []
                br_post_list = []
                br_asc_list = []
                br_asc_lg_list = []
                for br in br_postepNS_otherex:
                    br_asc = tab_other_exon[tab_other_exon['Br'] == br]['Br_Asc'].iloc[0]
                    br_asc_lg = tab_other_exon[tab_other_exon['Br'] == br_asc]['Br_lg'].iloc[0]
                    br_post_list.append(br)
                    br_asc_list.append(br_asc)
                    br_asc_lg_list.append(br_asc_lg)
                    exon_ep_list.append(exon)
                tab_br_asc_lg = pd.DataFrame({'Br': br_post_list,
        	   			        'Br_asc': br_asc_list,
        				        'Br_asc_lg': br_asc_lg_list,
        			                'Exon_ep': exon_ep_list})
                # take branches post epNS
                tab_otherex_after_epNS = tab_other_exon[tab_other_exon['Br'].isin(br_postepNS_otherex)]
                # observed
                tab_nb_obs_NS_WS_after_epNS_otherex = tab_otherex_after_epNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
                tab_nb_obs_NS_SW_after_epNS_otherex = tab_otherex_after_epNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_SW']]
                tab_nb_obs_NS_SS_after_epNS_otherex = tab_otherex_after_epNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_SS']]
                tab_nb_obs_NS_WW_after_epNS_otherex = tab_otherex_after_epNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_WW']]
                # expected
                # WS
                tab_randomNS_WS_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_WS_NS.csv"
                tab_randomNS_WS_otherexon = pd.read_csv(tab_randomNS_WS_otherexon_name, sep=',')
                tab_randomNS_WS_after_epNS_otherex = tab_randomNS_WS_otherexon[tab_randomNS_WS_otherexon['branches'].isin(br_postepNS_otherex)]
                tab_randomNS_WS_after_epNS_otherex = tab_randomNS_WS_after_epNS_otherex.rename(columns={'branches': 'Br'})
                # SW
                tab_randomNS_SW_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_SW_NS.csv"
                tab_randomNS_SW_otherexon = pd.read_csv(tab_randomNS_SW_otherexon_name, sep=',')
                tab_randomNS_SW_after_epNS_otherex = tab_randomNS_SW_otherexon[tab_randomNS_SW_otherexon['branches'].isin(br_postepNS_otherex)]
                tab_randomNS_SW_after_epNS_otherex = tab_randomNS_SW_after_epNS_otherex.rename(columns={'branches': 'Br'})
                # SS
                tab_randomNS_SS_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_SS_NS.csv"
                tab_randomNS_SS_otherexon = pd.read_csv(tab_randomNS_SS_otherexon_name, sep=',')
                tab_randomNS_SS_after_epNS_otherex = tab_randomNS_SS_otherexon[tab_randomNS_SS_otherexon['branches'].isin(br_postepNS_otherex)]
                tab_randomNS_SS_after_epNS_otherex = tab_randomNS_SS_after_epNS_otherex.rename(columns={'branches': 'Br'})
                # WW
                tab_randomNS_WW_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_WW_NS.csv"
                tab_randomNS_WW_otherexon = pd.read_csv(tab_randomNS_WW_otherexon_name, sep=',')
                tab_randomNS_WW_after_epNS_otherex = tab_randomNS_WW_otherexon[tab_randomNS_WW_otherexon['branches'].isin(br_postepNS_otherex)]
                tab_randomNS_WW_after_epNS_otherex = tab_randomNS_WW_after_epNS_otherex.rename(columns={'branches': 'Br'})
                # final tables for NS after epNS
                if exon == exons_otherex_postepNS[0] and other_exon == otherex_otherex_postepNS[0]:
                    # WS
                    tab_NS_WS_after_epNS_otherexons = pd.merge(tab_nb_obs_NS_WS_after_epNS_otherex, tab_randomNS_WS_after_epNS_otherex, how='left', on='Br')
                    tab_NS_WS_after_epNS_otherexons = pd.merge(tab_NS_WS_after_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # SW
                    tab_NS_SW_after_epNS_otherexons = pd.merge(tab_nb_obs_NS_SW_after_epNS_otherex, tab_randomNS_SW_after_epNS_otherex, how='left', on='Br')
                    tab_NS_SW_after_epNS_otherexons = pd.merge(tab_NS_SW_after_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # SS 
                    tab_NS_SS_after_epNS_otherexons = pd.merge(tab_nb_obs_NS_SS_after_epNS_otherex, tab_randomNS_SS_after_epNS_otherex, how='left', on='Br')
                    tab_NS_SS_after_epNS_otherexons = pd.merge(tab_NS_SS_after_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # WW
                    tab_NS_WW_after_epNS_otherexons = pd.merge(tab_nb_obs_NS_WW_after_epNS_otherex, tab_randomNS_WW_after_epNS_otherex, how='left', on='Br')
                    tab_NS_WW_after_epNS_otherexons = pd.merge(tab_NS_WW_after_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                else:
                    # WS 
                    tab_exon_NS_WS_after_epNS_otherexons = pd.merge(tab_nb_obs_NS_WS_after_epNS_otherex, tab_randomNS_WS_after_epNS_otherex, how='left', on='Br')
                    tab_exon_NS_WS_after_epNS_otherexons = pd.merge(tab_exon_NS_WS_after_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    tab_NS_WS_after_epNS_otherexons = pd.concat([tab_NS_WS_after_epNS_otherexons, tab_exon_NS_WS_after_epNS_otherexons])
                    # SW 
                    tab_exon_NS_SW_after_epNS_otherexons = pd.merge(tab_nb_obs_NS_SW_after_epNS_otherex, tab_randomNS_SW_after_epNS_otherex, how='left', on='Br')
                    tab_exon_NS_SW_after_epNS_otherexons = pd.merge(tab_exon_NS_SW_after_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    tab_NS_SW_after_epNS_otherexons = pd.concat([tab_NS_SW_after_epNS_otherexons, tab_exon_NS_SW_after_epNS_otherexons])
                    # SS 
                    tab_exon_NS_SS_after_epNS_otherexons = pd.merge(tab_nb_obs_NS_SS_after_epNS_otherex, tab_randomNS_SS_after_epNS_otherex, how='left', on='Br')
                    tab_exon_NS_SS_after_epNS_otherexons = pd.merge(tab_exon_NS_SS_after_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    tab_NS_SS_after_epNS_otherexons = pd.concat([tab_NS_SS_after_epNS_otherexons, tab_exon_NS_SS_after_epNS_otherexons])
                    # WW
                    tab_exon_NS_WW_after_epNS_otherexons = pd.merge(tab_nb_obs_NS_WW_after_epNS_otherex, tab_randomNS_WW_after_epNS_otherex, how='left', on='Br')
                    tab_exon_NS_WW_after_epNS_otherexons = pd.merge(tab_exon_NS_WW_after_epNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    tab_NS_WW_after_epNS_otherexons = pd.concat([tab_NS_WW_after_epNS_otherexons, tab_exon_NS_WW_after_epNS_otherexons])
            #           
            if br_postepnoNS_otherex:
                #
                exons_otherex_postepnoNS.append(exon)
                otherex_otherex_postepnoNS.append(other_exon)
                # take num & len of br ep
                exon_ep_list = []
                br_post_list = []
                br_asc_list = []
                br_asc_lg_list = []
                for br in br_postepnoNS_otherex:
                    br_asc = tab_other_exon[tab_other_exon['Br'] == br]['Br_Asc'].iloc[0]
                    br_asc_lg = tab_other_exon[tab_other_exon['Br'] == br_asc]['Br_lg'].iloc[0]
                    br_post_list.append(br)
                    br_asc_list.append(br_asc)
                    br_asc_lg_list.append(br_asc_lg)
                    exon_ep_list.append(exon)
                tab_br_asc_lg = pd.DataFrame({'Br': br_post_list,
         				        'Br_asc': br_asc_list,
        				        'Br_asc_lg': br_asc_lg_list,
        				        'Exon_ep' : exon_ep_list})
                # take branches
                tab_otherex_after_epnoNS = tab_other_exon[tab_other_exon['Br'].isin(br_postepnoNS_otherex)]
                # observed
                tab_nb_obs_NS_WS_after_epnoNS_otherex = tab_otherex_after_epnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
                tab_nb_obs_NS_SW_after_epnoNS_otherex = tab_otherex_after_epnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_SW']]
                tab_nb_obs_NS_SS_after_epnoNS_otherex = tab_otherex_after_epnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_SS']]
                tab_nb_obs_NS_WW_after_epnoNS_otherex = tab_otherex_after_epnoNS[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_WW']]
                # expected
                # WS
                tab_randomNS_WS_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_WS_NS.csv"
                tab_randomNS_WS_otherexon = pd.read_csv(tab_randomNS_WS_otherexon_name, sep=',')
                tab_randomNS_WS_after_epnoNS_otherex = tab_randomNS_WS_otherexon[tab_randomNS_WS_otherexon['branches'].isin(br_postepnoNS_otherex)]
                tab_randomNS_WS_after_epnoNS_otherex = tab_randomNS_WS_after_epnoNS_otherex.rename(columns={'branches': 'Br'})
                # SW
                tab_randomNS_SW_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_SW_NS.csv"
                tab_randomNS_SW_otherexon = pd.read_csv(tab_randomNS_SW_otherexon_name, sep=',')
                tab_randomNS_SW_after_epnoNS_otherex = tab_randomNS_SW_otherexon[tab_randomNS_SW_otherexon['branches'].isin(br_postepnoNS_otherex)]
                tab_randomNS_SW_after_epnoNS_otherex = tab_randomNS_SW_after_epnoNS_otherex.rename(columns={'branches': 'Br'})
                # SS
                tab_randomNS_SS_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_SS_NS.csv"
                tab_randomNS_SS_otherexon = pd.read_csv(tab_randomNS_SS_otherexon_name, sep=',')
                tab_randomNS_SS_after_epnoNS_otherex = tab_randomNS_SS_otherexon[tab_randomNS_SS_otherexon['branches'].isin(br_postepnoNS_otherex)]
                tab_randomNS_SS_after_epnoNS_otherex = tab_randomNS_SS_after_epnoNS_otherex.rename(columns={'branches': 'Br'})
                # WW
                tab_randomNS_WW_otherexon_name = tab_randomNS_dir + other_exon + "_simul_distrib_subst_WW_NS.csv"
                tab_randomNS_WW_otherexon = pd.read_csv(tab_randomNS_WW_otherexon_name, sep=',')
                tab_randomNS_WW_after_epnoNS_otherex = tab_randomNS_WW_otherexon[tab_randomNS_WW_otherexon['branches'].isin(br_postepnoNS_otherex)]
                tab_randomNS_WW_after_epnoNS_otherex = tab_randomNS_WW_after_epnoNS_otherex.rename(columns={'branches': 'Br'})
                # final tables for NS after epnoNS
                if exon == exons_otherex_postepnoNS[0] and other_exon == otherex_otherex_postepnoNS[0]:
                    # WS
                    tab_NS_WS_after_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_WS_after_epnoNS_otherex, tab_randomNS_WS_after_epnoNS_otherex, how='left', on='Br')
                    tab_NS_WS_after_epnoNS_otherexons = pd.merge(tab_NS_WS_after_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # SW
                    tab_NS_SW_after_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_SW_after_epnoNS_otherex, tab_randomNS_SW_after_epnoNS_otherex, how='left', on='Br')
                    tab_NS_SW_after_epnoNS_otherexons = pd.merge(tab_NS_SW_after_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # SS
                    tab_NS_SS_after_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_SS_after_epnoNS_otherex, tab_randomNS_SS_after_epnoNS_otherex, how='left', on='Br')
                    tab_NS_SS_after_epnoNS_otherexons = pd.merge(tab_NS_SS_after_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    # WW
                    tab_NS_WW_after_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_WW_after_epnoNS_otherex, tab_randomNS_WW_after_epnoNS_otherex, how='left', on='Br')
                    tab_NS_WW_after_epnoNS_otherexons = pd.merge(tab_NS_WW_after_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                else:
                    # WS 
                    tab_exon_NS_WS_after_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_WS_after_epnoNS_otherex, tab_randomNS_WS_after_epnoNS_otherex, how='left', on='Br')
                    tab_exon_NS_WS_after_epnoNS_otherexons = pd.merge(tab_exon_NS_WS_after_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    tab_NS_WS_after_epnoNS_otherexons = pd.concat([tab_NS_WS_after_epnoNS_otherexons, tab_exon_NS_WS_after_epnoNS_otherexons])
                    # SW 
                    tab_exon_NS_SW_after_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_SW_after_epnoNS_otherex, tab_randomNS_SW_after_epnoNS_otherex, how='left', on='Br')
                    tab_exon_NS_SW_after_epnoNS_otherexons = pd.merge(tab_exon_NS_SW_after_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    tab_NS_SW_after_epnoNS_otherexons = pd.concat([tab_NS_SW_after_epnoNS_otherexons, tab_exon_NS_SW_after_epnoNS_otherexons])
                    # SS 
                    tab_exon_NS_SS_after_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_SS_after_epnoNS_otherex, tab_randomNS_SS_after_epnoNS_otherex, how='left', on='Br')
                    tab_exon_NS_SS_after_epnoNS_otherexons = pd.merge(tab_exon_NS_SS_after_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    tab_NS_SS_after_epnoNS_otherexons = pd.concat([tab_NS_SS_after_epnoNS_otherexons, tab_exon_NS_SS_after_epnoNS_otherexons])
                    # WW
                    tab_exon_NS_WW_after_epnoNS_otherexons = pd.merge(tab_nb_obs_NS_WW_after_epnoNS_otherex, tab_randomNS_WW_after_epnoNS_otherex, how='left', on='Br')
                    tab_exon_NS_WW_after_epnoNS_otherexons = pd.merge(tab_exon_NS_WW_after_epnoNS_otherexons, tab_br_asc_lg, how='left', on='Br')
                    tab_NS_WW_after_epnoNS_otherexons = pd.concat([tab_NS_WW_after_epnoNS_otherexons, tab_exon_NS_WW_after_epnoNS_otherexons])    
            
            
    


if exons_post_epNS:
    tab_NS_WS_after_epNS.to_csv(gene + '_tab_NS_WS_after_epNS_with_random.csv', index=False)
    tab_NS_SW_after_epNS.to_csv(gene + '_tab_NS_SW_after_epNS_with_random.csv', index=False)
    tab_NS_SS_after_epNS.to_csv(gene + '_tab_NS_SS_after_epNS_with_random.csv', index=False)
    tab_NS_WW_after_epNS.to_csv(gene + '_tab_NS_WW_after_epNS_with_random.csv', index=False)

if exons_post_epnoNS:
    tab_NS_WS_after_epnoNS.to_csv(gene + '_tab_NS_WS_after_epnoNS_with_random.csv', index=False)
    tab_NS_SW_after_epnoNS.to_csv(gene + '_tab_NS_SW_after_epnoNS_with_random.csv', index=False)
    tab_NS_SS_after_epnoNS.to_csv(gene + '_tab_NS_SS_after_epnoNS_with_random.csv', index=False)
    tab_NS_WW_after_epnoNS.to_csv(gene + '_tab_NS_WW_after_epnoNS_with_random.csv', index=False)

if exons_otherex_durepNS:
    tab_NS_WS_during_epNS_otherexons.to_csv(gene + '_tab_NS_WS_during_epNS_otherex.csv', index=False)
    tab_NS_SW_during_epNS_otherexons.to_csv(gene + '_tab_NS_SW_during_epNS_otherex.csv', index=False)
    tab_NS_SS_during_epNS_otherexons.to_csv(gene + '_tab_NS_SS_during_epNS_otherex.csv', index=False)
    tab_NS_WW_during_epNS_otherexons.to_csv(gene + '_tab_NS_WW_during_epNS_otherex.csv', index=False)
    
if exons_otherex_durepnoNS:
    tab_NS_WS_during_epnoNS_otherexons.to_csv(gene + '_tab_NS_WS_during_epnoNS_otherex.csv', index=False)
    tab_NS_SW_during_epnoNS_otherexons.to_csv(gene + '_tab_NS_SW_during_epnoNS_otherex.csv', index=False)
    tab_NS_SS_during_epnoNS_otherexons.to_csv(gene + '_tab_NS_SS_during_epnoNS_otherex.csv', index=False)
    tab_NS_WW_during_epnoNS_otherexons.to_csv(gene + '_tab_NS_WW_during_epnoNS_otherex.csv', index=False)

if exons_otherex_postepNS:
    tab_NS_WS_after_epNS_otherexons.to_csv(gene + '_tab_NS_WS_after_epNS_otherex.csv', index=False)
    tab_NS_SW_after_epNS_otherexons.to_csv(gene + '_tab_NS_SW_after_epNS_otherex.csv', index=False)
    tab_NS_SS_after_epNS_otherexons.to_csv(gene + '_tab_NS_SS_after_epNS_otherex.csv', index=False)
    tab_NS_WW_after_epNS_otherexons.to_csv(gene + '_tab_NS_WW_after_epNS_otherex.csv', index=False)
    
if exons_otherex_postepnoNS:
    tab_NS_WS_after_epnoNS_otherexons.to_csv(gene + '_tab_NS_WS_after_epnoNS_otherex.csv', index=False)
    tab_NS_SW_after_epnoNS_otherexons.to_csv(gene + '_tab_NS_SW_after_epnoNS_otherex.csv', index=False)
    tab_NS_SS_after_epnoNS_otherexons.to_csv(gene + '_tab_NS_SS_after_epnoNS_otherex.csv', index=False)
    tab_NS_WW_after_epnoNS_otherexons.to_csv(gene + '_tab_NS_WW_after_epnoNS_otherex.csv', index=False)


























