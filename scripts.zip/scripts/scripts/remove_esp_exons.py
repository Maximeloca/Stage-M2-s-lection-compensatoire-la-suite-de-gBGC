## install packages ###

###ce script se fait pour un gène car on a bouclé sur la liste de gènes 
from Bio import SeqIO
import sys
import pandas as pd
import random

## arguments ###

    # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 3:
    sys.exit("ERROR : need 2 arguments : [1]gene name [2]directory of the sequences")
    # recuperer les arguments
exon_name = sys.argv[1]
#genes_exons_pos_tab_name = sys.argv[2]
seq_dir = sys.argv[2]

# read tab of gene and exons
#tab_genes_exons_pos = pd.read_csv(genes_exons_pos_tab_name, sep="\t", header=None) # on lit le tableau des gènes avec les exons positions et tout.. 
#tab_genes_exons_pos.columns = ['Exon', 'Gene'] # renomme les colonnes 

# list of exons for the gene
#exons_list = list(tab_genes_exons_pos[tab_genes_exons_pos['Gene'] == gene_name]['Exon'])
### tab_genes_exons_pos[tab_genes_exons_pos['Gene'] == gene_name] --> permet de récupérer les lignes qui correspondent à notre gène 
### ['Exon'] --> on ne garde que la colonne exon 
# donc à la fin on a la liste des exons qui appartiennent au gène qu'on fait 

exon=exon_name

exons_sp = list()
exon_align_name = f'{seq_dir}/{exon}' #on récupère l'aligne
for seq_read in SeqIO.parse(exon_align_name, 'fasta'):
    sp = seq_read.id #récupère id de la séquence = nom de l'espèce
    exons_sp.append(sp) # on ajoute le nom de l'espèce au dico

#dico_exon_sp = {}
#exon_1=exons_list[0]
#exon_align_name = f'{seq_dir}/{exon_1}' #on récupère l'aligne
#dico_exon_sp[exon_1] = []  
#for seq_read in SeqIO.parse(exon_align_name, 'fasta'):
#    sp = seq_read.id #récupère id de la séquence = nom de l'espèce
#    dico_exon_sp[exon_1].append(sp) # on ajoute le nom de l'espèce au dico

#nb_esp=len(dico_exon_sp[exon_1])
nb_esp=len(exons_sp)




#nb_esp_rm=nb_esp-25
#if nb_esp_rm > 0:
#    for i in range(nb_esp_rm):
#        sp_to_remove = random.choice(dico_exon_sp[exon_1])
#        dico_exon_sp[exon_1].remove(sp_to_remove)

nb_esp_rm=nb_esp-25
if nb_esp_rm > 0:
    for i in range(nb_esp_rm):
        sp_to_remove = random.choice(exons_sp)
        exons_sp.remove(sp_to_remove)

#sp_list = dico_exon_sp[exon_1]
sp_list = exons_sp


#for exon in exons_list:
    #pos = tab_genes_exons_pos[tab_genes_exons_pos['Exon'] == exon]['Position'].iloc[0]
seq_out_name = f'{exon}'
exon_align_name = f'{seq_dir}/{exon}'
with open(seq_out_name, 'w') as out: # 'w' car on va écrire dedans 
    for seq_read in SeqIO.parse(exon_align_name, 'fasta'):
        seq_id = seq_read.id
        if seq_id in sp_list:
            out.write(f'>{seq_id}\n')
            seq_seq = seq_read.seq
            out.write(f'{seq_seq}\n')
