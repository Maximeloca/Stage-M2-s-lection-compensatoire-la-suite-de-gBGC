ID=$1  # Prend l'ID en argument
Directory=$2

SPECIE=$(grep -w ${ID} ~/Cetacea/tab_species_id.csv | cut -f1)  # Récupère le nom de l'espèce

# Parcours tous les fichiers .fasta dans le dossier Sequences
for fasta in "$Directory"/*.fasta ; do
    sed -i "s/$ID/$SPECIE/g" "$fasta"  # Remplace l'ID par le nom de l'espèce
done