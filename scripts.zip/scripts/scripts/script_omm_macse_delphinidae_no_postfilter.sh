#! /bin/bash

# parametres ##

EXON=$1

# script ##

basename=$(basename "$EXON" .fasta)


~/bin/vranwez_default_omm_macse.sif --no_prefiltering --no_postfiltering --in_seq_file ~/Cetacea/Delphinidae/Reference_exons/${basename}_Oorc.fasta --in_seq_lr_file ~/Cetacea/Delphinidae/Sequences/test/wt_gap/unique/wt_ref/fou/align_no_postfilter/${EXON} --out_dir ~/Cetacea/Delphinidae/Sequences/test/wt_gap/unique/wt_ref/fou/align/${basename}_all_sp_seq_align --out_file_prefix ${EXON} --min_percent_NT_at_ends 0.1
### 1re arg l'exon de ref donc exon correspondant de la souris
### ensuite on lui donne notre le fichier contenant les espèces ayant le même exon
###--min_percent_NT_at_ends 0.1 --> cela correspond au pourcentage minimum de nucléotides nécessaire au niveau des extrêmités
