#!/usr/bin/env Rscript

## Arguments ##
args = commandArgs(trailingOnly=TRUE)
print(args)

if (length(args)<2) {
  stop("2 arguments must be supplied : [1] exon name [2] directory path", call.=FALSE)
}

exon_name = args[1]
dir_path = args[2]

## script ##

## WS table
tab_S_WS <- read.table(paste0(dir_path, exon_name, "_counts_dS_X_WS.csv"), sep="\t", header=T) # read table of synonymous substitution
tab_NS_WS <- read.table(paste0(dir_path, exon_name, "_counts_dN_X_WS.csv"), sep="\t", header=T) # read table of non-synonymous_substitution
tab_WS <- tab_S_WS + tab_NS_WS # sum the two tables
tab_WS <- tab_WS[,2:ncol(tab_WS)] # remove the first column (number of the codons)
nb_subst_WS <- colSums(tab_WS) # sum the number of substitutions on each branch
branches <- colnames(tab_WS) # get the numbers of the branches
exon_name_vector <- rep(exon_name, length(nb_subst_WS)) # create vector of exon name

## SW table
tab_S_SW <- read.table(paste0(dir_path, exon_name, "_counts_dS_X_SW.csv"), sep="\t", header=T) # read table of synonymous substitution
tab_NS_SW <- read.table(paste0(dir_path, exon_name, "_counts_dN_X_SW.csv"), sep="\t", header=T) # read table of non-synonymous_substitution
tab_SW <- tab_S_SW + tab_NS_SW # sum the two tables
tab_SW <- tab_SW[,2:ncol(tab_SW)] # remove the first column (number of the codons)
nb_subst_SW <- colSums(tab_SW) # sum the number of substitutions on each branch

## SSWW table 
tab_S_SS <- read.table(paste0(dir_path, exon_name, "_counts_dS_X_SS.csv"), sep="\t", header=T) # read table of synonymous substitution
tab_NS_SS <- read.table(paste0(dir_path, exon_name, "_counts_dN_X_SS.csv"), sep="\t", header=T) # read table of non-synonymous_substitution
tab_S_WW <- read.table(paste0(dir_path, exon_name, "_counts_dS_X_WW.csv"), sep="\t", header=T) # read table of synonymous substitution
tab_NS_WW <- read.table(paste0(dir_path, exon_name, "_counts_dN_X_WW.csv"), sep="\t", header=T) # read table of non-synonymous_substitution
tab_SSWW <- tab_S_SS + tab_NS_SS + tab_S_WW + tab_NS_WW # sum the four tables
tab_SSWW <- tab_SSWW[,2:ncol(tab_SSWW)] # remove the first column (number of the codons)
nb_subst_SSWW <- colSums(tab_SSWW) # sum the number of substitutions on each branch

## final table
tab_final <- as.data.frame(cbind(nb_subst_WS, nb_subst_SW, nb_subst_SSWW, branches, exon_name_vector)) # create the table of nb substitution and subst type
tab_final$nb_subst_SW <- as.numeric(as.character(tab_final$nb_subst_SW)) # transform the colum of nb subst SW as numeric
tab_final$nb_subst_WS <- as.numeric(as.character(tab_final$nb_subst_WS)) # transform the colum of nb subst WS as numeric
tab_final$nb_subst_SSWW <- as.numeric(as.character(tab_final$nb_subst_SSWW)) # transform the colum of nb subst SSWW as numeric
#tab_final$ratio <- tab_final$nb_subst_WS/tab_final$nb_subst_SW
#tab_final$nb_tot_subst <- tab_final$nb_subst_WS + tab_final$nb_subst_SW
#tab_final$diff <- tab_final$nb_subst_WS - tab_final$nb_subst_SW
#tab_final$indice <- (tab_final$nb_subst_WS - tab_final$nb_subst_SW)/(tab_final$nb_subst_WS + tab_final$nb_subst_SW)
#colnames(tab_final) <- c("nb_subst_WS", "nb_subst_SW","branch_number","exon_name","ratio_WS_SW","nb_tot_subst_SW_WS","diff_nb_WS_nb_SW","indice")

## save the final table
write.table(tab_final, paste0(exon_name, "_count_subst_types_in_branches.csv"), sep="\t", quote=F, row.names=F, col.names=F) # save the table as csv 
