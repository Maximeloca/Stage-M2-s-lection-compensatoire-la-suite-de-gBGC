## install packages ###
import sys
import pandas as pd
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]genes list [2]directory of the tab recap [3]threshold nb subst/len seq")
# recuperer les arguments
gene_list_txt = sys.argv[1]
tab_recap_dir = sys.argv[2]
seuil_nb_subst = sys.argv[3]

## script ###

# get the genes list
with open(gene_list_txt, "r") as file_gene_list:
    gene_read = file_gene_list.read().strip()
    genes_list = gene_read.split()

#
exons_pass_seuil_list = []
seuil_nb_subst = float(seuil_nb_subst)

# 
for gene in genes_list:
    # read the table
    tab_recap_name = tab_recap_dir + gene + "_tab_recap.csv"
    tab_recap = pd.read_csv(tab_recap_name, sep='\t')
    # add a column of ratio of nb subst WS / len exon ###peut être rajouter aussi les NS
    tab_recap['ratio'] = (tab_recap['Nb_subst_S_WS'] + tab_recap['Nb_subst_S_SW'] + tab_recap['Nb_subst_S_SS'] + tab_recap['Nb_subst_S_WW'])/tab_recap['Lg_seq']
    exons_pass_seuil = list(tab_recap[tab_recap['ratio'] > seuil_nb_subst]['Exon'])
    exons_pass_seuil = set(exons_pass_seuil)
    exons_pass_seuil = list(exons_pass_seuil)
    exons_pass_seuil_list.extend(exons_pass_seuil)
    

tab = pd.DataFrame({'Exon' : exons_pass_seuil_list})
tab.to_csv('List_exons_error_aln.csv', index=False)

