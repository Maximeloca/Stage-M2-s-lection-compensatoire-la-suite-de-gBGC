#! /bin/bash


### JE PEUX AUSSI ESSAYER DE MODIFIER CE SCRIPT
# parametres ##

SPECIE=$1
TRIBE=$2

# script ##

for EXON in $(cat ~/Murinae/${TRIBE}/Sequences/Exons_list.txt); do

	# informations

	GENE=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1) #-w permet de contenir uniquement le mot qu'on a dit, attention le -w prend aussi quand on a un tiret

	EXON_POSITION=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

###peut être cette zone la à modifier car long et remplacer par CONTIG=$(grep "${EXON}" ~/Murinae/${TRIBE}/Heterozygosity/contigs_lists/contigs_list_${SPECIE}.txt | cut -f2) ###on récupère le nom du contig associé à l'exon
	CONTIG=$(LC_ALL=en_US awk '{if ($12=="yes") {print $0}}' ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${SPECIE}/sortie_blast_reciproque_${SPECIE}.csv |\
	grep "${EXON}" |\
	cut -f6)
 
 

###on récupère la position de début de l'exon et on garde uniquement ceux ou on a yes
	DEBUT=$(LC_ALL=en_US awk '{if ($12=="yes") {print $0}}' ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${SPECIE}/sortie_blast_reciproque_${SPECIE}.csv |\
	grep "${EXON}" |\
	cut -f7)
###on récupère la position de la fin de l'exon
	FIN=$(LC_ALL=en_US awk '{if ($12=="yes") {print $0}}' ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${SPECIE}/sortie_blast_reciproque_${SPECIE}.csv |\
	grep "${EXON}" |\
	cut -f8)


###idem on est sur les individus mais on a qu'un ind  par espèces, c'est cette partie là qu'on veut modifier
	INDIV=$(grep ${SPECIE} ~/Murinae/${TRIBE}/Data/recap_sequencing_${TRIBE}.csv | cut -f2 -d',') ###récupère id individu
		
		# nombre de reads :
		#NB_READS=$(samtools coverage -H -r ${CONTIG}:${DEBUT}-${FIN} ~/Murinae/Mapping/${TRIBE}/${SPECIE}/${INDIV}_bwa_sorted_bam.bam | cut -f4)

		# % de bases couvertes :
		#COVERAGE=$(samtools coverage -H -r ${CONTIG}:${DEBUT}-${FIN} ~/Murinae/Mapping/${TRIBE}/${SPECIE}/${INDIV}_bwa_sorted_bam.bam | cut -f6)

		# profondeur moyenne de couverture :
		MEAN_DEPTH=$(samtools coverage -H -r ${CONTIG}:${DEBUT}-${FIN} ~/Murinae/${TRIBE}/Mapping/${SPECIE}/${INDIV}_bwa_sorted_bam.bam | cut -f7)
       #MEAN_DEPTH=$(samtools coverage -H -r ${CONTIG}:${DEBUT}-${FIN} ~/Murinae/${TRIBE}/Mapping/${SPECIE}/${INDIV}_bwa_sorted_bam.bam | cut -f7) ## peut être qu'il faut rajouter l'entrée dans le dossier espèce
            ## -r on spécifie une région de début et de fin
            ## - h on ne veut pas de titre
            ### ca va faire un tableau et la couverture c'est la colonne 7
            ### on peut tester juste samtools coverage sur un contig et regarder le tableau qu'il sort et si la colonne 7 correspond tjr à la couv moy
    
    ### profondeur moyenne de couverture pour chaque contig ?
            

		# % de GC :
		#GC=$(seqkit fx2tab ~/Murinae/Blast/blast_reciproque/${TRIBE}/${SPECIE}/${GENE}_${EXON}_${EXON_POSITION}_seq.fasta -g -n | cut -f2)
        
    HET_MOY=$(grep "${EXON}" ~/Murinae/${TRIBE}/Heterozygosity/${SPECIE}/tab_heterozygotie_${SPECIE}.csv | cut -f3)

        echo -e "${GENE}\t${EXON}\t${MEAN_DEPTH}\t${HET_MOY}"
done >> ${SPECIE}_Exons_tab_infos.csv
#		echo -e "${GENE}\t${EXON}\t${INDIV}\t${MEAN_DEPTH}"
#	done >> ${SPECIE}_${EXON}_tab_infos.csv
	
	#NB_READS_MOY=$(awk '{ sum += $4 } END { print (sum / NR)}' ${SPECIE}_${EXON}_tab_infos.csv)

	#COVERAGE_MOY=$(awk '{ sum += $5 } END { print (sum / NR)}' ${SPECIE}_${EXON}_tab_infos.csv)

#	MEAN_DEPTH_MOY=$(awk '{ sum += $4 } END { print (sum / NR)}' ${SPECIE}_${EXON}_tab_infos.csv) ###pas besoin de moyenne aussi mais on doit le arder vu qu'on est sur les indiv et on peut à la

	#GC_MOY=$(awk '{ sum += $7 } END { print (sum / NR)}' ${SPECIE}_${EXON}_tab_infos.csv)
	
#	HET_MOY=$(grep "${EXON}" ~/Murinae/${TRIBE}/Heterozygosity/${SPECIE}/tab_heterozygotie_${SPECIE}.csv | cut -f3)
		
#	echo -e "${GENE}\t${EXON}\t${MEAN_DEPTH_MOY}\t${HET_MOY}"
		
#	rm ${SPECIE}_${EXON}_tab_infos.csv ##on en aura certainement plus besoin
	
#done >> ${SPECIE}_Exons_tab_infos.csv
