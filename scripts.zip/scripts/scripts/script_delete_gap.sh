#!/bin/bash

# Prend notre fichier FASTA en argument
fasta=$1
out_folder=$2

# Extrait le nom du fichier sans le chemin
basename=$(basename "$fasta" .fasta)

# Supprime les tirets et enregistre le fichier corrigé
sed 's/-//g' "$fasta" > "$out_folder/${basename}_wt_gap.fasta"