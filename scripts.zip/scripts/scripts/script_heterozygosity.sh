#! /bin/bash

# parametres ##

BAM_FILE=$1
ASSEMBLY=$2
CONTIG=$3

# script ##

if [[ ! -e angsdput.saf.idx ]] ; then
	~/bin/angsd -i ${BAM_FILE} -anc ${ASSEMBLY} -dosaf 1 -fold 1 -gl 1 ;
fi
####on va faire l'indexation sur tous les fichier d'assemblage contenant tous les contigs et ensuite on va faire realSFS pour chaque contif et donc on le fait une fois sur le gros fichier d'assemmblage

~/bin/realSFS angsdput.saf.idx -r ${CONTIG} > est.ml ###va donner un tableau contenant le nb de sites hétérozygotes et le nb de site homozygote pour un contig

nb_het=$(cat est.ml | cut -f2 -d' ') ###on récupère le nb de hétérozygote

nb_hom=$(cat est.ml | cut -f1 -d' ') ###on récupère le nb de homozygote

het=$(echo "${nb_het}/(${nb_hom}+${nb_het})" | bc -l) ###bc - l va permettre de dire que notre sprtie eest numérique

echo "${het}" > heterozygosity.txt 
