## install packages ###

###ce script se fait pour un gène car on a bouclé sur la liste de gènes 
from Bio import SeqIO
import sys
import pandas as pd
import random

## arguments ###

    # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 6:
    sys.exit("ERROR : need 4 arguments : [1]gene name [2]tab of genes, exons, position [3]directory of the sequences [4] directory_ref")
    # recuperer les arguments
gene_name = sys.argv[1]
Seq_ref = sys.argv[2]
seq_dir = sys.argv[3]
seq_dir_wt_ref = sys.argv[4]
seq_dir_ref = sys.argv[5]

seq_out_name = f'{seq_dir_wt_ref}/{gene_name}_wt_ref'
exon_align_name = f'{seq_dir}/{gene_name}'
with open(seq_out_name, 'w') as out: # 'w' car on va écrire dedans 
    for seq_read in SeqIO.parse(exon_align_name, 'fasta'):
        seq_id = seq_read.id
        if seq_id != Seq_ref:
            out.write(f'>{seq_id}\n')
            seq_seq = seq_read.seq
            out.write(f'{seq_seq}\n')


seq_out_name_ref = f'{seq_dir_ref}/{gene_name}_ref'
exon_align_name = f'{seq_dir}/{gene_name}'
with open(seq_out_name_ref, 'w') as out: # 'w' car on va écrire dedans 
    for seq_read in SeqIO.parse(exon_align_name, 'fasta'):
        seq_id = seq_read.id
        if seq_id == Seq_ref:
            out.write(f'>{seq_id}\n')
            seq_seq = seq_read.seq
            out.write(f'{seq_seq}\n')