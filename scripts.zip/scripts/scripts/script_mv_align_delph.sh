#! /bin/bash

# parametres ##
EXON=$1
basename=$(basename "$EXON" .fasta)

mv ~/Cetacea/Delphinidae/Aligned_Sequences/${basename}_all_sp_seq_align/${basename}.fasta_final_align_NT.aln ~/Cetacea/Delphinidae/Aligned_Sequences/alignments
