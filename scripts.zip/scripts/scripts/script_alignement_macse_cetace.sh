#! /bin/bash

# parametres ##

EXON=$1


# script ##


java -jar ~/bin/macse_v2.07.jar -prog alignSequences -seq ~/Cetacea/Sequences/align_corrected/wt_gap/unique/${EXON} -out_NT ~/Cetacea/Aligned_Sequences/Align_NT/${EXON}_seq_NT_aligned.fasta -out_AA ~/Cetacea/Aligned_Sequences/Align_AA/${EXON}_seq_AA_aligned.fasta
### prog = juste le programme qu'on utilise et qui s'appelle alignSequences 
### seq = la séquence que l'on veut aligner 
### -out_NT = nom de sortie de l'alignement NT
### -out_AA = nom de sortie de l'alignement avec les acides aminés 