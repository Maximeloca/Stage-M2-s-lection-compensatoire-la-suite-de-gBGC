#!/usr/bin/python

"""
Reads a FASTA file and if >1 sequence has the same description line,
it only keeps the longest sequence. It outputs all the sequencs to stdout
when complete.

"""


from Bio import SeqIO
import sys
import os

if len(sys.argv) != 3:
    sys.exit("ERROR : need 3 arguments: [1]alignment [2]output folder path")

# Récupère les arguments
file = sys.argv[1]  # Fichier FASTA
out_folder = sys.argv[2]  # Dossier de sortie

# Création du nom du fichier de sortie
base_name = os.path.splitext(os.path.basename(file))[0]  # Récupère uniquement le nom du fichier sans extension
out_file_name = os.path.join(out_folder, f"{base_name}_unique.fasta")  # Définit le fichier de sortie

seqs = {}
new = 0  #For testing, count of sequences as their added to seqs
existing = 0  #For testing, count of sequences NOT added because they already exist

for seq_record in SeqIO.parse(file, "fasta"):
  if seq_record.name not in seqs:
    seqs[seq_record.name]=seq_record.seq
    new += 1
  else:
    existing += 1
    if len(seqs[seq_record.name])<=len(seq_record.seq):
       seqs[seq_record.name]=seq_record.seq
#       print "Duplicate found, ", seq_record.name

# Écriture des séquences uniques dans le fichier de sortie
with open(out_file_name, "w") as out:
    for name, seq in seqs.items():  # Utilisation de items() pour Python 3
        out.write(f">{name}\n{seq}\n")  # Écriture du nom et de la séquence

#for name, seq in seqs.iteritems():
#  print ">"+name
#  print seq

#Uncomment below print statement to print out the sequence counts
#print new, existing, new+existing