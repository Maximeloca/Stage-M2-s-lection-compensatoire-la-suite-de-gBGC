#! /bin/bash

# Arguments ###

EXON=$1
TRIBE=$2
NB_SIMUL=$3

# Script ###

python3 ~/scripts/signif_stat.py ~/${TRIBE}/Detecting_gBGC/Distrib_subst_S/${EXON}_stat_nb_subst.csv ~/${TRIBE}/Detecting_gBGC/I_Moran/I_Moran_${EXON}.csv ~/${TRIBE}/Randomisations/Distrib_subst/${EXON}_distrib_subst_simul.csv ~/${TRIBE}/Randomisations/I_Moran/${EXON}_I_simul.csv ${EXON}_tab_signif_stat.csv $NB_SIMUL
