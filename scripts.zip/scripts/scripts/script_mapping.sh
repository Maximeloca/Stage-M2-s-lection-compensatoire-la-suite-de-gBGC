#! /bin/bash

# paramètres ####

THREADS=$1
INDIV=$2
TRIBE=$3

# script ########

# génome de référence
SPECIE=$(grep ${INDIV} ~/Murinae/${TRIBE}/Data/recap_sequencing_${TRIBE}.csv | cut -f1 -d',') ###on récupère le nom de l'espèce
REF=~/Murinae/${TRIBE}/Assembly/trinity_OUT_${SPECIE}.Trinity.fasta ###ici ca correspond aux contigs qu'il faut aller récupérer --> fichier fasta avec tous les contigs de l'esp

###il faut certainement créer le dossier espèces donc : mkdir ${SPECIE}

mkdir ${SPECIE}s
# entrer dans dossier de l'espèce
cd ${SPECIE}

# créer l'index du génome de référence (s'il n'existe pas déjà)
if [[ ! -e ${REF}.amb && ! -e ${REF}.ann && ! -e ${REF}.bwt && ! -e ${REF}.pac && ! -e ${REF}.sa ]] ; then
	bwa index ${REF}
fi
###une indexation va transformer le fichier pour qu'on piusse s'en servir après
###-e = est ce que fichier existe
### ! --> c'est la négative càd ca n'existe pas
### si ca n'existe pas on fait l'indexation



# reads à mapper ####donc on va aller chercher les reads pour les individus
nb_indiv=$(grep -c ${SPECIE} ~/Murinae/${TRIBE}/Data/recap_sequencing_${TRIBE}.csv)
if [ ${nb_indiv} == 1 ] ; then
	READS_F=~/Murinae/${TRIBE}/Data/cleaned_pooled_reads/${SPECIE}_all_R1.clean.fastq.gz ####
	READS_R=~/Murinae/${TRIBE}/Data/cleaned_pooled_reads/${SPECIE}_all_R2.clean.fastq.gz ;
	else
	READS_F=~/Murinae/${TRIBE}/Data/cleaned_pooled_reads/${INDIV}_all_R1.clean.fastq.gz
	READS_R=~/Murinae/${TRIBE}/Data/cleaned_pooled_reads/${INDIV}_all_R2.clean.fastq.gz ;
fi

##on a récuper les contig qu'on veut mapper et les reads donc il faut aller mapper
# mapping
bwa mem -t ${THREADS} ${REF} ${READS_F} ${READS_R} > ${INDIV}_bwa.sam

###donc 1er arg les coeurs --> certainement à diminuer si pas de place
###2 arg : le nom du fichier fasta qui contient tous les contigs
### 3 arg : le fichier contenant les reads F
### 4 arg : le ficher des read R
#### et on renvoie tout ca vers un fichier .sam c'est notre fichier de sortie


### mais il faut modifier notre . sam en .bam pour que les autres logiciels s'en servent
# indexation du génome de référence
### on doit refaire une indexation

if [[ ! -e ${REF}.fai ]] ; then
	samtools faidx ${REF}
fi


# compression des mappings
### des trucs pour transformer en .bam parce que c'est ce qu'on veut
samtools view -bt ${REF} ${INDIV}_bwa.sam > ${INDIV}_bwa.bam

# tri des fichiers bam
samtools sort ${INDIV}_bwa.bam -o ${INDIV}_bwa_sorted_bam.bam

# indexation des fichiers bam
samtools index ${INDIV}_bwa_sorted_bam.bam

# sortir du dossier de l'espèce
cd ..
