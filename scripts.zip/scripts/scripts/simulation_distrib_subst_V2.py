## install packages ###
import sys
import pandas as pd
import numpy as np ###pour faire des calculs 
import random ###truc pour randomiser

## arguments ###

 # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 5:
    sys.exit("ERROR : need 4 arguments : [1]path to the table of stat number of substitutions [2]path to the table of the number and length of the branches [3]name of the csv out file [4]number of simulations")
    # recuperer les arguments
tab_nb_subst = sys.argv[1] #tableau avec branche et le type de substitution
tab_num_len_br = sys.argv[2] #tableau avec branche et longueur de branche
out_file = sys.argv[3]
nb_simul = sys.argv[4]

## script ###

## read the tables ####
tab_nb_subst_pd = pd.read_csv(tab_nb_subst, sep="\t")
#print(tab_nb_subst_pd.head())
tab_num_len_br_pd = pd.read_csv(tab_num_len_br, sep=",")
#print(tab_num_len_br_pd.head())

## get total number of substitution in all branches ####
nb_subst_WS_tot = np.sum(tab_nb_subst_pd['nb_subst_WS']) ###on récupère le nb total de substitutios dans l'arbre pour l'exon 
nb_subst_WS_tot = round(nb_subst_WS_tot)
nb_subst_SW_tot = np.sum(tab_nb_subst_pd['nb_subst_SW'])
nb_subst_SW_tot = round(nb_subst_SW_tot)
print(nb_subst_WS_tot)
print(nb_subst_SW_tot)

## get numero and length of the branches, and number of branches ####
num_br = list(tab_num_len_br_pd['num']) #numéro de branche 
#print(num_br)
len_br = list(tab_num_len_br_pd['lg']) #liste avec les longueurs de branches 
#print(len_br)
nb_br = len(num_br) #nb de branches
#print(nb_br)

## get the cumul length of the branches ####
cum_len_br = np.cumsum(len_br) #longueurs cumulés des branches, donc colonne 3 de mon tableau dans carnet 
#print(cum_len_br)
proba_cum_len_br = cum_len_br/cum_len_br[-1] ###proba cumulés donc colonne 4 de tableau da  ns mon carnet --> cum_len_br[-1], ca sera le dernier élément de la liste 
#print(proba_cum_len_br[0])
#print(proba_cum_len_br[nb_br-1])

## simul the distribution of substitutions WS in the tree ####
tab_simul_distrib_subst = pd.DataFrame(list(zip(num_br)))
#print(tab_simul_distrib_subst.head())
for simul in range(1, int(nb_simul)+1): #int= integer --> ca veut dire un nb entier, float = nb à virgules
    simul_subst_br_WS = [0] * nb_br # une liste avec autant d'éléments que de branches et ds chaque branche on a 0 
    for subst in range(1, nb_subst_WS_tot+1):
        proba = random.random() #tire une proba entre 0 et 1 
        for br in range(0, nb_br):
            if proba <= proba_cum_len_br[br]:
                simul_subst_br_WS[br] = simul_subst_br_WS[br] + 1
                break ###permet d'arrêter la boucle 
    tab_simul_subst_br = pd.DataFrame(list(zip(simul_subst_br_WS))) ###on fait un tableau avec cette liste
    tab_simul_distrib_subst = pd.concat([tab_simul_distrib_subst,tab_simul_subst_br], axis=1)

## simul the distribution of substitutions SW in the tree ####
#simul_subst_br_SW = [0] * nb_br
#for subst in range(1, nb_subst_SW_tot+1):
#    proba = random.random()
#    for br in range(0, nb_br):
#        if proba <= proba_cum_len_br[br]:
#            simul_subst_br_SW[br] = simul_subst_br_SW[br] + 1
#            break

#tab_simul_distrib_subst = pd.DataFrame(list(zip(num_br, simul_subst_br_WS, simul_subst_br_SW)), columns = ['branches', 'nb_subst_WS', 'nb_subst_SW'])
#print(tab_simul_distrib_subst)

col_simul = list((range(1, int(nb_simul)+1)))
col_simul = ["branches"] + col_simul ###donne des noms de colonnes, la première est le numéro de branche et après le reste c'est le numéro de la simulation 
tab_simul_distrib_subst.columns = col_simul
tab_simul_distrib_subst.to_csv(out_file, index=False)
