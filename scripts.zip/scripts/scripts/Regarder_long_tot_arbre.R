
setwd("~/Documents/Darwin2/M2/S2/Stage/Stage gBC/donnees_primates.nosync")
data = read.csv("lg_tree.csv" , header = F, sep ="\t")

max(data$V2)

colnames(data) <- c("Gène", "Longueur total de l'arbre")


sum(data$`Longueur total de l'arbre` > 0)
nrow(data)
###inf à 1
sum(data$`Longueur total de l'arbre` < 1)
data_inf_1 = subset(data, data$`Longueur total de l'arbre` < 1)
head(data_inf_1[order(-data_inf_1$`Longueur total de l'arbre`), 1], 10)

###inf à 0.8
sum(data$`Longueur total de l'arbre` < 0.8)
nrow(data_inf_0.8)
data_inf_0.8 = subset(data, data$`Longueur total de l'arbre` < 0.8)
head(data_inf_0.8[order(-data_inf_0.8$`Longueur total de l'arbre`), 1], 10)


###inf à 0.6
sum(data$`Longueur total de l'arbre` < 0.6)
data_inf_0.6 = subset(data, data$`Longueur total de l'arbre` < 0.6)
head(data_inf_0.6[order(-data_inf_0.6$`Longueur total de l'arbre`), 1], 10)

###inf à 0.4
sum(data$`Longueur total de l'arbre` < 0.4)
data_inf_0.4 = subset(data, data$`Longueur total de l'arbre` < 0.4)
head(data_inf_0.4[order(-data_inf_0.4$`Longueur total de l'arbre`), 1], 10)


###inf à 0.2
sum(data$`Longueur total de l'arbre` < 0.2)
data_inf_0.2 = subset(data, data$`Longueur total de l'arbre` < 0.2)
head(data_inf_0.2[order(-data_inf_0.2$`Longueur total de l'arbre`), 1], 10)


###inf à 0.1
sum(data$`Longueur total de l'arbre` < 0.1)
data_inf_0.1 = subset(data, data$`Longueur total de l'arbre` < 0.1)
head(data_inf_0.1[order(-data_inf_0.1$`Longueur total de l'arbre`), 1], 10)

###inf à 0.08
sum(data$`Longueur total de l'arbre` < 0.08)
data_inf_0.08 = subset(data, data$`Longueur total de l'arbre` < 0.08)
head(data_inf_0.08[order(-data_inf_0.08$`Longueur total de l'arbre`), 1], 10)

###inf à 0.09
sum(data$`Longueur total de l'arbre` < 0.09)
data_inf_0.09 = subset(data, data$`Longueur total de l'arbre` < 0.09)
head(data_inf_0.09[order(-data_inf_0.09$`Longueur total de l'arbre`), 1], 10)


###inf à 0.07
sum(data$`Longueur total de l'arbre` < 0.07)
data_inf_0.07 = subset(data, data$`Longueur total de l'arbre` < 0.07)
head(data_inf_0.07[order(-data_inf_0.07$`Longueur total de l'arbre`), 1], 10)

###inf à 0.06
sum(data$`Longueur total de l'arbre` < 0.06)
data_inf_0.06 = subset(data, data$`Longueur total de l'arbre` < 0.06)
head(data_inf_0.06[order(-data_inf_0.06$`Longueur total de l'arbre`), 1], 10)

###inf à 0.05
sum(data$`Longueur total de l'arbre` < 0.05)
data_inf_0.05 = subset(data, data$`Longueur total de l'arbre` < 0.05)
head(data_inf_0.05[order(-data_inf_0.05$`Longueur total de l'arbre`), 1], 10)

hist(data$`Longueur total de l'arbre`)

hist(data$`Longueur total de l'arbre`,
     main = "Histogramme des longueurs d'arbre",
     xlab = "Longueur totale de l'arbre",
     ylab = "Fréquence",
     col = "lightblue",
     border = "white",
     breaks = 350)  # augmente le nombre de classes 

# Calcul de la moyenne et de la médiane
moyenne <- mean(data$`Longueur total de l'arbre`)
mediane <- median(data$`Longueur total de l'arbre`)

# Histogramme précis
hist(data$`Longueur total de l'arbre`,
     main = "Histogramme précis des longueurs d'arbre",
     xlab = "Longueur totale de l'arbre",
     ylab = "Fréquence",
     col = "lightblue",
     border = "white",
     breaks = 350)

# Ajout de la moyenne (ligne rouge)
abline(v = moyenne, col = "red", lwd = 2, lty = 2)
# Ajout de la médiane (ligne verte)
abline(v = mediane, col = "darkgreen", lwd = 2, lty = 2)

# Ajout de la légende
legend("topright",
       legend = c(paste0("Moyenne = ", round(moyenne, 3)),
                  paste0("Médiane = ", round(mediane, 3))),
       col = c("red", "darkgreen"),
       lty = 2,
       lwd = 2,
       bty = "n")





# Calcul de la moyenne et de la médiane
moyenne <- mean(data$`Longueur total de l'arbre`)
mediane <- median(data$`Longueur total de l'arbre`)

# Histogramme avec axe des abscisses plus précis
hist(data$`Longueur total de l'arbre`,
     main = "Histogramme des longueurs d'arbre",
     xlab = "Longueur totale de l'arbre",
     ylab = "Fréquence",
     col = "lightblue",
     border = "white",
     breaks = 350,
     xaxt = "n")  # On supprime les graduations automatiques de l'axe X

# Ajout de l'axe X avec des ticks tous les 0.05
axis(1, at = seq(from = floor(min(data$`Longueur total de l'arbre`)),
                 to = ceiling(max(data$`Longueur total de l'arbre`)),
                 by = 0.05), las = 2, cex.axis = 0.7)

# Ajout de la moyenne (ligne rouge)
abline(v = moyenne, col = "red", lwd = 2, lty = 2)

# Ajout de la médiane (ligne verte)
abline(v = mediane, col = "darkgreen", lwd = 2, lty = 2)

# Ajout de la légende
legend("topright",
       legend = c(paste0("Moyenne = ", round(moyenne, 3)),
                  paste0("Médiane = ", round(mediane, 3))),
       col = c("red", "darkgreen"),
       lty = 2,
       lwd = 2,
       bty = "n")














data_inf_3 =subset(data, data$`Longueur total de l'arbre` < 3)
# Calcul de la moyenne et de la médiane
moyenne_2 <- mean(data_inf_3$`Longueur total de l'arbre`)
mediane_2 <- median(data_inf_3$`Longueur total de l'arbre`)
long_arbre = 0.08
# Histogramme avec axe des abscisses plus précis
hist(data_inf_3$`Longueur total de l'arbre`,
     main = "Histogramme des longueurs d'arbre",
     xlab = "Longueur totale de l'arbre",
     ylab = "Fréquence",
     col = "lightblue",
     border = "white",
     breaks = 350,
     xaxt = "n")  # On supprime les graduations automatiques de l'axe X

# Ajout de l'axe X avec des ticks tous les 0.05
axis(1, at = seq(from = floor(min(data_inf_3$`Longueur total de l'arbre`)),
                 to = ceiling(max(data_inf_3$`Longueur total de l'arbre`)),
                 by = 0.005), las = 2, cex.axis = 0.7)

# Ajout de la moyenne (ligne rouge)
abline(v = moyenne_2, col = "red", lwd = 2, lty = 2)

# Ajout de la médiane (ligne verte)
abline(v = mediane_2, col = "darkgreen", lwd = 2, lty = 2)

abline(v= long_arbre, col = "black", lwd = 2, lty = 2)
# Ajout de la légende
legend("topright",
       legend = c(paste0("Moyenne = ", round(moyenne, 3)),
                  paste0("Médiane = ", round(mediane, 3)),
                  paste0("Longueur =", round(long_arbre, 3) )),
       col = c("red", "darkgreen", "black"),
       lty = 2,
       lwd = 2,
       bty = "n")












# Calcul de la densité
dens <- density(data$`Longueur total de l'arbre`)

# Affichage de la courbe
plot(dens,
     main = "Courbe de densité des longueurs d'arbre",
     xlab = "Longueur totale de l'arbre",
     ylab = "Densité estimée",
     col = "red",
     lwd = 2)
# Ajout de la moyenne (ligne rouge)
abline(v = moyenne, col = "red", lwd = 2, lty = 2)
# Ajout de la médiane (ligne verte)
abline(v = mediane, col = "darkgreen", lwd = 2, lty = 2)

# Ajout de la légende
legend("topright",
       legend = c(paste0("Moyenne = ", round(moyenne, 3)),
                  paste0("Médiane = ", round(mediane, 3))),
       col = c("red", "darkgreen"),
       lty = 2,
       lwd = 2,
       bty = "n")

# Calcul de la densité
dens <- density(data$`Longueur total de l'arbre`)

# Tracé de la densité avec suppression des axes par défaut
plot(dens,
     main = "Courbe de densité des longueurs d'arbre",
     xlab = "Longueur totale de l'arbre",
     ylab = "Densité estimée",
     col = "red",
     lwd = 2,
     xaxt = "n")  # On désactive l'axe x pour le redéfinir plus précisément

# Création de ticks plus précis sur l'axe des x
x_ticks <- pretty(dens$x, n = 20)  # 20 ticks "beaux"
axis(1, at = x_ticks)              # Redessin de l’axe x avec plus de précision









