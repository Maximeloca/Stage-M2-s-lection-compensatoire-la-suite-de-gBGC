#!/bin/bash

chemin_fasta=$1
nb_ind=$(grep -c ">" "$chemin_fasta")

# Extraire uniquement le nom du fichier sans le chemin
basename=$(basename "$chemin_fasta")

# Ajout du nombre d'individus et du fichier dans le CSV
echo -e "$nb_ind\t$basename" >> nb_esp_align.csv
