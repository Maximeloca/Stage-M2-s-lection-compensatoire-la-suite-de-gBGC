#!/bin/bash

# Nom du fichier avec les correspondances exon-cds
exon_to_cds_file="$1"  # Fichier des exon -> cds
input_file="$2"        # Fichier d'entrée avec les données à traiter
output_file="$3"       # Fichier de sortie


GENE=$(grep -w "${EXON}" ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)
POS=$(grep -w "${EXON}" ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

# Lire les correspondances exon-cds dans un tableau associatif (exon -> cds)
declare -A exon_to_cds
while IFS=, read -r exon cds; do
    if [[ "$exon" != "Exon" ]]; then  # Ignorer l'en-tête
        exon_to_cds["$exon"]="$cds"
    fi
done < "$exon_to_cds_file"

# Ajouter une nouvelle colonne "Gene" à partir de l'exon
awk -F, 'BEGIN {OFS=","} NR==1 {print "Gene", $0} NR>1 { 
    exon=$1
    if (exon in exon_to_cds) {
        gene = exon_to_cds[exon]
        print gene, $0
    } else {
        print "NA", $0  # Si pas trouvé, mettre "NA"
    }
}' "$input_file" > "$output_file"




#!/bin/bash

# Nom du fichier avec les correspondances exon-cds
exon_to_cds_file="$1"  # Fichier des exon -> cds
input_file="$2"        # Fichier d'entrée avec les données à traiter
output_file="$3"       # Fichier de sortie

# Lire les correspondances exon-cds dans un tableau associatif (exon -> cds)
declare -A exon_to_cds
while IFS=, read -r exon cds; do
    if [[ "$exon" != "Exon" ]]; then  # Ignorer l'en-tête
        exon_to_cds["$exon"]="$cds"
    fi
done < "$exon_to_cds_file"

# Ajouter une nouvelle colonne "Gene" à partir de l'exon
awk -F, 'BEGIN {OFS=","} NR==1 {print "Gene", $0} NR>1 { 
    exon=$1
    if (exon in exon_to_cds) {
        gene = exon_to_cds[exon]
        print gene, $0
    } else {
        print "NA", $0  # Si pas trouvé, mettre "NA"
    }
}' "$input_file" > "$output_file"

