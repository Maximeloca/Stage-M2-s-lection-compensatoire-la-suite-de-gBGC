# install packages ###
from Bio.SeqUtils import GC123
import sys
from Bio import SeqIO
from statistics import mean

# arguments ###
    # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]exon name [2]alignment file [3]file out name (csv file)")
    # recuperer les arguments
exon_name = sys.argv[1]
in_seq = sys.argv[2]
out_file = sys.argv[3]

# script ###
with open(out_file, 'w') as out: # open csv file to write results
    #out.write(f'seq_id\tGC3\n') # write header of the csv file
    GC12 = []
    GC3 = []
    for seq_read in SeqIO.parse(in_seq, 'fasta'): # for each seq read seq
        print(GC123(seq_read))
        GC3_seq = GC123(seq_read)[3] # get GC3
        GC12_seq = (GC123(seq_read)[1] + GC123(seq_read)[2]) / 2
        GC12.append(GC12_seq)
        GC3.append(GC3_seq)
    GC12_mean = mean(GC12)
    GC3_mean = mean(GC3)
    out.write(f'{exon_name}\t{GC12_mean}\t{GC3_mean}') # write seq id and GC3 for the seq
