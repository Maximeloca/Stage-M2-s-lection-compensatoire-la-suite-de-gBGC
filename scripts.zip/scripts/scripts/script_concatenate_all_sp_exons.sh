#! /bin/bash

# parametres ##

tribe=$1

# script ##

###va créer un giga fichier fasta contenant le nom des espèces et leurs séquences de tous les exons 

for sp in $(cat ~/Murinae/${tribe}/Data/list_species_${tribe}.txt) ; do
echo ">${sp}"
cat ~/Murinae/${tribe}/Aligned_concatenated_sequences/wt_chevrons/${sp}_all_seq_NT_aligned_final.fasta ;
done >> ${tribe}_all_seq_NT_aligned_final.fasta
