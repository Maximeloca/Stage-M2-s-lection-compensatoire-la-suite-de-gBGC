#!/bin/bash

ID=$1         # Prend l'ID en argument
Directory=$2  # Dossier contenant les fichiers .fasta
OutDir=$3     # Dossier de sortie

# Récupère le nom de l'espèce associé à l'ID
SPECIE=$(grep -w "$ID" ~/Cetacea/tab_species_id_corrected.csv | cut -f1)

# Parcours tous les fichiers .fasta dans le dossier source
for fasta in "$Directory"/*.fasta; do
    # Crée un fichier modifié dans le dossier de sortie
    sed "s/^>$ID$/>$SPECIE/" "$fasta" > "$OutDir/$(basename "$fasta")"
done
