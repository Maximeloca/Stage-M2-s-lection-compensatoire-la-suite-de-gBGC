#!/bin/bash

folder=$1

cd ~/Donnees_Cetaces/Baits_Genes_Corrected/"$folder"
cp *_Align.fa.fasta ~/Donnees_Cetaces/Sequence_verif/
