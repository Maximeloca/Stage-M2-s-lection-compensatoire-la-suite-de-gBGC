#!/usr/bin/env Rscript

## Arguments ###
args = commandArgs(trailingOnly=TRUE)
print(args)
if (length(args)<4) {
  stop("4 arguments must be supplied : [1] input tree (newick format) [2] first outgroup [3] second outgroup [4] name of the rooted phylogeny", call.=FALSE)
}

tree = args[1] # complete phylogeny
outgroup1 = args[2] # first outgroup
outgroup2 = args[3] # second outgroup
rooted_tree = args[4] # name of the rooted phylogeny

## load packages ###
library(ape)

## script ###
# read the phylogeny
phylo <- read.tree(file = tree)

# root the phylogeny with both outgroups
rooted_phylo <- root(phylo, outgroup = c(outgroup1, outgroup2), resolve.root = T)

# save this rooted phylogeny
ape::write.tree(rooted_phylo, file=rooted_tree)