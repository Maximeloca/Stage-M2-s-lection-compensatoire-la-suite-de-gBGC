#!/bin/bash

EXON=$1
outfile=$2

GENE=$(grep -w "${EXON}" ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)
POS=$(grep -w "${EXON}" ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

mkdir ~/Murinae/Rattini/Aligned_Sequences/FINAL/finder_subst/"$outfile"

cp ~/Murinae/Rattini/Aligned_Sequences/FINAL/${GENE}_${EXON}_${POS}_FINAL_align_NT.fasta ~/Murinae/Rattini/Aligned_Sequences/FINAL/finder_subst/"$outfile"/
