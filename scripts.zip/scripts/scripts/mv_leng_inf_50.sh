#! /bin/bash

# parametres ###

file=$1
chemin_entree=$2
chemin_sortie=$3

# Récupération de la longueur d'alignement depuis le CSV
leng_align=$(grep "$file" ~/Cetacea/Aligned_Sequences/FINAL/alignment_lengths.csv | cut -f2)

# Vérification et déplacement si nécessaire
if [[ "$leng_align" -le 49 ]]; then
    mv "$chemin_entree"/"$file" "$chemin_sortie"
fi