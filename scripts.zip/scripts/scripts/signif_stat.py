## install packages ###
import sys
import pandas as pd
import os

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 7:
    sys.exit("ERROR : need 6 arguments : [1]path to the table of number of substitutions [2]path to the table of Moran's I [3]path to the table of the simulated number of substitutions [4]path to the table of the simulated Moran's I [5]csv out name [6]number of simulations")
    # recuperer les arguments
tab_nb_subst_path = sys.argv[1] #chemin vers le tableau vers le nb de subst dans chaque branche, tableau obs
tab_I_path = sys.argv[2] #valeur de I obs 
tab_simul_nb_subst_path = sys.argv[3] #tableau du nb de subst attendu
tab_simul_I_path = sys.argv[4] #tableau simul I 
csv_out_name = sys.argv[5]
nb_simul = sys.argv[6]

## script ###

nb_simul = int(nb_simul) #on précise que c'est un nb

# read tables
tab_nb_subst = pd.read_csv(tab_nb_subst_path, sep='\t')
tab_simul_nb_subst = pd.read_csv(tab_simul_nb_subst_path, sep=',')

if os.path.exists(tab_simul_I_path): #si ce fichier existe 
    tab_I = pd.read_csv(tab_I_path, sep=',')
if os.path.exists(tab_simul_I_path):
    tab_simul_I = pd.read_csv(tab_simul_I_path, sep=',')
    I_branches = list(tab_simul_I['branches'])
    tab_simul_I.index = I_branches

# nb branches and list of branches
nb_br = len(tab_nb_subst.columns) #longueur des colonnes = nb de branches 
branches = list(tab_simul_nb_subst['branches']) #liste des numéros de branches

# nb_subst
nb_subst_WS_signif = []
for br in branches:
    nb_subst_WS = tab_nb_subst[tab_nb_subst['branches'] == br]['nb_subst_WS'].iloc[0] #récupère pour la branche donnée le nb de subst obs WS
    nb_subst_WS = round(nb_subst_WS, 1) #on arrondi à la décimal la plus proche 
    count = 0
    if(nb_subst_WS < 1.8): #il faut au moins deux substitutions pour avoir un épisode 
        count = 0
    else:
        nb_subst_WS_simul_br = tab_simul_nb_subst[tab_simul_nb_subst['branches'] == br] #liste de la ligne contenant toutes les substitutions attendus pour une branche pour chaque simul
        nb_subst_WS_simul_br = nb_subst_WS_simul_br.iloc[0]
        for i in range(1, nb_simul+1):
            nb_subst_WS_simul = nb_subst_WS_simul_br.iloc[i] #récupère le nb de subst de la simulation i 
            if nb_subst_WS > int(nb_subst_WS_simul): #est ce que le nb de subst obs est supérieur à la simul
                count = count + 1
            elif nb_subst_WS == int(nb_subst_WS_simul): #si c'est égal entre obs et simul on ajoute juste +0,5
                count = count + 0.5
    nb_subst_WS_signif.append(count)
tab_nb_subst_WS_signif = pd.DataFrame({'branches':branches, #crée un data à partir d'une liste, contenant les colonnes branches et les colonnes signif_nb_WS
                                       'signif_nb_WS':nb_subst_WS_signif})
tab_nb_subst_WS_signif.to_csv(csv_out_name, index=False) #index = False pas de numéro de ligne 

# I Moran
if os.path.exists(tab_simul_I_path):
    I_signif = []
    I_branches = list(tab_simul_I['branches'])
    for br in I_branches:
        I_WS = tab_I[tab_I['branch_number'] == br]['WS'].iloc[0]
        count = 0
        I_WS_simul_br = tab_simul_I[tab_simul_I['branches'] == br]
        I_WS_simul_br = I_WS_simul_br.iloc[0]
        for i in range(1, nb_simul+1):
            I_WS_simul = I_WS_simul_br.iloc[i]
            if I_WS_simul == 'NA':
                count = count + 0
            elif float(I_WS) == float(I_WS_simul):
                count = count + 0.5
            elif float(I_WS) > float(I_WS_simul):
                count = count + 1
        I_signif.append(count)
else:
    I_branches = branches
    I_signif = ['NA'] * len(branches)


tab_I_signif = pd.DataFrame({'branches':I_branches,
                             'signif_I':I_signif})

tab_signif = pd.merge(tab_nb_subst_WS_signif, tab_I_signif, on='branches', how='outer')
print(tab_signif.head())

tab_signif.to_csv(csv_out_name, index=False, na_rep='NA')
