#!/usr/bin/env Rscript

## Arguments ###
args = commandArgs(trailingOnly=TRUE)
print(args)
if (length(args)<14) {
  stop("4 arguments must be supplied : [1] input tree (newick format) [2-13] outgroups [14] name of the rooted phylogeny", call.=FALSE)
}

tree = args[1] # complete phylogeny
outgroup1 = args[2] # first outgroup
outgroup2 = args[3] # second outgroup
outgroup3 = args[4]
outgroup4 = args[5]
outgroup5 = args[6]
outgroup6 = args[7]
outgroup7 = args[8]
outgroup8 = args[9]
outgroup9 = args[10]
outgroup10 = args[11]
outgroup11 = args[12]
outgroup12 = args[13]
rooted_tree = args[14] # name of the rooted phylogeny

## load packages ###
library(ape)

## script ###
# read the phylogeny
phylo <- read.tree(file = tree)

# root the phylogeny with both outgroups
rooted_phylo <- root(phylo, outgroup = c(outgroup1, outgroup2,outgroup3,outgroup4,outgroup5,outgroup6,outgroup7,outgroup8,outgroup9,outgroup10,outgroup11,outgroup12), resolve.root = T)

# save this rooted phylogeny
ape::write.tree(rooted_phylo, file=rooted_tree)