#! /bin/bash

# Arguments ###

EXON=$1
TRIBE=$2
NB_SIMUL=$3

# Script ###


cd Br_lg_tables
#if [[ ! -e ${GENE}_br_len.csv ]] ;then

###vérifier que le programme num_br_lg est présent, ce script donne les numéros de branches avec la longueur de branche 
~/bin/num_br_lg/tpn ~/${TRIBE}/Phylogeny/exon_tree/${EXON}_tree.treefile ${EXON}_br_len.csv ;
#fi
cd ..

echo -e "exon : $EXON"

lg_seq=$(grep $EXON ~/${TRIBE}/Aligned_Sequences/FINAL/wt_outgroup/exons_len.csv | cut -f2)
echo -e "lg seq = $lg_seq"

if [ ${lg_seq} -gt 999 ] ; then ###on e fait que si c'est supérieur à 1000
cd I_Moran
python3 ~/scripts/simul_I_Moran_V3.py ~/${TRIBE}/Detecting_gBGC/Distrib_subst_S/${EXON}_stat_nb_subst.csv ${lg_seq} ${EXON}_I_simul.csv $NB_SIMUL
###on tire au hasard la position des subst
cd ..
fi

cd Distrib_subst
python3 ~/scripts/simulation_distrib_subst_V2.py ~/${TRIBE}/Detecting_gBGC/Distrib_subst_S/${EXON}_stat_nb_subst.csv ~/${TRIBE}/Randomisations/Br_lg_tables/${EXON}_br_len.csv ${EXON}_distrib_subst_simul.csv $NB_SIMUL
cd ..
