#! /bin/bash

# parametres ###

TRIBE=$1
GENE=$2

# script ###

EXON=$(grep "${GENE}" ~/Murinae/${TRIBE}/Aligned_Sequences/FINAL/Final_genes_exons_pos_list.txt | head -1 | cut -f2) #on peut prendre n'importe lequel d'exon car ils ont tous les mêmes espèces
EXON_POSITION=$(grep  "${GENE}" ~/Murinae/${TRIBE}/Aligned_Sequences/FINAL/Final_genes_exons_pos_list.txt | head -1 | cut -f3)

Rscript ~/scripts/script_prune_tree.R ~/Murinae/${TRIBE}/Phylogeny/${TRIBE}_double_rooted_tree.treefile ~/Murinae/${TRIBE}/Aligned_Sequences/FINAL/${GENE}_${EXON}_${EXON_POSITION}_FINAL_align_NT.fasta ${GENE}_tree.treefile
