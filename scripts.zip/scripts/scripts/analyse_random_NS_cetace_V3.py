## install packages ###
import sys
import pandas as pd
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 5:
    sys.exit("ERROR : need 4 arguments : [1]gene name [2]directory of the tab recap [3]directory of the tab random NS [4]list of paralogs exons")
# recuperer les arguments
exon_name = sys.argv[1]
tab_recap_dir = sys.argv[2]
tab_randomNS_dir = sys.argv[3]
paralogs_list_file = sys.argv[4]

## script ###

# get the paralogs list ####crée une liste des fichiers paralogues 
with open(paralogs_list_file, "r") as file_paralogs_list:
    file_paralogs_list_read = file_paralogs_list.read().strip()
    paralogs_list = file_paralogs_list_read.split()

exon = exon_name
print(exon)
# read the table
tab_recap_name = tab_recap_dir + "_tab_recap.csv" #récupère le tableau récap du gène
tab_recap_with_paralogs = pd.read_csv(tab_recap_name, sep='\t') 
    
# remove paralogs exons
tab_recap = tab_recap_with_paralogs[~tab_recap_with_paralogs.Exon.isin(paralogs_list)] #enlève les exons faisant partie des paralogues, le ~ permet de faire l'inverse

# list of exons
exons_list = list(tab_recap['Exon']) #refait du coup la liste d'exon sans paralogue 
exons_list = set(exons_list) # equivalent of uniq
exons_list = list(exons_list) # equivalent of uniq
print(exons_list)
    
# list of exons with episodes
exons_episodes = list(tab_recap[(tab_recap['Episode'] == 'YES') & (pd.notna(tab_recap['Br_Asc']))]['Exon']) ### récupère la liste des épisodes sans prendre ceux qui n'ont pas de branche ascendante
###on ne fait pas confiance à ce que le mapping a mis dans les branches basales 
exons_episodes = set(exons_episodes) # equivalent of uniq
exons_episodes = list(exons_episodes) # equivalent of uniq
print(exons_episodes)


exons_post_epNS = []
exons_post_epnoNS = []

###ATTENTION ON S'EN FOU DE TOUT CE QUI EST DANS LES AUTRES EXONS, LES 2 BLOCS DE 4 SAUTENT 
#exons_otherex_durepNS = []
#otherex_otherex_durepNS = []
#exons_otherex_durepnoNS = []
#otherex_otherex_durepnoNS = []

#exons_otherex_postepNS = []
#otherex_otherex_postepNS = []
#exons_otherex_postepnoNS = []
#otherex_otherex_postepnoNS = []

#for exon in exons_list: #pour chaque exon de la liste 
    ###PARTIE 1 DE LA BOUCLE : VA RÉCUPÉRER POUR CHAQUE EXON LES BRANCHES PRÉSENTANT UN ÉPISODE ET QUI NE PRÉSENTENT PAS DE NA POUR LES BRANCHES DESCENDANTES ET ASCENDANTES 
 #   print(exon)
    # list other exons of the same gene
    #other_exons_list = list(exons_list) #liste d'exons
    #other_exons_list.remove(exon) #on enlève de la liste d'exon l'xon qu'on est en train de traiter 
    # list of branches with episodes
tab_exon = tab_recap[tab_recap['Exon'] == exon] # lignes de l'exons concernés 
   # pos_exon = int(list(tab_exon['exon_pos'])[0]) #position de l'exon [0] car on prend le premier 
   # pas besoin de pos exon
   # print(pos_exon)
tab_exon_ep = tab_exon[(tab_exon['Episode'] == 'YES') & (pd.notna(tab_exon['Br_Asc'])) & (pd.notna(tab_exon['Br_Desc1']))] #récupère les lignes présentant des épisodes ou les branches ascendantes Ne sont pas NA et les descendantes ne sont pas NA non plus
br_ep = list(tab_exon_ep['Br']) #liste des branches présentant un épisodes et répondant au critère de pas de branches ascendantes qui sont NA et descendantes qui sont NA 
print(br_ep)   
            
    ##### NS after the episodes with at least 1 subst NS WS #####
    # list of the branches after the episodes NS & no episode in these branches
tab_exon_epNS = tab_exon_ep[tab_exon_ep['Nb_subst_NS_WS'] > 0.6] ###Récupère les épisodes présentant au moins une substitutions NS 
br_epNS = list(tab_exon_epNS['Br']) ##récupère le numéro des branches présentant un épisode et une substitution NS
print(br_epNS)
br_postepNS = []
    #ep_uniq_exon = []
    #pas besoin car on ne regarde pas les autres exons
for br in br_epNS: #pour chaque branche présentant un épisode et au moins une subst NS
    br_desc1 = tab_exon[tab_exon['Br'] == br]['Br_Desc1'].iloc[0] #récupère la branche descendante 1 de la ranche avec l'épisode et na subst NS
    br_desc2 = tab_exon[tab_exon['Br'] == br]['Br_Desc2'].iloc[0] #récupère la branche descendante 2 de la ranche avec l'épisode et na subst NS
    br_postepNS.append(br_desc1) #place la branche 1 dans la liste des branches post ep
    br_postepNS.append(br_desc2) #place la branche 2 dans la liste des branches post ep
        # counter of nb ep in same br of other ex initiates at zero 
        #nb_ep_other_ex = 0
        # search if ep in same br in other ex
        #for other_exon in other_exons_list: #pour chaque exon de la liste mais du coup on a enlevé l'exon qu'on vient de faire donc on regarde si dans les autres exons 
        #    tab_other_exon = tab_recap[tab_recap['Exon'] == other_exon]
        #    pval = tab_other_exon[tab_other_exon['Br'] == br]['signif_nb_subst_S_WS'].iloc[0] #on récupère le nb de fois ou les autres exons ont un obs > à l'attendu 
        #    if pval > 200: ###si la pval est > 200 on rajoute +1 à nb_ep_other_ex --> mais c'est hyper stringeant 
        #        nb_ep_other_ex += 1 
        #if nb_ep_other_ex > 0: #si nb_ep_other_ex est supérieur à 0 alors on rajoute un NO sinon on rajoute un YES
        #    ep_uniq_exon.append('NO')
        #    ep_uniq_exon.append('NO')
        #else:
        #    ep_uniq_exon.append('YES')
        #    ep_uniq_exon.append('YES')
print(br_postepNS)
if br_postepNS: ###Si on a une branche post ep
    exons_post_epNS.append(exon) #on ajoute l'exon à la liste 
    # tab of br asc br desc ep (=br ep), lg br asc br desc ep (=br ep), and br br desc ep 
    br_post_list = []
    br_asc_list = []
    br_asc_lg_list = []
    for br in br_postepNS: #Pour chaque branche post ep
        br_asc = tab_exon[tab_exon['Br'] == br]['Br_Asc'].iloc[0] ##récupère la branche ascendante
        br_asc_lg = tab_exon[tab_exon['Br'] == br_asc]['Br_lg'].iloc[0] #récupère la longueur de la branche ascendante
        br_post_list.append(br) #ajoute la branche post epis à la liste 
        br_asc_list.append(br_asc) #ajoute la branche ascendante
        br_asc_lg_list.append(br_asc_lg) #longueur de la branche ascendante
    tab_br_asc_lg = pd.DataFrame({'Br': br_post_list, ###crée le data frame avec la branche post epi, la branche ascendante et sa longueur
        			'Br_asc': br_asc_list,
        			'Br_asc_lg': br_asc_lg_list})
        # tab of exon with theses branches
    tab_exon_postepNS = tab_exon[tab_exon['Br'].isin(br_postepNS)] ### récupère dans tab_exon les branches correspondant au branche post ep qu'on a choisi 
        # observed nb of subst NS WS after the episodes #crée un tableau avec le nb de subst NS WS dans les branches post ep, récupère toutes les infos notés, exon, Lg_seq, GC12, ...
    tab_nb_obs_NS_WS_after_epNS = tab_exon_postepNS[['Exon',  'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
        # observed nb of subst NS SW after the episodes
    tab_nb_obs_NS_SW_after_epNS = tab_exon_postepNS[['Exon', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_SW']]
        # observed nb of subst NS SS after the episodes
    tab_nb_obs_NS_SS_after_epNS = tab_exon_postepNS[['Exon', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_SS']]
        # observed nb of subst NS WW after the episodes
    tab_nb_obs_NS_WW_after_epNS = tab_exon_postepNS[['Exon', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_WW']]
        # expected nb of subst NS WS after the episodes
    tab_randomNS_WS_exon_name = tab_randomNS_dir + "_simul_distrib_subst_WS_NS.csv" #tableau correspondant au randomisation NS_WS
    tab_randomNS_WS_exon = pd.read_csv(tab_randomNS_WS_exon_name, sep=',')
    tab_randomNS_WS_exon_brpostepNS = tab_randomNS_WS_exon[tab_randomNS_WS_exon['branches'].isin(br_postepNS)] ###récupère le nb de subst NS dans les randomisation pour les branches post ep
    tab_randomNS_WS_exon_brpostepNS = tab_randomNS_WS_exon_brpostepNS.rename(columns={'branches': 'Br'}) #on renomme la colonnes branches par Br pour pouvoir merger après 
        # expected nb of subst NS SW after the episodes
    tab_randomNS_SW_exon_name = tab_randomNS_dir + "_simul_distrib_subst_SW_NS.csv"
    tab_randomNS_SW_exon = pd.read_csv(tab_randomNS_SW_exon_name, sep=',')
    tab_randomNS_SW_exon_brpostepNS = tab_randomNS_SW_exon[tab_randomNS_SW_exon['branches'].isin(br_postepNS)]
    tab_randomNS_SW_exon_brpostepNS = tab_randomNS_SW_exon_brpostepNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS SS after the episodes
    tab_randomNS_SS_exon_name = tab_randomNS_dir + "_simul_distrib_subst_SS_NS.csv"
    tab_randomNS_SS_exon = pd.read_csv(tab_randomNS_SS_exon_name, sep=',')
    tab_randomNS_SS_exon_brpostepNS = tab_randomNS_SS_exon[tab_randomNS_SS_exon['branches'].isin(br_postepNS)]
    tab_randomNS_SS_exon_brpostepNS = tab_randomNS_SS_exon_brpostepNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS WW after the episodes
    tab_randomNS_WW_exon_name = tab_randomNS_dir + "_simul_distrib_subst_WW_NS.csv"
    tab_randomNS_WW_exon = pd.read_csv(tab_randomNS_WW_exon_name, sep=',')
    tab_randomNS_WW_exon_brpostepNS = tab_randomNS_WW_exon[tab_randomNS_WW_exon['branches'].isin(br_postepNS)]
    tab_randomNS_WW_exon_brpostepNS = tab_randomNS_WW_exon_brpostepNS.rename(columns={'branches': 'Br'})
        # final tables for NS after ep
    if exon == exons_post_epNS[0]: #si l'exon correspond au premier exon de la liste, on crée le data frame sinon on va le concaténer avec celui des autres exons 
            # WS --> on ne peut pas merge deux tableau alors il est fait en deux fois 
        tab_NS_WS_after_epNS = pd.merge(tab_nb_obs_NS_WS_after_epNS, tab_randomNS_WS_exon_brpostepNS, how='left', on='Br')
        tab_NS_WS_after_epNS = pd.merge(tab_NS_WS_after_epNS, tab_br_asc_lg, how='left', on='Br')
            # SW
        tab_NS_SW_after_epNS = pd.merge(tab_nb_obs_NS_SW_after_epNS, tab_randomNS_SW_exon_brpostepNS, how='left', on='Br')
        tab_NS_SW_after_epNS = pd.merge(tab_NS_SW_after_epNS, tab_br_asc_lg, how='left', on='Br')
            # SS
        tab_NS_SS_after_epNS = pd.merge(tab_nb_obs_NS_SS_after_epNS, tab_randomNS_SS_exon_brpostepNS, how='left', on='Br')
        tab_NS_SS_after_epNS = pd.merge(tab_NS_SS_after_epNS, tab_br_asc_lg, how='left', on='Br')
            # WW
        tab_NS_WW_after_epNS = pd.merge(tab_nb_obs_NS_WW_after_epNS, tab_randomNS_WW_exon_brpostepNS, how='left', on='Br')
        tab_NS_WW_after_epNS = pd.merge(tab_NS_WW_after_epNS, tab_br_asc_lg, how='left', on='Br')

            

    ##### NS after the episodes with no subst NS WS ##### --> idem que au dessus sauf que cette fois ci c'est pour les épisodes ne présentant aucune substitution NS
    # list of the branches after these episodes & no episodes in these branches
    tab_exon_epnoNS = tab_exon_ep[tab_exon_ep['Nb_subst_NS_WS'] < 0.4]
    br_epnoNS = list(tab_exon_epnoNS['Br'])
    print(br_epnoNS)
    br_postepnoNS = []
    ep_uniq_exon = []
    for br in br_epnoNS:
        br_desc1 = tab_exon[tab_exon['Br'] == br]['Br_Desc1'].iloc[0]
        br_desc2 = tab_exon[tab_exon['Br'] == br]['Br_Desc2'].iloc[0]
        br_postepnoNS.append(br_desc1)
        br_postepnoNS.append(br_desc2)
        # counter of nb ep in same br of other ex initiates at zero 
        #nb_ep_other_ex = 0
        # search if ep in same br in other ex
    print(br_postepnoNS)
    print(ep_uniq_exon)
    if br_postepnoNS:
        exons_post_epnoNS.append(exon)
        # tab of br asc br desc ep (=br ep), lg br asc br desc ep (=br ep), and br br desc ep 
        br_post_list = []
        br_asc_list = []
        br_asc_lg_list = []
        for br in br_postepnoNS:
            br_asc = tab_exon[tab_exon['Br'] == br]['Br_Asc'].iloc[0]
            br_asc_lg = tab_exon[tab_exon['Br'] == br_asc]['Br_lg'].iloc[0]
            br_post_list.append(br)
            br_asc_list.append(br_asc)
            br_asc_lg_list.append(br_asc_lg)
        tab_br_asc_lg = pd.DataFrame({'Br': br_post_list,
        				'Br_asc': br_asc_list,
        				'Br_asc_lg': br_asc_lg_list})
        # tab of exon with theses branches
        tab_exon_postepnoNS = tab_exon[tab_exon['Br'].isin(br_postepnoNS)]
        # observed nb of subst NS WS after the episodes
        tab_nb_obs_NS_WS_after_epnoNS = tab_exon_postepnoNS[['Exon', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
        # observed nb of subst NS SW after the episodes
        tab_nb_obs_NS_SW_after_epnoNS = tab_exon_postepnoNS[['Exon', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_SW']]
        # observed nb of subst NS SS after the episodes
        tab_nb_obs_NS_SS_after_epnoNS = tab_exon_postepnoNS[['Exon', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_SS']]
        # observed nb of subst NS WW after the episodes
        tab_nb_obs_NS_WW_after_epnoNS = tab_exon_postepnoNS[['Exon', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_WW']]
        # expected nb of subst NS WS after the episodes
        tab_randomNS_WS_exon_name = tab_randomNS_dir + "_simul_distrib_subst_WS_NS.csv"
        tab_randomNS_WS_exon = pd.read_csv(tab_randomNS_WS_exon_name, sep=',')
        tab_randomNS_WS_exon_brpostepnoNS = tab_randomNS_WS_exon[tab_randomNS_WS_exon['branches'].isin(br_postepnoNS)]
        tab_randomNS_WS_exon_brpostepnoNS = tab_randomNS_WS_exon_brpostepnoNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS SW after the episodes
        tab_randomNS_SW_exon_name = tab_randomNS_dir + "_simul_distrib_subst_SW_NS.csv"
        tab_randomNS_SW_exon = pd.read_csv(tab_randomNS_SW_exon_name, sep=',')
        tab_randomNS_SW_exon_brpostepnoNS = tab_randomNS_SW_exon[tab_randomNS_SW_exon['branches'].isin(br_postepnoNS)]
        tab_randomNS_SW_exon_brpostepnoNS = tab_randomNS_SW_exon_brpostepnoNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS SS after the episodes
        tab_randomNS_SS_exon_name = tab_randomNS_dir + "_simul_distrib_subst_SS_NS.csv"
        tab_randomNS_SS_exon = pd.read_csv(tab_randomNS_SS_exon_name, sep=',')
        tab_randomNS_SS_exon_brpostepnoNS = tab_randomNS_SS_exon[tab_randomNS_SS_exon['branches'].isin(br_postepnoNS)]
        tab_randomNS_SS_exon_brpostepnoNS = tab_randomNS_SS_exon_brpostepnoNS.rename(columns={'branches': 'Br'})
        # expected nb of subst NS WW after the episodes
        tab_randomNS_WW_exon_name = tab_randomNS_dir + "_simul_distrib_subst_WW_NS.csv"
        tab_randomNS_WW_exon = pd.read_csv(tab_randomNS_WW_exon_name, sep=',')
        tab_randomNS_WW_exon_brpostepnoNS = tab_randomNS_WW_exon[tab_randomNS_WW_exon['branches'].isin(br_postepnoNS)]
        tab_randomNS_WW_exon_brpostepnoNS = tab_randomNS_WW_exon_brpostepnoNS.rename(columns={'branches': 'Br'})
        # final tables for NS after ep
        if exon == exons_post_epnoNS[0]:
            # WS
            tab_NS_WS_after_epnoNS = pd.merge(tab_nb_obs_NS_WS_after_epnoNS, tab_randomNS_WS_exon_brpostepnoNS, how='left', on='Br')
            tab_NS_WS_after_epnoNS = pd.merge(tab_NS_WS_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            # SW
            tab_NS_SW_after_epnoNS = pd.merge(tab_nb_obs_NS_SW_after_epnoNS, tab_randomNS_SW_exon_brpostepnoNS, how='left', on='Br')
            tab_NS_SW_after_epnoNS = pd.merge(tab_NS_SW_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            # SS
            tab_NS_SS_after_epnoNS = pd.merge(tab_nb_obs_NS_SS_after_epnoNS, tab_randomNS_SS_exon_brpostepnoNS, how='left', on='Br')
            tab_NS_SS_after_epnoNS = pd.merge(tab_NS_SS_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
            # WW
            tab_NS_WW_after_epnoNS = pd.merge(tab_nb_obs_NS_WW_after_epnoNS, tab_randomNS_WW_exon_brpostepnoNS, how='left', on='Br')
            tab_NS_WW_after_epnoNS = pd.merge(tab_NS_WW_after_epnoNS, tab_br_asc_lg, how='left', on='Br')
   
            
    #### peut être tout virer ce qui est sur les autres exons --> c'est fait   

if exons_post_epNS:
    tab_NS_WS_after_epNS.to_csv(exon + '_tab_NS_WS_after_epNS_with_random.csv', index=False)
    tab_NS_SW_after_epNS.to_csv(exon + '_tab_NS_SW_after_epNS_with_random.csv', index=False)
    tab_NS_SS_after_epNS.to_csv(exon + '_tab_NS_SS_after_epNS_with_random.csv', index=False)
    tab_NS_WW_after_epNS.to_csv(exon + '_tab_NS_WW_after_epNS_with_random.csv', index=False)

if exons_post_epnoNS:
    tab_NS_WS_after_epnoNS.to_csv(exon + '_tab_NS_WS_after_epnoNS_with_random.csv', index=False)
    tab_NS_SW_after_epnoNS.to_csv(exon + '_tab_NS_SW_after_epnoNS_with_random.csv', index=False)
    tab_NS_SS_after_epnoNS.to_csv(exon + '_tab_NS_SS_after_epnoNS_with_random.csv', index=False)
    tab_NS_WW_after_epnoNS.to_csv(exon + '_tab_NS_WW_after_epnoNS_with_random.csv', index=False)
