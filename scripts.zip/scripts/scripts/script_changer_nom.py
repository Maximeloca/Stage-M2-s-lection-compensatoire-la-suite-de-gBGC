## Install packages ###
import sys
import os
from Bio import SeqIO

## Arguments ###
# Vérifie que le nombre d'arguments est correct
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments: [1]alignment [2]output folder path [3]ID mapping file")

# Récupère les arguments
align = sys.argv[1]  # fichier FASTA
out_folder = sys.argv[2]  # Dossier où enregistrer les fichiers modifiés
liste_fichier_sp_id = sys.argv[3]  # Fichier contenant les correspondances ID -> espèce

# Crée le nom du fichier de sortie
base_name = os.path.splitext(os.path.basename(align))[0]  # Récupère le nom sans extension
out_file_name = os.path.join(out_folder, f"{base_name}.fasta")  # Définit le fichier de sortie

# Ouvre le fichier de sortie et écrit les séquences modifiées
with open(out_file_name, "w") as out:
    for seq_read in SeqIO.parse(align, 'fasta'):
        seq_id = seq_read.id
        seq_seq = seq_read.seq

        # Récupération du nom de l'espèce à partir du fichier de correspondance
        SPECIE = seq_id  # Valeur par défaut (si pas trouvé dans le fichier)
        with open(liste_fichier_sp_id, "r") as machin:
            for line in machin:
                parts = line.strip().split("\t")  # Séparation par tabulation
                if len(parts) == 2:
                    species_name, short_id = parts
                    if short_id == seq_id:
                        SPECIE = species_name
                        #break  # Arrêter la recherche dès qu'on trouve une correspondance

        out.write(f'>{SPECIE}\n{seq_seq}\n')