#! /bin/bash

# Arguments ###

EXON=$1

# Script ###


# arbre global : forcer topologie et obtenir longueurs branches avec iqtree
iqtree2 -s ~/Cetacea/Aligned_Sequences/FINAL/wt_outgroup/${EXON}  -nt 1 -m GTR -keep-ident -g ~/Cetacea/Phylogeny/exon_tree/${EXON}_tree.treefile --prefix ${EXON}_tree_g >out_iqtree_global_${EXON}.txt 2>error_iqtree_global_${EXON}.txt
### on calcule les longueurs de branches en forcant la topologie et en lui donnant les alignements 
### -nt nb de CPU obligatoire d'ê à 1 CPU
### keep-ident --> fais quand même même si on a des séquences très similaires 
### -g --> pour lui donner la topologie 

# arbre exon avec iqtree
iqtree2 -s ~/Cetacea/Aligned_Sequences/FINAL/wt_outgroup/${EXON}  -nt 1 -m GTR --prefix ${EXON}_tree_e >out_iqtree_exon_${EXON}.txt 2>error_iqtree_exon_${EXON}.txt
### on impose pas la topologie mais on lui donne la séquence de l'alignement de l'exon ou il n'y a plus que les espèces communes entre tous les exons 

# calculer longueur tot arbre global
python3 ~/scripts/lg_tree.py ~/Cetacea/Sup_filter_paralogs/${EXON}_tree_g.treefile lg_tree_g_${EXON}.txt >out_lg_tot_tree_g_${EXON}.txt 2>error_lg_tot_tree_g_${EXON}.txt
lg_tree_g=$(cat lg_tree_g_${EXON}.txt)

# calculer longueur tot arbre exon
python3 ~/scripts/lg_tree.py ~/Cetacea/Sup_filter_paralogs/${EXON}_tree_e.treefile lg_tree_e_${EXON}.txt >out_lg_tot_tree_e_${EXON}.txt 2>error_lg_tot_tree_e_${EXON}.txt
lg_tree_e=$(cat lg_tree_e_${EXON}.txt)

# recuperer longueur de la sequence
lg=$(grep ${EXON} ~/Cetacea/Aligned_Sequences/FINAL/wt_outgroup/align_len.csv | cut -f2)

# faire tableau
echo -e "${EXON}\t${lg}\t${lg_tree_g}\t${lg_tree_e}"

