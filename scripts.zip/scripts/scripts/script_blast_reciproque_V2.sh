#! /bin/bash

## parametres ##

EXON=$1
BLAST_EXONS_VS_CONTIGS=$2
ASSEMBLY=$3
SPECIE=$4
suppr=${5:-1} # supprimer les fichiers intermediaires : 1 oui ; 2 non : par défault : 1
### le 1 permet de supprimer les fichiers intermédiaires

## script ##

# nom du gene auquel appartient l'exon
gene=$(grep -w "${EXON}" ${BLAST_EXONS_VS_CONTIGS} | head -1 | cut -f2 | cut -f1 -d"|")

# position de l'exon dans le gene
exon_position=$(grep -w "${EXON}" ${BLAST_EXONS_VS_CONTIGS} | head -1 | cut -f2 | cut -f5 -d"|")

# trouver la evalue minimum dans les blast de cet exon
min_evalue=$(grep -w "${EXON}" ${BLAST_EXONS_VS_CONTIGS} | \
sort -g -k3 | head -1 | cut -f3)

# garder le/les blast de evalue minimum et trouver la longueur de blast maximum dans ces blasts
max_long=$(grep -w "${EXON}" ${BLAST_EXONS_VS_CONTIGS} | \
LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' | \
sort -k5 -r | head -1 | cut -f5)

# garder le blast de evalue minimum, de longueur maximum et de pident maximum
grep -w "${EXON}" ${BLAST_EXONS_VS_CONTIGS} | \
LC_ALL=en_US awk -v min=${min_evalue} '{if ($3==min) {print $0}}' | \
LC_ALL=en_US awk -v max=${max_long} '{if ($5==max) {print $0}}' | \
sort -k4 -r | head -1 > best_blast_${EXON}.txt

###on garde le meilleur blast de l'exon en utilisant ces 3 filtres

# recuperer le nom du contig qui est le meilleur blast et les positions de debut et fin du blast sur sa sequence
contig=$(cut -f1 best_blast_${EXON}.txt)
if (( "$(cut -f10 best_blast_${EXON}.txt)" < "$(cut -f11 best_blast_${EXON}.txt)" )) ; then
	seq_start=$(cut -f10 best_blast_${EXON}.txt)
	seq_end=$(cut -f11 best_blast_${EXON}.txt)
	inverse="n" ;
	else 
	seq_start=$(cut -f11 best_blast_${EXON}.txt)
	seq_end=$(cut -f10 best_blast_${EXON}.txt)
	inverse="y"
fi
### et des fois les sequences sont dans le mauvais sens donc ca match mal sur le début et la fin c'est inversé
####donc à cette étape on a choisi le meilleur BLAst du contig et maintenant on veut découper dans le contig la séquence correspondante



# recuperer la sequence decoupee (correspondant au blast) de ce contig
grep -w "${contig}" $ASSEMBLY > ${EXON}_${contig}_full_name.txt
sed -i 's/>//g' ${EXON}_${contig}_full_name.txt
seqkit grep  -n -f ${EXON}_${contig}_full_name.txt $ASSEMBLY -o ${EXON}_${contig}_seq.fasta
seqkit subseq -r ${seq_start}:${seq_end} ${EXON}_${contig}_seq.fasta > ${EXON}_${contig}_blasted_seq.fasta
if [ "$inverse" == "y" ] ; then
	seqkit seq -p -r -t dna ${EXON}_${contig}_blasted_seq.fasta > ${EXON}_${contig}_blasted_seqinvcomp.fasta
	rm ${EXON}_${contig}_blasted_seq.fasta
fi

### seqkit permet de prendre la séquence et de venir couper la portion qui nous intéresse
###seqkit seq permet de remettre les séquences inversés dans le bon sens

# faire le blast reciproque
~/scripts/script_blast.sh ${EXON}_${contig}_blasted_*.fasta ~/Murinae/Reference_exons/Mouse_exons_ref_coding_seq_lgmin100.fasta blast_reciproque_${EXON}_${contig}.txt 1

# trouver le meilleur blast
if [ $(wc -l < blast_reciproque_${EXON}_${contig}.txt) > 0 ] ; then
min_evalue2=$(sort -g -k3 blast_reciproque_${EXON}_${contig}.txt | head -1 | cut -f3)
max_long2=$(LC_ALL=en_US awk -v min=${min_evalue2} '{if ($3==min) {print $0}}' blast_reciproque_${EXON}_${contig}.txt | \
sort -k5 -r | head -1 | cut -f5)
exon_best_blast=$(LC_ALL=en_US awk -v min=${min_evalue2} '{if ($3==min) {print $0}}' blast_reciproque_${EXON}_${contig}.txt | \
LC_ALL=en_US awk -v max=${max_long2} '{if ($5==max) {print $0}}' | \
sort -k4 -r | head -1 | cut -f1 | cut -f2 -d"|")

### on va retrouver

# si l'exon meilleur blast est le meme que l'exon dont le meilleur blast etait ce contig, garder cette sequence

if [ "${EXON}" == "${exon_best_blast}" ] ; then
	grep -v ">" ${EXON}_${contig}_blasted_*.fasta > ${EXON}_${contig}_blasted_seq_seqonly.txt
	echo -e ">${SPECIE}\n$(cat ${EXON}_${contig}_blasted_seq_seqonly.txt)" >> ${gene}_${EXON}_${exon_position}_seq.fasta
	exon_conservation="yes" ;
	else 
	exon_conservation="no"
fi
fi

#/inversé n ca met à la ligne

## suppression optionnelle des fichiers intermédiaires ##

if [ ${suppr} == 1 ] ; then
	rm best_blast_${EXON}.txt
	rm ${EXON}_${contig}_full_name.txt
	rm ${EXON}_${contig}_seq.fasta
	rm ${EXON}_${contig}_blasted_*.fasta
	rm ${EXON}_${contig}_blasted_seq_seqonly.txt
	rm ${EXON}_${contig}_seq.fasta.seqkit.fai
	rm blast_reciproque_${EXON}_${contig}.txt
fi

echo -e "${EXON}\t${gene}\t${exon_position}\t${min_evalue}\t${max_long}\t${contig}\t${seq_start}\t${seq_end}\t${min_evalue2}\t${max_long2}\t${exon_best_blast}\t${exon_conservation}" >> sortie_blast_reciproque_${SPECIE}.csv
