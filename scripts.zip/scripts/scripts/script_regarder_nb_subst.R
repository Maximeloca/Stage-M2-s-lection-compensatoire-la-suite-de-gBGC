###Cétacé#####
setwd("~/Documents/Darwin2/M2/S2/Stage/Stage gBC/donnees_cetace/Cetace.nosync")

library(tidyr)
library(ggplot2)
library(forcats)

tab <- read.csv("count_subst_types_in_branches_all_exons.csv", header = F, sep = "\t")
colnames(tab) <- c("nb_subst_WS", "nb_subst_SW", "nb_subst_SSWW", "branch_number","exon_name")

liste_bcp_subst = read.csv("List_exons_error_aln.csv")

tab_resum <- tab[,c(1,2,3,4,5)]
tab_resum$nb_tot_subst <- tab_resum$nb_subst_WS + tab_resum$nb_subst_SW + tab_resum$nb_subst_SSWW
colnames(tab_resum) <- c("WS", "SW", "SSWW","branche number","exon_name","nb_tot_subst")


liste_bcp_subst = read.csv("List_exons_error_aln.csv")
#liste_bcp_subst

# Filtrer les exons en supprimant ceux présents dans la liste
tab_filtered <- tab_resum[!tab_resum$exon_name %in% liste_bcp_subst$Exon, ]
hist(tab_filtered$nb_tot_subst)

moy =mean(tab_filtered$nb_tot_subst)

tab_filtered_exon <- subset(tab_filtered, exon_name == "NW_004438433.1_13977228-13977504_+0_ID=cds4473_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta")
hist(tab_filtered_exon$nb_tot_subst)


tab_filtered_comp <- subset(tab_filtered, exon_name %in% c(
  "NW_004438521.1_4760910-4761294_-2_ID=cds17156_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta",
  "NW_004438433.1_13977228-13977504_+0_ID=cds4473_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta"
))

hist(tab_filtered_comp$nb_tot_subst)

#top_10_exons <- head(tab_filtered$exon_name[order(-tab_filtered$nb_tot_subst)], 10)
#top_10_exons

##top_10_exons <- head(unique(tab_filtered$exon_name[order(-tab_filtered$nb_tot_subst)]), 10)
#data_10_top_10_exons = as.data.frame(top_10_exons)
#top_10_exons



#hist(tab_resum$nb_tot_subst)
#hist(tab_filtered$nb_tot_subst)

#nrow(tab_resum[tab_resum$nb_tot_subst>15,])


#tab_resum_filtre <- tab_resum[tab_resum$nb_tot_subst >= 4.5, ]
#nrow(tab_resum_filtre)

#exon_names_sorted_unique <- sort(unique(tab_resum_filtre$exon_name))
#liste_exons_sup_5_subst = as.data.frame(exon_names_sorted_unique)




###sans les gaps

tab1 <- read.csv("count_subst_types_in_branches_all_exons_sans_gap.csv", header = F, sep = "\t")
colnames(tab1) <- c("nb_subst_WS", "nb_subst_SW", "nb_subst_SSWW", "branch_number","exon_name")

liste_bcp_subst = read.csv("List_exons_error_aln.csv")

tab_resum1 <- tab1[,c(1,2,3,4,5)]
tab_resum1$nb_tot_subst <- tab_resum1$nb_subst_WS + tab_resum1$nb_subst_SW + tab_resum1$nb_subst_SSWW
colnames(tab_resum1) <- c("WS", "SW", "SSWW","branche number","exon_name","nb_tot_subst")


liste_bcp_subst = read.csv("List_exons_error_aln.csv")
#liste_bcp_subst

# Filtrer les exons en supprimant ceux présents dans la liste
tab_filtered_1 <- tab_resum1[!tab_resum1$exon_name %in% liste_bcp_subst$Exon, ]
max(tab_filtered_1$nb_tot_subst)

hist(tab_filtered_1$nb_tot_subst)

###avec les gaps#####
tab2 <- read.csv("count_subst_types_in_branches_all_exons_avec_gap.csv", header = F, sep = "\t")
colnames(tab2) <- c("nb_subst_WS", "nb_subst_SW", "nb_subst_SSWW", "branch_number","exon_name")

liste_bcp_subst = read.csv("List_exons_error_aln.csv")

tab_resum2 <- tab2[,c(1,2,3,4,5)]
tab_resum2$nb_tot_subst <- tab_resum2$nb_subst_WS + tab_resum2$nb_subst_SW + tab_resum2$nb_subst_SSWW
colnames(tab_resum2) <- c("WS", "SW", "SSWW","branche number","exon_name","nb_tot_subst")


liste_bcp_subst = read.csv("List_exons_error_aln.csv")
liste_bcp_subst

# Filtrer les exons en supprimant ceux présents dans la liste
tab_filtered_2 <- tab_resum2[!tab_resum2$exon_name %in% liste_bcp_subst$Exon, ]

tab_filtered_3 <- subset(tab_filtered_2, exon_name == "NW_004438433.1_13977228-13977504_+0_ID=cds4473_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta")
tab_filtered_4 <- subset(tab_filtered_2, exon_name == "NW_004438586.1_1397997-1398570_+1_ID=cds21155_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta")
tab_filtered_5 <- subset(tab_filtered_2, exon_name == "NW_004438521.1_4760910-4761294_-2_ID=cds17156_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta")

tab_filtered_comp <- subset(tab_filtered_2, exon_name %in% c(
  "NW_004438521.1_4760910-4761294_-2_ID=cds17156_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta",
  "NW_004438433.1_13977228-13977504_+0_ID=cds4473_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta"
))



max(tab_filtered_2$nb_tot_subst)



####filtre à 0.2
setwd("~/Documents/Darwin2/M2/S2/Stage/Stage gBC/donnees_cetace/Cetace.nosync")

library(tidyr)
library(ggplot2)
library(forcats)

tab <- read.csv("count_subst_types_in_branches_all_exons.csv", header = F, sep = "\t")
colnames(tab) <- c("nb_subst_WS", "nb_subst_SW", "nb_subst_SSWW", "branch_number","exon_name")

#liste_bcp_subst = read.csv("List_exons_error_aln.csv")

tab_resum <- tab[,c(1,2,3,4,5)]
tab_resum$nb_tot_subst <- tab_resum$nb_subst_WS + tab_resum$nb_subst_SW + tab_resum$nb_subst_SSWW
colnames(tab_resum) <- c("WS", "SW", "SSWW","branche number","exon_name","nb_tot_subst")


liste_bcp_subst = read.csv("List_exons_error_aln.csv")
#liste_bcp_subst

# Filtrer les exons en supprimant ceux présents dans la liste
#tab_filtered <- tab_resum[!tab_resum$exon_name %in% liste_bcp_subst$Exon, ]
tab_filtered <- tab_resum
hist(tab_filtered$nb_tot_subst)


#tab_filtered_exon <- subset(tab_filtered, exon_name == "NW_004438433.1_13977228-13977504_+0_ID=cds4473_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta")
#hist(tab_filtered_exon$nb_tot_subst)


tab_filtered_comp <- subset(tab_filtered, exon_name %in% c(
  "NW_004438421.1_30678488-30678869_-0_ID=cds2284_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta",
  "NW_004438428.1_17599776-17600265_-0_ID=cds3606_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta",
  "NW_004438583.1_2367453-2367909_+0_ID=cds20821_Align.fa_corrected_wt_gap_unique.fasta_seq_NT_aligned.fasta"
))

hist(tab_filtered_comp$nb_tot_subst)

###sans les gaps

tab1 <- read.csv("count_subst_types_in_branches_all_exons_sans_gap_0.2.csv", header = F, sep = "\t")
colnames(tab1) <- c("nb_subst_WS", "nb_subst_SW", "nb_subst_SSWW", "branch_number","exon_name")

liste_bcp_subst = read.csv("List_exons_error_aln.csv")

tab_resum1 <- tab1[,c(1,2,3,4,5)]
tab_resum1$nb_tot_subst <- tab_resum1$nb_subst_WS + tab_resum1$nb_subst_SW + tab_resum1$nb_subst_SSWW
colnames(tab_resum1) <- c("WS", "SW", "SSWW","branche number","exon_name","nb_tot_subst")


#liste_bcp_subst = read.csv("List_exons_error_aln.csv")
#liste_bcp_subst

# Filtrer les exons en supprimant ceux présents dans la liste
#tab_filtered_1 <- tab_resum1[!tab_resum1$exon_name %in% liste_bcp_subst$Exon, ]
tab_filtered_1 <- tab_resum1
max(tab_filtered_1$nb_tot_subst)

hist(tab_filtered_1$nb_tot_subst)




par(mfrow = c(1, 2))  # Divise la fenêtre graphique en 1 ligne, 2 colonnes

hist(tab_filtered_1$nb_tot_subst,
     main = "Exons",
     xlab = "Nombre de substitutions",
     col = "lightgray")

hist(tab_filtered_comp$nb_tot_subst,
     main = "Exons",
     xlab = "Nombre de substitutions",
     col = "lightblue")










###Rattini#####
setwd("~/Documents/Darwin2/M2/S2/Stage/Stage gBC/Rattini")

library(tidyr)
library(ggplot2)
library(forcats)



tab <- read.csv("count_subst_types_in_branches_all_exons.csv", header = F, sep = "\t")
colnames(tab) <- c("nb_subst_WS", "nb_subst_SW", "nb_subst_SSWW", "branch_number","exon_name")

tab_resum <- tab[,c(1,2,3,4,5)]
tab_resum$nb_tot_subst <- tab_resum$nb_subst_WS + tab_resum$nb_subst_SW + tab_resum$nb_subst_SSWW
colnames(tab_resum) <- c("WS", "SW", "SSWW","branche number","exon_name","nb_tot_subst")


liste_bcp_subst = read.csv("List_exons_error_aln.csv")
liste_bcp_subst

# Filtrer les exons en supprimant ceux présents dans la liste
tab_filtered <- tab_resum[!tab_resum$exon_name %in% liste_bcp_subst$Exon, ]


#top_10_exons <- head(tab_filtered$exon_name[order(-tab_filtered$nb_tot_subst)], 10)
#top_10_exons

top_10_exons <- head(unique(tab_filtered$exon_name[order(-tab_filtered$nb_tot_subst)]), 10)
data_10_top_10_exons. =as.data.frame(top_10_exons)
top_10_exons



hist(tab_resum$nb_tot_subst)
hist(tab_filtered$nb_tot_subst)

nrow(tab_resum[tab_resum$nb_tot_subst>15,])


tab_resum_filtre <- tab_resum[tab_resum$nb_tot_subst >= 4.5, ]
nrow(tab_resum_filtre)

exon_names_sorted_unique <- sort(unique(tab_resum_filtre$exon_name))
liste_exons_sup_5_subst = as.data.frame(exon_names_sorted_unique)