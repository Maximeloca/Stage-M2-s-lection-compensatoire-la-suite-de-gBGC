#! /bin/bash

# parametres ##

EXON=$1
TRIBE=$2

# script ##

gene=$(grep -w ${EXON} ~/Murinae/Blast/reference/Gene_exons_ref_list.txt | cut -f1)
exon_position=$(grep -w ${EXON} ~/Murinae/Blast/reference/Gene_exons_ref_list.txt | cut -f3)
java -jar ~/bin/macse_v2.07.jar -prog alignSequences -seq ~/Murinae/Sequences/${TRIBE}/${gene}_${EXON}_${exon_position}_all_sp_seq.fasta -out_NT ${gene}_${EXON}_${exon_position}_seq_NT_aligned.fasta -out_AA ${gene}_${EXON}_${exon_position}_seq_AA_aligned.fasta
### prog = juste le programme qu'on utilise et qui s'appelle alignSequences 
### seq = la séquence que l'on veut aligner 
### -out_NT = nom de sortie de l'alignement NT
### -out_AA = nom de sortie de l'alignement avec les acides aminés 