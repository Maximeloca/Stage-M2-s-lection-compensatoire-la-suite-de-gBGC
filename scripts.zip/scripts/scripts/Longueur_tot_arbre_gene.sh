
GENE=$1
TRIBE=$2

# arbre exon avec iqtree
iqtree2 -s ~/${TRIBE}/align_genes_seq/${GENE}_seq_align_NT.fasta   -nt 1 -m GTR --prefix ~/${TRIBE}/Phylogeny/Gene_tree/${GENE}_tree >out_iqtree_exon_${GENE}.txt 2>error_iqtree_exon_${GENE}.txt

# calculer longueur tot arbre exon
python3 ~/scripts/lg_tree.py ~/${TRIBE}/Phylogeny/Gene_tree/${GENE}_tree.treefile lg_tree_${GENE}.txt >out_lg_tot_tree_e_${GENE}.txt 2>error_lg_tot_tree_e_${GENE}.txt
lg_tree_e=$(cat lg_tree_${GENE}.txt)

# Affichage de l'exon et du CDS dans un fichier CSV
echo -e "$GENE\t$lg_tree_e" >> lg_tree.csv