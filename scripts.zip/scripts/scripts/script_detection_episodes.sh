#! /bin/bash

# Arguments ###

GENE=$1
TRIBE=$2
TH_LG=$3
TH_SIGNIF=$4

# Script ###

grep $GENE ~/Murinae/${TRIBE}/Substitutions_mapping/gene_exon_lenseq_mapping_ok.txt > ${GENE}_exons_lg_seq.csv

python3 ~/scripts/detection_episode.py ${GENE}_exons_lg_seq.csv ~/Murinae/${TRIBE}/Detecting_gBGC/Detection/signif_stat/ $TH_LG $TH_SIGNIF ${GENE}_episodes_detection.csv

rm ${GENE}_exons_lg_seq.csv
