## figure ##########
###Rattini#####
setwd("~/Documents/Darwin2/M2/S2/Stage/Stage gBC/Rattini.nosync")
library(tidyr)
library(ggplot2)
library(forcats)

tab <- read.csv("count_subst_types_in_branches_all_exons.csv", header = F, sep = "\t")
colnames(tab) <- c("nb_subst_WS", "nb_subst_SW", "nb_subst_SSWW", "branch_number","exon_name")

liste_bcp_subst = read.csv("List_exons_error_aln.csv")
tab = tab[!tab$exon_name %in% liste_bcp_subst$Exon, ]


tab_resum <- tab[,c(1,2,3)]
tab_resum$nb_tot_subst <- tab_resum$nb_subst_WS + tab_resum$nb_subst_SW + tab_resum$nb_subst_SSWW
colnames(tab_resum) <- c("WS", "SW", "SSWW", "nb_tot_subst")



tab_resum$WS_prop <- tab_resum$WS/tab_resum$nb_tot_subst
tab_resum$SW_prop <- tab_resum$SW/tab_resum$nb_tot_subst
tab_resum$SSWW_prop <- tab_resum$SSWW/tab_resum$nb_tot_subst
tab_resum <- tab_resum[4:7]

# cat entre 1 et 1.5 subst tot
tab_resum_nb_1 <- tab_resum[tab_resum$nb_tot_subst > 0.9 & tab_resum$nb_tot_subst <= 1.5,]
prop_moy_WS_nb_1 <- mean(tab_resum_nb_1$WS_prop)
prop_moy_SW_nb_1 <- mean(tab_resum_nb_1$SW_prop)
prop_moy_SSWW_nb_1 <- mean(tab_resum_nb_1$SSWW_prop)

# cat entre 2 et 5 subst tot
tab_resum_nb_2_5 <- tab_resum[tab_resum$nb_tot_subst > 1.5  & tab_resum$nb_tot_subst < 4.5,]
prop_moy_WS_nb_2_5 <- mean(tab_resum_nb_2_5$WS_prop)
prop_moy_SW_nb_2_5 <- mean(tab_resum_nb_2_5$SW_prop)
prop_moy_SSWW_nb_2_5 <- mean(tab_resum_nb_2_5$SSWW_prop)

# cat sup à 5 subst tot
tab_resum_nb_sup_5 <- tab_resum[tab_resum$nb_tot_subst >=4.5,]
prop_moy_WS_nb_sup_5 <- mean(tab_resum_nb_sup_5$WS_prop)
prop_moy_SW_nb_sup_5 <- mean(tab_resum_nb_sup_5$SW_prop)
prop_moy_SSWW_nb_sup_5 <- mean(tab_resum_nb_sup_5$SSWW_prop)

# table for the plot
nb_tot_subst <- c("1", "2-5", ">=5")
prop_moy_SW <- c(prop_moy_SW_nb_1, prop_moy_SW_nb_2_5, prop_moy_SW_nb_sup_5)
prop_moy_WS <- c(prop_moy_WS_nb_1, prop_moy_WS_nb_2_5, prop_moy_WS_nb_sup_5)
prop_moy_SSWW <- c(prop_moy_SSWW_nb_1, prop_moy_SSWW_nb_2_5, prop_moy_SSWW_nb_sup_5)
tab_graphe <- cbind.data.frame(nb_tot_subst, prop_moy_SW, prop_moy_WS, prop_moy_SSWW)
colnames(tab_graphe) <- c("nb_tot_subst", "SW", "WS", "SSWW")
tab_graphe <- tab_graphe %>% pivot_longer(!nb_tot_subst, names_to = "subst_type", values_to = "prop_moy")
levels(tab_graphe$nb_tot_subst)
tab_graphe$nb_tot_subst <- fct_relevel(tab_graphe$nb_tot_subst, c("1", "2-5", ">=5")) # mettre dans le bon ordre les catégories

# plot
p = ggplot(data=tab_graphe, aes(x=nb_tot_subst, y=prop_moy)) +
  geom_col(aes(fill=subst_type), color="black", linewidth=0.2) +
  scale_colour_manual(values = c("#00BA38", "#619CFF", "#F8766D")) +
  scale_fill_manual(values = c("#00BA38", "#619CFF", "#F8766D")) +
  theme_classic() +
  xlab("Number of substitutions in a branch") +
  ylab("Mean proportion of each type of substitution")
p
ggsave("Rattini_substitution_plot_2.png", plot = p, width = 8, height = 6, dpi = 300)


###Cétacé#####
setwd("~/Documents/Darwin2/M2/S2/Stage/Stage gBC/donnees_cetace/Cetace.nosync")

library(tidyr)
library(ggplot2)
library(forcats)

tab <- read.csv("count_subst_types_in_branches_all_exons.csv", header = F, sep = "\t")
colnames(tab) <- c("nb_subst_WS", "nb_subst_SW", "nb_subst_SSWW", "branch_number","exon_name")

liste_bcp_subst = read.csv("List_exons_error_aln.csv")
tab = tab[!tab$exon_name %in% liste_bcp_subst$Exon, ]

tab_resum <- tab[,c(1,2,3)]
tab_resum$nb_tot_subst <- tab_resum$nb_subst_WS + tab_resum$nb_subst_SW + tab_resum$nb_subst_SSWW
colnames(tab_resum) <- c("WS", "SW", "SSWW", "nb_tot_subst")

tab_resum$WS_prop <- tab_resum$WS/tab_resum$nb_tot_subst
tab_resum$SW_prop <- tab_resum$SW/tab_resum$nb_tot_subst
tab_resum$SSWW_prop <- tab_resum$SSWW/tab_resum$nb_tot_subst
tab_resum <- tab_resum[4:7]
###tab_resum contient les proportions de chaque type de substitution (nb_subs_WS/Nb_tot_subst) pour chaque exon 


# cat entre 1 et 1.5 subst tot
tab_resum_nb_1 <- tab_resum[tab_resum$nb_tot_subst > 0.9 & tab_resum$nb_tot_subst <= 1.5,]
prop_moy_WS_nb_1 <- mean(tab_resum_nb_1$WS_prop)
prop_moy_SW_nb_1 <- mean(tab_resum_nb_1$SW_prop)
prop_moy_SSWW_nb_1 <- mean(tab_resum_nb_1$SSWW_prop)

###fais les proportions pour chaque type qd on a entre 0,9 et 1,5 subst au total

# cat entre 2 et 5 subst tot
tab_resum_nb_2_5 <- tab_resum[tab_resum$nb_tot_subst > 1.5  & tab_resum$nb_tot_subst < 4.5,]
prop_moy_WS_nb_2_5 <- mean(tab_resum_nb_2_5$WS_prop)
prop_moy_SW_nb_2_5 <- mean(tab_resum_nb_2_5$SW_prop)
prop_moy_SSWW_nb_2_5 <- mean(tab_resum_nb_2_5$SSWW_prop)

# cat sup à 5 subst tot
tab_resum_nb_sup_5 <- tab_resum[tab_resum$nb_tot_subst >=4.5,]
prop_moy_WS_nb_sup_5 <- mean(tab_resum_nb_sup_5$WS_prop)
prop_moy_SW_nb_sup_5 <- mean(tab_resum_nb_sup_5$SW_prop)
prop_moy_SSWW_nb_sup_5 <- mean(tab_resum_nb_sup_5$SSWW_prop)

# table for the plot
nb_tot_subst <- c("1", "2-5", ">=5")
prop_moy_SW <- c(prop_moy_SW_nb_1, prop_moy_SW_nb_2_5, prop_moy_SW_nb_sup_5)
prop_moy_WS <- c(prop_moy_WS_nb_1, prop_moy_WS_nb_2_5, prop_moy_WS_nb_sup_5)
prop_moy_SSWW <- c(prop_moy_SSWW_nb_1, prop_moy_SSWW_nb_2_5, prop_moy_SSWW_nb_sup_5)
tab_graphe <- cbind.data.frame(nb_tot_subst, prop_moy_SW, prop_moy_WS, prop_moy_SSWW)
colnames(tab_graphe) <- c("nb_tot_subst", "SW", "WS", "SSWW")
tab_graphe <- tab_graphe %>% pivot_longer(!nb_tot_subst, names_to = "subst_type", values_to = "prop_moy")
levels(tab_graphe$nb_tot_subst)
tab_graphe$nb_tot_subst <- fct_relevel(tab_graphe$nb_tot_subst, c("1", "2-5", ">=5")) # mettre dans le bon ordre les catégories

# plot
p = ggplot(data=tab_graphe, aes(x=nb_tot_subst, y=prop_moy)) +
  geom_col(aes(fill=subst_type), color="black", linewidth=0.2) +
  scale_colour_manual(values = c("#00BA38", "#619CFF", "#F8766D")) +
  scale_fill_manual(values = c("#00BA38", "#619CFF", "#F8766D")) +
  theme_classic() +
  xlab("Number of substitutions in a branch") +
  ylab("Mean proportion of each type of substitution")

p

ggsave("Cetace_substitution_plot_2.png", plot = p, width = 8, height = 6, dpi = 300)



