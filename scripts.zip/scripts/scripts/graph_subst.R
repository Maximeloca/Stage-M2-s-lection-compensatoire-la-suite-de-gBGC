#!/usr/bin/env Rscript

## Arguments ##################################################################################
args = commandArgs(trailingOnly=TRUE)
print(args)

if (length(args)<3) {
  stop("3 arguments must be supplied : [1] exon name [2] path of the directory of the mapping substitutions tables [3] name of the csv out", call.=FALSE)
}

exon_name = args[1]
dir_path = args[2]
csv_out = args[3]

# test ####
#exon_name = "ENSMUSE00001335942"
#dir_path = "./"
###########

## script ####################################################################################

# load tables
tab_WS <- read.table(paste0(dir_path, exon_name, "_counts_dS_X_WS.csv"), sep="\t", header=T, check.names = F)
tab_WS <- tab_WS[,2:ncol(tab_WS)]
###on vire la colonne des codons
tab_SW <- read.table(paste0(dir_path, exon_name, "_counts_dS_X_SW.csv"), sep="\t", header=T, check.names = F)
tab_SW <- tab_SW[,2:ncol(tab_SW)]
tab_WW <- read.table(paste0(dir_path, exon_name, "_counts_dS_X_WW.csv"), sep="\t", header=T, check.names = F)
tab_WW <- tab_WW[,2:ncol(tab_WW)]
tab_SS <- read.table(paste0(dir_path, exon_name, "_counts_dS_X_SS.csv"), sep="\t", header=T, check.names = F)
tab_SS <- tab_SS[,2:ncol(tab_SS)]

# total number of WS substitutions in a branch
nb_subst_WS <- colSums(tab_WS)
nb_subst_SW <- colSums(tab_SW)
nb_subst_WW <- colSums(tab_WW)
nb_subst_SS <- colSums(tab_SS)

# build the table
branches <- colnames(tab_WS) # numéro des branches 
tab_final <- as.data.frame(cbind(branches, nb_subst_WS, nb_subst_SW, nb_subst_WW, nb_subst_SS))
tab_final$branches <- as.numeric(as.character(tab_final$branches))
tab_final$nb_subst_WS <- as.numeric(as.character(tab_final$nb_subst_WS))
tab_final$nb_subst_SW <- as.numeric(as.character(tab_final$nb_subst_SW))
tab_final$nb_subst_WW <- as.numeric(as.character(tab_final$nb_subst_WW))
tab_final$nb_subst_SS<- as.numeric(as.character(tab_final$nb_subst_SS))

nb_subst_SS_WW = nb_subst_WW + nb_subst_SS
nb_subst_tot = nb_subst_WS + nb_subst_SW + nb_subst_WW + nb_subst_SS

library(ggplot2)
library(dplyr)

tab_nul$branches <- as.numeric(as.character(tab_nul$branches))
tab_nul$nb_subst_WS <- as.numeric(as.character(tab_nul$nb_subst_WS))
tab_nul$nb_subst_SW <- as.numeric(as.character(tab_nul$nb_subst_SW))
tab_nul$nb_subst_WW <- as.numeric(as.character(tab_nul$nb_subst_WW))
tab_nul$nb_subst_SS<- as.numeric(as.character(tab_nul$nb_subst_SS))
# Ajouter une colonne du total des substitutions
tab_nul$nb_subst_tot <- tab_nul$nb_subst_WS + tab_nul$nb_subst_SW + tab_nul$nb_subst_WW + tab_nul$nb_subst_SS

# Catégoriser le nombre de substitutions par branche
tab_nul$category <- cut(
  tab_nul$nb_subst_tot,
  breaks = c(-Inf, 1, 5, Inf),
  labels = c("1", "2-5", ">=5"),
  right = TRUE
)

# Transformer le tableau pour qu'il soit au format long (tidy)
tab_long <- tab_nul %>%
  select(category, nb_subst_WS, nb_subst_SW, nb_subst_WW, nb_subst_SS) %>%
  pivot_longer(cols = -category, names_to = "subst_type", values_to = "count")

# Calculer les proportions par catégorie
tab_long <- tab_long %>%
  group_by(category, subst_type) %>%
  summarise(proportion = sum(count) / sum(count[subst_type %in% c("nb_subst_WS", "nb_subst_SW", "nb_subst_WW", "nb_subst_SS")]), .groups = "drop")

p = ggplot(tab_long, aes(x = category, y = proportion, fill = subst_type)) +
  geom_bar(stat = "identity", position = "fill") +
  scale_y_continuous(expand = c(0, 0)) +
  labs(
    x = "Number of substitutions in a branch",
    y = "Mean proportion of each type of substitution",
    fill = "subst_type"
  ) +
  theme_minimal()

# save the table
ggsave("distribution_subst.png", plot = p, width = 8, height = 6, dpi = 500)

