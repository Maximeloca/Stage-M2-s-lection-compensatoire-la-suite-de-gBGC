#! /bin/bash 

# parametres ##

SPECIE=$1
DATA_DIRECTORY=$2

# script ##

Trinity --seqType fq --left ${DATA_DIRECTORY}/${SPECIE}_all_R1.clean.fastq.gz --right ${DATA_DIRECTORY}/${SPECIE}_all_R2.clean.fastq.gz --max_memory 50G --CPU 4 --output trinity_OUT_${SPECIE}
nb_contigs=$(grep -c -w ">" trinity_OUT_${SPECIE}/Trinity.fasta)
echo -e "nombre contigs ${SPECIE} : ${nb_contigs}"
