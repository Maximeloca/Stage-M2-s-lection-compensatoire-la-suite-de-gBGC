#! /bin/bash

# parametres ##

SPECIE=$1
TRIBE=$2

# script ##

###en gros ce script va rechercher dans chaque exon si l'espèce qu'on recherche est présente, si c'est le cas il va récupérer sa séquence 
### et la placer dans un nouveau fichier ou il y aura au dessus le nom de l'exon, si l'espèce n'est pas présent dans l'exon 
### on va afficher une ligne de N égal au nombre des séquences de l'exon et place dans le fichier de sortie la ligne de N 
### avec le nom de l'exon au dessus, exemple :

### dans le dossier : SP__all_seq_NT_aligned_final.fasta ou l'espèce n'a pas l'exon 2 
#EXON 1 
#sequence... 
#EXON 2 (de 108 bases)
# NNN...N --> 108 N 



for EXON in $(cat ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/alignments_wt_ref_filtered/alignments_wt_ref_filtered_wt_stop/Exons_filtered_final_list.txt); do

	gene=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1) # récupère le nom du gène 
	exon_position=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3) #récupère la position
	sp_present=$(grep -c "${SPECIE}" ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/alignments_wt_ref_filtered/alignments_wt_ref_filtered_wt_stop/${gene}_${EXON}_${exon_position}_final_align_NT_wt_ref_filtered_wt_stop.fasta)
	###regarde combien de fois dans l'exon on retrouve l'espèce

	echo ">${EXON}"	
	
	if [ ${sp_present} == 0 ] ; then
		length=$(seqkit fx2tab ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/alignments_wt_ref_filtered/alignments_wt_ref_filtered_wt_stop/${gene}_${EXON}_${exon_position}_final_align_NT_wt_ref_filtered_wt_stop.fasta -l -n | head -1 | cut -f2)
		#récupère la longueur de la séquence de l'exon
		# fx2tab --> permet de convertir le fichier fasta en un tableau
		# -l permet de donner la longueur de la séquence 
		# -n affiche le nom de chaque séquence 
		 #le tableau va ressembler à un truc comme ca : donc espèce en colonne 1 et longueur en colonne 2
		 #Berylmys_bowersi			108
		 #Waiomys_mamasae			108
		 #Tateomys_rhinogradoides	108
		 #Taeromys_punicans			108
		 #Sommeromys_macrorhinos	108
		 ###par conséquent vu qu'on veut juste la longueur on fait head -1 | cut -f2 --> comme ca on récupère juste 108
		printf 'N%.0s' $(seq 1 $length) 
		# premet de générer une série de N de la même longueur que les autres séquences, dans notre exemple 108 donc on aura 108 N à la suite
		
		echo "" ;
		else
		echo "${SPECIE}" > ${SPECIE}_name.txt
		seqkit grep  -n -f ${SPECIE}_name.txt ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/alignments_wt_ref_filtered/alignments_wt_ref_filtered_wt_stop/${gene}_${EXON}_${exon_position}_final_align_NT_wt_ref_filtered_wt_stop.fasta -o ${SPECIE}_${gene}_${EXON}_${exon_position}_seq_NT_aligned_final.fasta
		##va prendre la séquence de l'espèce concernée et va l'enregistrer dans un fichier de sortie ou il y aura le nom de la séquence
		##dnc le nom de l'espèce et la séquence qui suit 
		##sekqit -n --> permet de prendre le nom entier donc le nom de l'espèce en entier 
		grep -v ">" ${SPECIE}_${gene}_${EXON}_${exon_position}_seq_NT_aligned_final.fasta
		# va afficher uniquement la séquence sans le nom de l'espèce 
		rm ${SPECIE}_${gene}_${EXON}_${exon_position}_seq_NT_aligned_final.fasta
		rm ${SPECIE}_name.txt
	fi
done >> ${SPECIE}_all_seq_NT_aligned_final.fasta
### dans le dossier : SP__all_seq_NT_aligned_final.fasta ou l'espèce n'a pas l'exon 2 
#EXON 1 
#sequence... 
#EXON 2 (de 108 bases)
# NNN...N --> 108 N 