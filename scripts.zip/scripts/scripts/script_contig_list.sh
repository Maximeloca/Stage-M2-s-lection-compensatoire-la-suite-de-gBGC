#! /bin/bash

# donne la correspondance entre exon ref et contig meilleur blast pour une espece donnee

# parametres ##

SPECIE=$1
TRIBE=$2

# script ##
####

for exon in $(cat ~/Murinae/${TRIBE}/Sequences/Exons_list.txt) ; do
	contig=$(LC_ALL=en_US awk '{if ($12=="yes") {print $0}}' ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${SPECIE}/sortie_blast_reciproque_${SPECIE}.csv |\ ###on garde que les lignes ou c'est yes car ca correspond à ce qu'on a gardé
	grep "${exon}"  | cut -f6) ###F6 colonne qui contient le nom du contig
	echo -e "${exon}\t${contig}"
done >> contigs_list_${SPECIE}.txt

###on récupère l'identifiant du contig pour lequel l'exon correspond et on crée un tableau avec exon et contig associé 
