## install packages ###

###ce script se fait pour un gène car on a bouclé sur la liste de gènes 
from Bio import SeqIO
import sys
import pandas as pd

## arguments ###

    # message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]gene name [2]tab of genes, exons, position [3]directory of the sequences")
    # recuperer les arguments
gene_name = sys.argv[1]
genes_exons_pos_tab_name = sys.argv[2]
seq_dir = sys.argv[3]

# read tab of gene and exons
tab_genes_exons_pos = pd.read_csv(genes_exons_pos_tab_name, sep="\t", header=None) # on lit le tableau des gènes avec les exons positions et tout.. 
tab_genes_exons_pos.columns = ['Gene', 'Exon', 'Position'] # renomme les colonnes 

# list of exons for the gene
exons_list = list(tab_genes_exons_pos[tab_genes_exons_pos['Gene'] == gene_name]['Exon'])
### tab_genes_exons_pos[tab_genes_exons_pos['Gene'] == gene_name] --> permet de récupérer les lignes qui correspondent à notre gène 
### ['Exon'] --> on ne garde que la colonne exon 
# donc à la fin on a la liste des exons qui appartiennent au gène qu'on fait 

# list of species for each exon
dico_exon_sp = {}
for exon in exons_list:
    dico_exon_sp[exon] = []
    pos = tab_genes_exons_pos[tab_genes_exons_pos['Exon'] == exon]['Position'].iloc[0] # .iloc car on récupère que une case 
    exon_align_name = f'{seq_dir}{gene_name}_{exon}_{pos}_final_align_NT_wt_ref_filtered_wt_stop.fasta' #on récupère l'aligne
    #f' permet utiliser variable et texte 
    for seq_read in SeqIO.parse(exon_align_name, 'fasta'):
        sp = seq_read.id #récupère id de la séquence = nom de l'espèce
        dico_exon_sp[exon].append(sp) # on ajoute le nom de l'espèce au dico

# find the common species between the exons
for i in range(1, len(exons_list)+1):
    exon = exons_list[i-1] # car dans python dans une liste on commence à 0 donc on fait i-1 pour récupérer l'exon que l'on veut 
    if i == 1:
        sp_list = dico_exon_sp[exon] #liste espèce premier exon
    else:
        sp_list_exon = dico_exon_sp[exon]
        sp_list = list(set(sp_list) & set(sp_list_exon)) #ne garde que ce qui est en commun entre sp_liste donc la liste d'sp du premier exon et le second exon et du coup au fur et à mesure la liste se réduit car on écrase à chaque fois sp_list

# get the sequences with these common species
for exon in exons_list:
    pos = tab_genes_exons_pos[tab_genes_exons_pos['Exon'] == exon]['Position'].iloc[0]
    seq_out_name = f'{gene_name}_{exon}_{pos}_FINAL_align_NT.fasta'
    exon_align_name = f'{seq_dir}{gene_name}_{exon}_{pos}_final_align_NT_wt_ref_filtered_wt_stop.fasta'
    with open(seq_out_name, 'w') as out: # 'w' car on va écrire dedans 
        for seq_read in SeqIO.parse(exon_align_name, 'fasta'):
            seq_id = seq_read.id
            if seq_id in sp_list:
                out.write(f'>{seq_id}\n')
                seq_seq = seq_read.seq
                out.write(f'{seq_seq}\n')
                ### cette boucle va recrée un fichier fasta contenant les séquences avec uniquement les espèces communes entre les exons d'un gène 
