#! /bin/bash

# parametres ##

EXON=$1
TRIBE=$2

# script ##

gene=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)
exon_position=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

mv ~/Murinae/${TRIBE}/Aligned_Sequences/${gene}_${EXON}_${exon_position}_all_sp_seq_align/${gene}_${EXON}_${exon_position}_final_align_NT.aln ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/
