## Install packages ###
import sys
from Bio import SeqIO
import os


## Arguments ###
    # error message if the number of arguments is wrong
if len(sys.argv) != 4:
    sys.exit("ERROR : need 3 arguments : [1]alignment file [2]list of exons ref names [3]out fasta file name")
    # get the arguments
align_name = sys.argv[1]
list_outgroup = sys.argv[2]
out_folder = sys.argv[3]  # Dossier de sortie


file_name = os.path.basename(align_name)  # Récupère uniquement le nom du fichier (sans le chemin)
out_file_name = os.path.join(out_folder, file_name)  # Construit le chemin du fichier de sortie

## Script ###

with open(list_outgroup, "r") as file_ex_name:
    file_ex_name_read = file_ex_name.read().strip()
    ex_name_list = file_ex_name_read.split()
####permet de créer une liste des outgroup à retirer

with open(out_file_name, "w") as out:
    for seq_read in SeqIO.parse(align_name, 'fasta'):
        seq_id = seq_read.id
        if seq_id not in ex_name_list:
            out.write(f'>{seq_id}\n')
            seq_seq = seq_read.seq
            out.write(f'{seq_seq}\n')
###créer une boucle ou les outgroups ne sont pas dans le fichier de sortie 
