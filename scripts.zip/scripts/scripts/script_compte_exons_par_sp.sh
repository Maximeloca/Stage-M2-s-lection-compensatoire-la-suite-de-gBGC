#! /bin/bash

# parametres ##
SPECIE=$1

count=0
# Boucle sur les fichiers .fasta pour compter les occurrences de l'espèce
for file in *.fasta; do
    count=$((count + $(grep -c "${SPECIE}" "$file")))
done

# Si le fichier n'existe pas, ajoute l'en-tête
if [ ! -f Nb_Exon_par_sp.csv ]; then
    echo -e "Espèce\tNombre d'occurrences" > Nb_Exon_par_sp.csv
fi

# Ajout du résultat au fichier CSV
echo -e "${SPECIE}\t$count" >> Nb_Exon_par_sp.csv
