from ete3 import Tree
## ete3 pour manipulation des phylogénies 
import sys

tree_name = sys.argv[1]
out_file_name = sys.argv[2]

# read the tree
t = Tree(tree_name, format=1)

lg_list = []
# for each node of the tree :
### fais la longueur de chaque noeuds enfin les branches descendantes 
for node in t.iter_descendants("postorder"):
    lg = node.dist
    lg_list.append(lg)
#print(lg_list)
sum_lg = sum(lg_list)

with open(out_file_name, 'w') as out:
    out.write(f'{sum_lg}')