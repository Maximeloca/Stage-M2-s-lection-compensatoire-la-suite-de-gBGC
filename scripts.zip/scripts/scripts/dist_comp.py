## install packages ###
import sys
import pandas as pd
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 5:
    sys.exit("ERROR : need 4 arguments : [1]gene name [2]directory of the tab recap [3]list of paralogs exons [4]directory of the substitution mapping tables")
# recuperer les arguments
gene_name = sys.argv[1]
tab_recap_dir = sys.argv[2]
paralogs_list_file = sys.argv[3]
tab_subst_map_dir = sys.argv[4]

## script ###

# get the paralogs list
####crée la liste des paralogues 
with open(paralogs_list_file, "r") as file_paralogs_list:
    file_paralogs_list_read = file_paralogs_list.read().strip()
    paralogs_list = file_paralogs_list_read.split()

gene = gene_name
print(gene)
# read the table
tab_recap_name = tab_recap_dir + gene + "_tab_recap.csv"
tab_recap_with_paralogs = pd.read_csv(tab_recap_name, sep='\t')
#récupère le tableau récap du gène n
    
# remove paralogs exons
tab_recap = tab_recap_with_paralogs[~tab_recap_with_paralogs.Exon.isin(paralogs_list)]
##exclue les exons dans la liste des paralogues 

# list of exons
exons_list = list(tab_recap['Exon'])
exons_list = set(exons_list) # equivalent of uniq
exons_list = list(exons_list) # equivalent of uniq
###crée du coup la liste des exons présent dans le gène

# create lists to fill
exon_tab_list = []
lg_exon_list = []
ep_uniq_exon = []
br_ep_list = []
br_post_ep_list = []
nb_NS_WS_br_ep = []
nb_NS_WS_br_post_ep = []
nb_NS_SW_br_post_ep = []
nb_NS_SS_br_post_ep = []
nb_NS_WW_br_post_ep = []
nb_NS_tot_post_ep = []
pos_NS_br_ep = []
pos_NS_br_post_ep = []



##
for exon in exons_list: ###pour chaque exon étant dans le gène 
    ###POUR CHAQUE EXON PRÉSENT DANS LE GÈNE
    # list other exons of the same gene
    other_exons_list = list(exons_list) ###on crée d'abord une liste avec tous les exons 
    other_exons_list.remove(exon) ###et on retire l'exon qu'on est en train de traiter de la liste "autres exons"
    # tab of exon & br with episodes
    tab_exon = tab_recap[tab_recap['Exon'] == exon] ###la du coup on crée le tableau récap de l'exon 
    tab_exon_ep = tab_exon[(tab_exon['Episode'] == 'YES') & (pd.notna(tab_exon['Br_Asc']))]  ###la on crée le tableau de l'exon s'il possède un épisode et qu'il a une branche ascendante
    # get length of exon seq
    lg_seq = tab_exon[tab_exon['Br'] == 0]['Lg_seq'].iloc[0] ##récupère la longueur de l'exon
    ##### NS after the episodes with at least 1 subst NS WS #####
    # list of the branches after the episodes NS & no episode in these branches
    tab_exon_epNS = tab_exon_ep[tab_exon_ep['Nb_subst_NS_WS'] > 0.9] ##tableau des épisodes contenant au moins une subst NS
    br_epNS = list(tab_exon_epNS['Br']) ###crée la liste des branches possédant au moins un épisode et une subst NS 
    for br in br_epNS: ###pour chaque branche on récupère la branche descendante
        ###POUR CHAQUE BRANCHE PRÉSENTANT UN ÉPISODE, AU MOINS UNE SUBST NS WS ET AYANT UNE BRANCHE ASCENDANTE 
        br_desc1 = (tab_exon[tab_exon['Br'] == br]['Br_Desc1'].iloc[0]) 
        br_desc2 = (tab_exon[tab_exon['Br'] == br]['Br_Desc2'].iloc[0])
        # counter of nb ep in same br of other ex initiates at zero 
        nb_ep_other_ex = 0 ###crée un compteur 
        if pd.notna(br_desc1): ###si la branche descendante n'est pas une NA on crée une liste de ces deux branches
            br_desc1 = int(br_desc1)
            br_desc2 = int(br_desc2)
            br_desc_list = [br_desc1, br_desc2]
            # search if ep in same br in other ex
            for other_exon in other_exons_list: ###on recherche dans les autres exons s'il possède un épisode sur la même branche et si c'est le cas on rajoute +1 au compteur 
                tab_other_exon = tab_recap[tab_recap['Exon'] == other_exon]
                pval = tab_other_exon[tab_other_exon['Br'] == br]['signif_nb_subst_S_WS'].iloc[0]
                if pval > 200:
                    nb_ep_other_ex += 1
            ### get all informations for branches ep & descent branches
            for br_desc in br_desc_list: ###pour chaque branche descendante de la liste donc nos deux branches descendantes 
                ###POUR CHAQUE BRANCHE DESCENDANTE D'UNE BRANCHE AVEC UN ÉPISODE ET UNE SUBST NS WS ET AYANT UNE BRANCHE ASCENDANTE, ON VA RÉCUPÉRER CHAQUE TYPE DE SUBST NS
                if tab_exon[tab_exon['Br'] == br_desc]['Episode'].iloc[0] == 'SURENO': ####si la branche descendante présente SURENO
                    exon_tab_list.append(exon) #on ajoute l'exon à la liste 
                    lg_exon_list.append(lg_seq) #longueur exon
                    br_ep_list.append(br)#branches avec des épisodes 
                    br_post_ep_list.append(br_desc) ###ajoute la branche post ep
                    if nb_ep_other_ex > 0: ###si on a un épisode dans la même branche sur un autre exon 
                        ep_uniq_exon.append('NO') ###on ajoute no a la colonne est ce que on a un unique épisode
                    else:
                        ep_uniq_exon.append('YES') ### si non on ajoute YES 
                    nb_NS_ep = tab_exon[tab_exon['Br'] == br]['Nb_subst_NS_WS'].iloc[0]  ###récupère le nb de substitution NS WS pour la branche avec l'épisode
                    if 0.9 < nb_NS_ep < 1.2:
                        nb_NS_ep = 1 ##on arrondi à 1 si c'est compris entre 0,9 et 1,2
                    nb_NS_WS_br_ep.append(nb_NS_ep) ##ajoute le nb de subst à la liste
                    nb_NS_WS_postep = tab_exon[tab_exon['Br'] == br_desc]['Nb_subst_NS_WS'].iloc[0] ###récupère le nb de subst NS WS pour la branche descendante 
                    if 0.9 < nb_NS_WS_postep < 1.2:
                        nb_NS_WS_postep = 1
                    nb_NS_WS_br_post_ep.append(nb_NS_WS_postep)
                    nb_NS_SW_postep = tab_exon[tab_exon['Br'] == br_desc]['Nb_subst_NS_SW'].iloc[0] #fais pareil pour les NS SW
                    if 0.9 < nb_NS_SW_postep < 1.2:
                        nb_NS_SW_postep = 1
                    nb_NS_SW_br_post_ep.append(nb_NS_SW_postep)
                    nb_NS_SS_postep = tab_exon[tab_exon['Br'] == br_desc]['Nb_subst_NS_SS'].iloc[0]#idem ,pour les NS SS
                    if 0.9 < nb_NS_SS_postep < 1.2:
                        nb_NS_SS_postep = 1
                    nb_NS_SS_br_post_ep.append(nb_NS_SS_postep)
                    nb_NS_WW_postep = tab_exon[tab_exon['Br'] == br_desc]['Nb_subst_NS_WW'].iloc[0]##idem NS WW
                    if 0.9 < nb_NS_WW_postep < 1.2:
                        nb_NS_WW_postep = 1
                    nb_NS_WW_br_post_ep.append(nb_NS_WW_postep)
                    nb_NS_postep = nb_NS_WS_postep + nb_NS_SW_postep + nb_NS_SS_postep + nb_NS_WW_postep ###somme tous les types de subst NS donc regarde si on a au mois une subst NS
                    if 0.9 < nb_NS_postep < 1.2:
                        nb_NS_postep = 1
                    nb_NS_tot_post_ep.append(nb_NS_postep)
                    if nb_NS_ep == 1 and nb_NS_postep == 1: ###si on a au mois une subst NS dans la branche ep et dans la branche post ep
                        ###VA VENIR RÉCUPÉRER LA POSITION DE CHAQUE TYPE DE SUBSTITUTIONS POUR LA BRANCHE EP ET DESCENDANTE
                        if nb_NS_WS_postep == 1: # si on a au moins une subst NS WS
                            tab_map_subst_name = tab_subst_map_dir + exon + "_counts_dN_X_WS.csv" #tableau du mapping des substitutions pour les NS WS
                            tab_map_subst = pd.read_csv(tab_map_subst_name, sep='\t')
                            pos_comp = tab_map_subst[tab_map_subst[str(br_desc)] > 0.8]['sites'].iloc[0] ##regarde les substitutions > 0,8 dans la branche descendante et récupère les sites
                            pos_delet = tab_map_subst[tab_map_subst[str(br)] > 0.8]['sites'].iloc[0] ###comme ligne du dessus mais pour la branche avec l'épisode
                            pos_NS_br_ep.append(pos_delet) 
                            pos_NS_br_post_ep.append(pos_comp)
                        elif nb_NS_SW_postep == 1: ###si on a une subst SW dans la branche post ep et on fait pareil qu'au dessus
                            tab_map_subst_name = tab_subst_map_dir + exon + "_counts_dN_X_SW.csv"
                            tab_map_subst = pd.read_csv(tab_map_subst_name, sep='\t')
                            pos_comp = tab_map_subst[tab_map_subst[str(br_desc)] > 0.8]['sites'].iloc[0]
                            tab_map_subst_delet_name = tab_subst_map_dir + exon + "_counts_dN_X_WS.csv"
                            tab_map_subst_delet = pd.read_csv(tab_map_subst_delet_name, sep='\t')
                            pos_delet = tab_map_subst_delet[tab_map_subst_delet[str(br)] > 0.8]['sites'].iloc[0]
                            pos_NS_br_ep.append(pos_delet)
                            pos_NS_br_post_ep.append(pos_comp)
                        elif nb_NS_SS_postep == 1:
                            tab_map_subst_name = tab_subst_map_dir + exon + "_counts_dN_X_SS.csv"
                            tab_map_subst = pd.read_csv(tab_map_subst_name, sep='\t')
                            pos_comp = tab_map_subst[tab_map_subst[str(br_desc)] > 0.8]['sites'].iloc[0]
                            tab_map_subst_delet_name = tab_subst_map_dir + exon + "_counts_dN_X_WS.csv"
                            tab_map_subst_delet = pd.read_csv(tab_map_subst_delet_name, sep='\t')
                            pos_delet = tab_map_subst_delet[tab_map_subst_delet[str(br)] > 0.8]['sites'].iloc[0]
                            pos_NS_br_ep.append(pos_delet)
                            pos_NS_br_post_ep.append(pos_comp)
                        elif nb_NS_WW_postep == 1:
                            tab_map_subst_name = tab_subst_map_dir + exon + "_counts_dN_X_WW.csv"
                            tab_map_subst = pd.read_csv(tab_map_subst_name, sep='\t')
                            pos_comp = tab_map_subst[tab_map_subst[str(br_desc)] > 0.8]['sites'].iloc[0]
                            tab_map_subst_delet_name = tab_subst_map_dir + exon + "_counts_dN_X_WS.csv"
                            tab_map_subst_delet = pd.read_csv(tab_map_subst_delet_name, sep='\t')
                            pos_delet = tab_map_subst_delet[tab_map_subst_delet[str(br)] > 0.8]['sites'].iloc[0]
                            pos_NS_br_ep.append(pos_delet)
                            pos_NS_br_post_ep.append(pos_comp)
                    else: #si on a pas au moins une subst NS  dans la branche ep et post ep
                        pos_NS_br_ep.append('NA')
                        pos_NS_br_post_ep.append('NA')
                    
   
           
## tab for the gene
if exon_tab_list:
    tab_gene = pd.DataFrame({'Exon': exon_tab_list,
                             'Lg_seq': lg_exon_list,
                             'Ep_uniq_exon': ep_uniq_exon,
                             'Br_ep': br_ep_list,
                             'Br_postep': br_post_ep_list,
                             'Nb_NS_WS_ep': nb_NS_WS_br_ep,
                             'Nb_NS_WS_postep': nb_NS_WS_br_post_ep,
                             'Nb_NS_SW_postep': nb_NS_SW_br_post_ep,
                             'Nb_NS_SS_postep': nb_NS_SS_br_post_ep,
                             'Nb_NS_WW_postep': nb_NS_WW_br_post_ep,
                             'Nb_NS_tot_postep': nb_NS_tot_post_ep, #nb total de NS ost épisode
                             'pos_NS_delet': pos_NS_br_ep, ###position des subst délétères
                             'pos_NS_comp': pos_NS_br_post_ep}) ###position de la sélection compensatoire

    # save this tab
    tab_gene.to_csv(gene + '_tab_dist_comp.csv', index=False)



