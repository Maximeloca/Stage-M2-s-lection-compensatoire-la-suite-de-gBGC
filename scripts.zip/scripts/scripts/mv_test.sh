#! /bin/bash

# parametres ##
EXON=$1

cp ~/Cetacea/Delphinidae/Sequences/test/wt_gap/unique/wt_ref/fou/align_no_postfilter/${EXON} ~/Cetacea/Delphinidae/Sequences/test/wt_gap/unique/wt_ref/fou/align_no_postfilter/align/${EXON}
