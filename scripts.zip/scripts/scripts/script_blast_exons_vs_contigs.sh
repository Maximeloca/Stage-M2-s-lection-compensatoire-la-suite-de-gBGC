#! /bin/bash

# paramètres #
QUERY=$1
TRIBE=$2
SPECIE=$3
LONGMIN=$4
PIDENTMIN=$5
PERCENTMIN=$6
THREADS=$7

# reference
REF=~/Murinae/${TRIBE}/Assembly/trinity_OUT_${SPECIE}.Trinity.fasta

# créer une base de données des séquences de référence de la souris, si elle n'est pas déjà créée #
if [[ ! -e ${REF}.ndb && ! -e ${REF}.nhr && ! -e ${REF}.nin && ! -e ${REF}.not && ! -e ${REF}.nsq && ! -e ${REF}.ntf && ! -e ${REF}.nto ]] ; then
	makeblastdb -in ${REF} -dbtype nucl ;
fi

# creer repertoire pour l'espece
mkdir ${SPECIE}

# y entrer
cd ${SPECIE}

# faire le blast #
blastn -query ${QUERY} -db ${REF} -num_threads $THREADS -evalue 1e-10 -outfmt '6 sseqid qseqid evalue pident length slen qlen qstart qend sstart send mismatch' > blast_exons_vs_contigs_${SPECIE}.txt

#blastn --> n à la fin car nucléotide
### on veut un fichier de sortie avec identifié de la seq ref, de la seq query, e value, ...
####

# donner indications sur le blast #
nb_blast=$(wc -l blast_exons_vs_contigs_${SPECIE}.txt)
nb_exons=$(cut -f2 blast_exons_vs_contigs_${SPECIE}.txt | sort -u | wc -l)
nb_contigs=$(cut -f1 blast_exons_vs_contigs_${SPECIE}.txt | sort -u | wc -l)

echo "espèce : ${SPECIE}"
echo "nombre de blast : $nb_blast"
echo "nombre d'exons ayant blasté : $nb_exons"
echo "nombre de contigs trouvés : $nb_contigs"

# filtrer le blast #
LC_ALL=en_US awk -v longmin=${LONGMIN} '{if ($5>longmin) {print $0}}' blast_exons_vs_contigs_${SPECIE}.txt |\ ### on lui dit qu'on affiche uniquement si notre blast a une longueur supérieur à notre longueur minimal, print $0 = print tout le fichier
LC_ALL=en_US awk -v seuilpident=${PIDENTMIN} '{if ($4>seuilpident) {print $0}}' |\ ### on affiche uniquement si notre %identitié est > 85%
LC_ALL=en_US awk -v seuilpercent=${PERCENTMIN} '{if (($5/$7)>=seuilpercent) {print $0}}' > blast_exons_vs_contigs_filtre_${SPECIE}.txt ### si notre ratio de longueur exon/longueur exon correspondant > 0,5 --> alors on afffiche et on le garde

### donc la on a mis 3 filtres pour savoir ce qu'on va garder
###le / à l'envers permet juste de mettre la commande à la suite à la ligne
##awk est utilisée ici pour filtrer
### -v veut dire qu'on met des arguments

# donner indications sur le blast filtré #
nb_blast_filtre=$(wc -l blast_exons_vs_contigs_filtre_${SPECIE}.txt)
nb_exons_filtre=$(cut -f2 blast_exons_vs_contigs_filtre_${SPECIE}.txt | sort -u | wc -l)
nb_contigs_filtre=$(cut -f1 blast_exons_vs_contigs_filtre_${SPECIE}.txt | sort -u | wc -l)

##on fait comme avant et ca permet de voir à quel point on a épurer nos données

echo "nombre de blast filtre : $nb_blast_filtre"
echo "nombre d'exons ayant blasté filtre : $nb_exons_filtre"
echo "nombre de contigs trouvés filtre : $nb_contigs_filtre"

# créer fichier des noms des exons qui ont blasté
cut -f2 blast_exons_vs_contigs_filtre_${SPECIE}.txt | cut -f2 -d"|" | sort -u > exons_list_blast_${SPECIE}.txt

### on créer un ficier avec tous les identifiants des exons qui ont match
### le second cut on dit que le sep c'est |


# sortir du repertoire de l'espèce
cd ../
