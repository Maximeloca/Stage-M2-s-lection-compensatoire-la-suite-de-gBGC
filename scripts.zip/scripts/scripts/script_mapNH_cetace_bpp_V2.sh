#! /bin/bash

### mapping substitutions ###

# work with bio++ V3 https://biopp.github.io/ 

# we are going to use a mapping method : https://github.com/BioPP/testnh  & https://github.com/BioPP/bppsuite/

####ATTENTION CE SCRIPT A ÉTÉ MODIFIÉ MAIS ÉGALEMENT SUR LA BIGMEM --> SUR LE CHEMIN POUR ALIGN_SEQ_FILE et TREE_FILE


# parametres ###

TRIBE=$1
EXON=$2

# script ###


# Data set

ALIGN_SEQ_FILE="\/bigvol\/maxime\/${TRIBE}\/Aligned_Sequences\/FINAL\/${EXON}"
#va chercher l'alignement
###on met le chemin en mode bizarre car on va les utiliser pour sed et sinon il ne comprend pas



TREE_FILE="\/bigvol\/maxime\/${TRIBE}\/Phylogeny\/exon_tree\/${EXON}_tree.treefile"
#va chercher l'arbre 

# 1 ## Put the name of the data set in the parameter file

# create parameter files for the exon

cp ~/bin/mapNH/bppML.bpp ./bppML_${EXON}.bpp
cp ~/bin/mapNH/mapNH.bpp ./mapNH_${EXON}.bpp

# replace the arguments

sed -i "s/seqname/${ALIGN_SEQ_FILE}/" bppML_${EXON}.bpp
sed -i "s/exonname/${EXON}/" bppML_${EXON}.bpp
sed -i "s/treename/${TREE_FILE}/" bppML_${EXON}.bpp

sed -i "s/seqname/${ALIGN_SEQ_FILE}/" mapNH_${EXON}.bpp
sed -i "s/exonname/${EXON}/" mapNH_${EXON}.bpp

# 2 ## Fit a homogeneous model

~/bin/mapNH/bppML  param=bppML_${EXON}.bpp
###on appelle le script bppML qui est un exécutable et ensuite on lui donne comme paramètre notre fichier .bpp


# 3 ## Run mapNH

~/bin/mapNH/mapnh param=mapNH_${EXON}.bpp


# delete the parameter files

rm bppML_${EXON}.bpp mapNH_${EXON}.bpp
