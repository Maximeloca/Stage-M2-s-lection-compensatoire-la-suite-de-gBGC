## install packages ###
import sys
import pandas as pd
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 5:
    sys.exit("ERROR : need 4 arguments : [1]exon name [2]directory of the tab recap [3]list of paralogs exons [4]tab cds exon")
# recuperer les arguments
exon_name = sys.argv[1] #nom du gène 
tab_recap_dir = sys.argv[2] #tab recap de chaque gène 
paralogs_list_file = sys.argv[3] #liste des paralogues 
tab_exon_cds = sys.argv[4]

## script ###

# get the paralogs list
with open(paralogs_list_file, "r") as file_paralogs_list: #on ouvre la liste des paralogues et on la trasnforme en liste
    file_paralogs_list_read = file_paralogs_list.read().strip()
    paralogs_list = file_paralogs_list_read.split()

exon = exon_name #gene name devient gene 
print(exon)
# read the table
tab_recap_name = tab_recap_dir + "_tab_recap.csv"  
tab_recap_with_paralogs = pd.read_csv(tab_recap_name, sep='\t') #on lit le tableau recap du gène mais il contient encore les paralogues
    
# remove paralogs exons
tab_recap = tab_recap_with_paralogs[~tab_recap_with_paralogs.Exon.isin(paralogs_list)] ###on enlève les paralogues en utilisant le ~

# list exons
exons_list = list(tab_recap['Exon']) #on fait la nouvelle liste d'exons
exons_list = set(exons_list) # equivalent of uniq
exons_list = list(exons_list) # equivalent of uniq
print(exons_list)

# on crée des listes 
gene_list = []
exon_list = []
GC3_list = []
lg_seq_list = []
br_ep_list = []
ep_list = []
nb_WS_ep_list = []
nb_SW_ep_list = []
nb_WS_postep_list = []
nb_SW_postep_list = []

# list branches episodes
tab_recap_ep = tab_recap[(tab_recap['Episode'] == 'YES') & (pd.notna(tab_recap['Br_Asc'])) & (pd.notna(tab_recap['Br_Desc1']))] ###garde les lignes avec épisodes et ayant des branches ascendantes et descendantes 
br_ep = list(tab_recap_ep['Br']) #liste des branches avec épisodes
br_ep = set(br_ep)
br_ep = list(br_ep)
print(br_ep)

tab_exon_cds_df = pd.read_csv(tab_exon_cds, sep='\t')  # Lecture du fichier
gene = tab_exon_cds_df[tab_exon_cds_df['Exon'] == exon]['Gene'].iloc[0]  # Récupération du gène

###
#for exon in exons_list: ###pour les exons de la liste 
# tab exon

tab_exon = tab_recap[tab_recap['Exon'] == exon] #récupère la ligne de l'exon 
# for each br ep get br post ep and infos
for br in br_ep:#pour chaque branche dans la liste des branches épisodes 
    # get br post
    br_post1 = tab_exon[tab_exon['Br'] == br]['Br_Desc1'].iloc[0] #branche descendante 1 de branche ep
    br_post2 = tab_exon[tab_exon['Br'] == br]['Br_Desc2'].iloc[0] #branche descendante 1 de branche ep
    # get infos
    GC3 = tab_exon[tab_exon['Br'] == br]['GC3'].iloc[0] #GC3 de la branche ep
    lg_seq = tab_exon[tab_exon['Br'] == br]['Lg_seq'].iloc[0] #longueur de la branche ep
    ep = tab_exon[tab_exon['Br'] == br]['Episode'].iloc[0] #est ce que on a un épisode sur la branche qu'on regarde dans l'exon
    nb_WS_ep = tab_exon[tab_exon['Br'] == br]['Nb_subst_S_WS'].iloc[0] #nb subst S WS
    nb_SW_ep = tab_exon[tab_exon['Br'] == br]['Nb_subst_S_SW'].iloc[0] #nb subst S SW 
    nb_WS_postep1 = tab_exon[tab_exon['Br'] == br_post1]['Nb_subst_S_WS'].iloc[0] #nb subst S WS branche post ep 1
    nb_WS_postep2 = tab_exon[tab_exon['Br'] == br_post2]['Nb_subst_S_WS'].iloc[0] #nb subst S WS branche post ep 2
    nb_WS_postep = nb_WS_postep1 + nb_WS_postep2 #nb tot subst S WS branche post
    nb_SW_postep1 = tab_exon[tab_exon['Br'] == br_post1]['Nb_subst_S_SW'].iloc[0] #nb subst S SW branche post ep 1
    nb_SW_postep2 = tab_exon[tab_exon['Br'] == br_post2]['Nb_subst_S_SW'].iloc[0] #nb subst S SW branche post ep 2
    nb_SW_postep = nb_SW_postep1 + nb_SW_postep2
    # fill the lists
    gene_list.append(gene)
    exon_list.append(exon)
    GC3_list.append(GC3)
    lg_seq_list.append(lg_seq)
    br_ep_list.append(br)
    ep_list.append(ep)
    nb_WS_ep_list.append(nb_WS_ep)
    nb_SW_ep_list.append(nb_SW_ep)
    nb_WS_postep_list.append(nb_WS_postep)
    nb_SW_postep_list.append(nb_SW_postep)
        
# make the table
tab = pd.DataFrame({'Exon' : exon_list,
		     'GC3' : GC3_list,
		     'Lg_seq' : lg_seq_list,
		     'Br_ep' : br_ep_list,
		     'Episode' : ep_list,
		     'Nb_S_WS_ep' : nb_WS_ep_list,
		     'Nb_S_SW_ep' : nb_SW_ep_list,
		     'Nb_S_WS_postep' : nb_WS_postep_list,
		     'Nb_S_SW_postep' : nb_SW_postep_list})


# save the table
tab.to_csv(exon + '_tab_for_sort_ep.csv', index=False)
