#! /bin/bash

# parametres ##

EXON=$1
TRIBE=$2

# script ##

gene=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | head -1 | cut -f1)
exon_position=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | head -1 | cut -f3)
for specie in $(cat ~/Murinae/${TRIBE}/Data/list_species_${TRIBE}.txt) ; do
if [[ -e  ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${specie}/${gene}_${EXON}_${exon_position}_seq.fasta ]] ; then
	cat ~/Murinae/${TRIBE}/Blast/reciprocal_blast/${specie}/${gene}_${EXON}_${exon_position}_seq.fasta
fi
done > ${gene}_${EXON}_${exon_position}_all_sp_seq.fasta
nb_lignes=$(wc -l < ${gene}_${EXON}_${exon_position}_all_sp_seq.fasta)
if [ ${nb_lignes} == 0 ] ; then
	rm ${gene}_${EXON}_${exon_position}_all_sp_seq.fasta
fi

### on va regrouper toutes les espèces ayant le même exon dans le même fichier 
