from Bio import SeqIO, AlignIO
import os
import sys

if len(sys.argv) != 3:
    sys.exit("ERROR: need 2 arguments: [1]alignment [2]output folder path")

# Récupère les arguments
file = sys.argv[1]  # Fichier d'alignement (par exemple, un fichier FASTA)
out_folder = sys.argv[2]  # Dossier de sortie

# Crée le chemin pour le fichier de sortie
out_file_name = os.path.join(out_folder, "alignment_lengths.csv")

# Charge l'alignement
alignment = AlignIO.read(file, "fasta")  # Ajustez le format selon le type d'alignement, donc on rajoute "fasta"

# Récupère la longueur de l'alignement
align_length = alignment.get_alignment_length()

# Écriture dans le fichier CSV en mode append (ajouter sans écraser)
with open(out_file_name, "a") as out:
    # Vérifie si le fichier est vide pour ajouter les en-têtes
    if os.stat(out_file_name).st_size == 0:
        out.write(f"File\tAlignment_Length\n")  # En-tête
    out.write(f"{file}\t{align_length}\n")  # Données
