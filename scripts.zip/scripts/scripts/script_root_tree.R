#!/usr/bin/env Rscript

## Arguments ###
args = commandArgs(trailingOnly=TRUE) ##les arguments
print(args)

if (length(args)<3) {
  stop("3 arguments must be supplied : [1] input tree (newick format) [2] outgroup, [3] name of the rooted phylogeny", call.=FALSE)
}

tree = args[1] # complete phylogeny
outgroup = args[2] # outgroup
rooted_tree = args[3] # name of the rooted phylogeny

## load packages ###
library(ape)

## script ###

# read the phylogeny
phylo <- read.tree(file = tree)

# root the phylogeny
rooted_phylo <- root(phylo, outgroup = outgroup, resolve.root = T) # regarder ce que veut dire resolve.root 
#resolve.root = a logical specifying whether to resolve the new root as a bifurcating node.
# resolve.root = T -->La racine sera forcée à être bifurcante (avoir exactement deux descendants)

# save this rooted phylogeny
ape::write.tree(rooted_phylo, file=rooted_tree)
