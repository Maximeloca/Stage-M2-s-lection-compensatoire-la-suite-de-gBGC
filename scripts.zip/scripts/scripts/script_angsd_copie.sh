#! /bin/bash

# parametres ##

SPECIE=$1
TRIBE=$2

# script ##
### ESSAYER DE MODIFIER CE SCRIPT VU QU'ON A QU'UN SEUL INDIVIDU PAR ESP



mkdir ${SPECIE}

cd ${SPECIE}


for EXON in $(cat ~/Murinae/${TRIBE}/Sequences/Exons_list.txt) ; do ### boucle sur exon

	CONTIG=$(grep "${EXON}" ~/Murinae/${TRIBE}/Heterozygosity/contigs_lists/contigs_list_${SPECIE}.txt | cut -f2) ###on récupère le nom du contig associé à l'exon
###ATTENTION NON SEULEMENT J'AI ENLEVÉ LA BOUCLE MAIS J'AI AUSSI CHANGÉ LE CHEMIN DU FICHIER BAM.BAM EN RAJOUTANT LE RÉPERTOIRE SPECIE QUI N'ÉTAIT PAS SPÉCIFIÉ
	INDIV=$(grep ${SPECIE} ~/Murinae/${TRIBE}/Data/recap_sequencing_${TRIBE}.csv | cut -f2 -d',')
		mkdir ${INDIV}
		cd ${INDIV}
		~/scripts/script_heterozygosity.sh ~/Murinae/${TRIBE}/Mapping/${SPECIE}/${INDIV}_bwa_sorted_bam.bam ~/Murinae/${TRIBE}/Assembly/trinity_OUT_${SPECIE}.Trinity.fasta ${CONTIG}
		heterozygotie=$(cat heterozygosity.txt) ##on lui donne le fichier du mapping, le fichier fasta contenant tous les contigs de l'esp, l'ide du contig
  ### heterozygotie=$(cat heterozygosity.txt) --> on va récupérer la velur d'hétérozygotie qu'on a trouvé dans le script eterozygotie
		#echo -e "${EXON}\t${SPECIE}\t${INDIV}\t${heterozygotie}"
        echo -e "${EXON}\t${SPECIE}\t${heterozygotie}"

		cd ..
done >> tab_heterozygotie_${SPECIE}.csv
#	done >> tab_heterozygotie_${EXON}_${SPECIE}.csv
	#mean_het=$(awk '{ sum += $4 } END { print (sum / NR)}' tab_heterozygotie_${EXON}_${SPECIE}.csv) ###ici on fait une moyenne mais pas besoin de faire uene moyenne car on a qu'un seul #individu, on lui demande d'abord de faire la somme de la colonne 4 et ensuite NR correspond au total
#	rm tab_heterozygotie_${EXON}_${SPECIE}.csv
#	echo -e "${EXON}\t${SPECIE}\t${mean_het}" ### peut être qu'on peut récupérer juste ce qui nous intéresse et essayer de simplifier le script puisqu'on à qu'un seul indeividu par esp

#done >> tab_heterozygotie_${SPECIE}.csv
cd ..

