#! /bin/bash

# parametres ##

EXON=$1
TRIBE=$2

# script ##

GENE=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f1)
POS=$(grep -w ${EXON} ~/Murinae/Reference_exons/Gene_exons_ref_list.txt | cut -f3)

python3 ~/scripts/remove_seq_with_stop_codon_V2.py $EXON ~/Murinae/${TRIBE}/Aligned_Sequences/${GENE}_${EXON}_${POS}_all_sp_seq_align/${GENE}_${EXON}_${POS}_final_mask_align_AA.aln ~/Murinae/${TRIBE}/Aligned_Sequences/alignments/alignments_wt_ref/alignments_wt_ref_filtered/${GENE}_${EXON}_${POS}_final_align_NT_wt_ref_filtered.fasta ${GENE}_${EXON}_${POS}_final_align_NT_wt_ref_filtered_wt_stop.fasta ${EXON}_seq_with_stop.csv
