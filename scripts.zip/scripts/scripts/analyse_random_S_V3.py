## install packages ###
import sys
import pandas as pd
import numpy as np

# message d'erreur si pas le bon nombre d'arguments
if len(sys.argv) != 5:
    sys.exit("ERROR : need 4 arguments : [1]gene name [2]directory of the tab recap [3]directory of the tab random S [4]list of paralogs exons")
# recuperer les arguments
gene_name = sys.argv[1]
tab_recap_dir = sys.argv[2]
tab_randomS_dir = sys.argv[3]
paralogs_list_file = sys.argv[4]

## script ###

# get the paralogs list
with open(paralogs_list_file, "r") as file_paralogs_list:
    file_paralogs_list_read = file_paralogs_list.read().strip()
    paralogs_list = file_paralogs_list_read.split()

gene = gene_name
print(gene)
# read the table
tab_recap_name = tab_recap_dir + gene + "_tab_recap.csv"
tab_recap_with_paralogs = pd.read_csv(tab_recap_name, sep='\t')
    
# remove paralogs exons
tab_recap = tab_recap_with_paralogs[~tab_recap_with_paralogs.Exon.isin(paralogs_list)]

# list of exons
exons_list = list(tab_recap['Exon'])
exons_list = set(exons_list) # equivalent of uniq
exons_list = list(exons_list) # equivalent of uniq
print(exons_list)
    
exons_post_ep = []

exons_otherex_durep = []
otherex_otherex_durep = []

for exon in exons_list:
    print(exon)
    
    ##### S after the episodes #####
    
    # list of branches with episodes
    tab_exon = tab_recap[tab_recap['Exon'] == exon]
    tab_exon_ep = tab_exon[(tab_exon['Episode'] == 'YES') & (pd.notna(tab_exon['Br_Asc'])) & (pd.notna(tab_exon['Br_Desc1']))]
    br_ep = list(tab_exon_ep['Br'])
    print(br_ep)   
            
    # list of the branches after the episodes & no episode in these branches
    br_postep = []
    for br in br_ep:
        br_desc1 = tab_exon[tab_exon['Br'] == br]['Br_Desc1'].iloc[0]
        br_desc2 = tab_exon[tab_exon['Br'] == br]['Br_Desc2'].iloc[0]
        br_postep.append(br_desc1)
        br_postep.append(br_desc2)
    print(br_postep)
    if br_postep:
        exons_post_ep.append(exon)
        # tab of br asc (=br_ep)
        br_post_list = []
        br_asc_list = []
        for br in br_postep:
            br_post_list.append(br)
            br_asc = tab_exon[tab_exon['Br'] == br]['Br_Asc'].iloc[0]
            br_asc_list.append(br_asc)
        tab_br_asc = pd.DataFrame({'Br': br_post_list,
        			      'Br_asc' : br_asc_list})
        # tab of exon with theses branches
        tab_exon_postep = tab_exon[tab_exon['Br'].isin(br_postep)]
        # observed nb of subst NS WS after the episodes
        tab_nb_obs_S_WS_after_ep = tab_exon_postep[['Exon', 'dNdS',  'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
        # observed nb of subst NS SW after the episodes
        tab_nb_obs_S_SW_after_ep = tab_exon_postep[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_SW', 'Nb_subst_NS_WS']]
        # observed nb of subst NS SS after the episodes
        tab_nb_obs_S_SS_after_ep = tab_exon_postep[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_SS', 'Nb_subst_NS_WS']]
        # observed nb of subst NS WW after the episodes
        tab_nb_obs_S_WW_after_ep = tab_exon_postep[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Episode', 'Nb_subst_S_WW', 'Nb_subst_NS_WS']]
        # expected nb of subst NS WS after the episodes
        tab_randomS_WS_exon_name = tab_randomS_dir + exon + "_simul_distrib_subst_WS_S.csv"
        tab_randomS_WS_exon = pd.read_csv(tab_randomS_WS_exon_name, sep=',')
        tab_randomS_WS_exon_brpostep = tab_randomS_WS_exon[tab_randomS_WS_exon['branches'].isin(br_postep)]
        tab_randomS_WS_exon_brpostep = tab_randomS_WS_exon_brpostep.rename(columns={'branches': 'Br'})
        # expected nb of subst NS SW after the episodes
        tab_randomS_SW_exon_name = tab_randomS_dir + exon + "_simul_distrib_subst_SW_S.csv"
        tab_randomS_SW_exon = pd.read_csv(tab_randomS_SW_exon_name, sep=',')
        tab_randomS_SW_exon_brpostep = tab_randomS_SW_exon[tab_randomS_SW_exon['branches'].isin(br_postep)]
        tab_randomS_SW_exon_brpostep = tab_randomS_SW_exon_brpostep.rename(columns={'branches': 'Br'})
        # expected nb of subst NS SS after the episodes
        tab_randomS_SS_exon_name = tab_randomS_dir + exon + "_simul_distrib_subst_SS_S.csv"
        tab_randomS_SS_exon = pd.read_csv(tab_randomS_SS_exon_name, sep=',')
        tab_randomS_SS_exon_brpostep = tab_randomS_SS_exon[tab_randomS_SS_exon['branches'].isin(br_postep)]
        tab_randomS_SS_exon_brpostep = tab_randomS_SS_exon_brpostep.rename(columns={'branches': 'Br'})
        # expected nb of subst NS WW after the episodes
        tab_randomS_WW_exon_name = tab_randomS_dir + exon + "_simul_distrib_subst_WW_S.csv"
        tab_randomS_WW_exon = pd.read_csv(tab_randomS_WW_exon_name, sep=',')
        tab_randomS_WW_exon_brpostep = tab_randomS_WW_exon[tab_randomS_WW_exon['branches'].isin(br_postep)]
        tab_randomS_WW_exon_brpostep = tab_randomS_WW_exon_brpostep.rename(columns={'branches': 'Br'})
        # final tables for S after ep
        if exon == exons_post_ep[0]:
            # WS
            tab_S_WS_after_ep = pd.merge(tab_nb_obs_S_WS_after_ep, tab_randomS_WS_exon_brpostep, how='left', on='Br')
            tab_S_WS_after_ep = pd.merge(tab_S_WS_after_ep, tab_br_asc, how='left', on='Br')
            # SW
            tab_S_SW_after_ep = pd.merge(tab_nb_obs_S_SW_after_ep, tab_randomS_SW_exon_brpostep, how='left', on='Br')
            tab_S_SW_after_ep = pd.merge(tab_S_SW_after_ep, tab_br_asc, how='left', on='Br')
            # SS
            tab_S_SS_after_ep = pd.merge(tab_nb_obs_S_SS_after_ep, tab_randomS_SS_exon_brpostep, how='left', on='Br')
            tab_S_SS_after_ep = pd.merge(tab_S_SS_after_ep, tab_br_asc, how='left', on='Br')
            # WW
            tab_S_WW_after_ep = pd.merge(tab_nb_obs_S_WW_after_ep, tab_randomS_WW_exon_brpostep, how='left', on='Br')
            tab_S_WW_after_ep = pd.merge(tab_S_WW_after_ep, tab_br_asc, how='left', on='Br')
        else:
            # WS
            tab_exon_S_WS_after_ep = pd.merge(tab_nb_obs_S_WS_after_ep, tab_randomS_WS_exon_brpostep, how='left', on='Br')
            tab_exon_S_WS_after_ep = pd.merge(tab_exon_S_WS_after_ep, tab_br_asc, how='left', on='Br')
            tab_S_WS_after_ep = pd.concat([tab_S_WS_after_ep, tab_exon_S_WS_after_ep])
            # SW
            tab_exon_S_SW_after_ep = pd.merge(tab_nb_obs_S_SW_after_ep, tab_randomS_SW_exon_brpostep, how='left', on='Br')
            tab_exon_S_SW_after_ep = pd.merge(tab_exon_S_SW_after_ep, tab_br_asc, how='left', on='Br')
            tab_S_SW_after_ep = pd.concat([tab_S_SW_after_ep, tab_exon_S_SW_after_ep])
            # SS
            tab_exon_S_SS_after_ep = pd.merge(tab_nb_obs_S_SS_after_ep, tab_randomS_SS_exon_brpostep, how='left', on='Br')
            tab_exon_S_SS_after_ep = pd.merge(tab_exon_S_SS_after_ep, tab_br_asc, how='left', on='Br')
            tab_S_SS_after_ep = pd.concat([tab_S_SS_after_ep, tab_exon_S_SS_after_ep])
            # WW
            tab_exon_S_WW_after_ep = pd.merge(tab_nb_obs_S_WW_after_ep, tab_randomS_WW_exon_brpostep, how='left', on='Br')
            tab_exon_S_WW_after_ep = pd.merge(tab_exon_S_WW_after_ep, tab_br_asc, how='left', on='Br')
            tab_S_WW_after_ep = pd.concat([tab_S_WW_after_ep, tab_exon_S_WW_after_ep])
            
            
    ##### S during episodes in other exons of the same gene #####
    
    # list other exons of the same gene
    other_exons_list = list(exons_list)
    other_exons_list.remove(exon)
    
    for other_exon in other_exons_list:
        tab_other_exon = tab_recap[tab_recap['Exon'] == other_exon]
        br_ep_otherex = []
        #
        for br in br_ep:
            if tab_other_exon[tab_other_exon['Br'] == br]['Episode'].iloc[0] != 'YES':
                br_ep_otherex.append(br)
        print(br_ep_otherex)
        if br_ep_otherex:
            exons_otherex_durep.append(exon)
            otherex_otherex_durep.append(other_exon)
            # take exon ep name
            exon_ep_list = []
            br_ep_list = []
            for br in br_ep_otherex:
                br_ep_list.append(br)
                exon_ep_list.append(exon)
            tab_ex_ep = pd.DataFrame({'Br': br_ep_list,
            				'Exon_ep' : exon_ep_list})
            # take branches
            tab_otherex_during_ep = tab_other_exon[tab_other_exon['Br'].isin(br_ep_otherex)]
            # observed
            tab_nb_obs_S_WS_during_ep_otherex = tab_otherex_during_ep[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WS', 'Nb_subst_NS_WS']]
            tab_nb_obs_S_SW_during_ep_otherex = tab_otherex_during_ep[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_SW', 'Nb_subst_NS_WS']]
            tab_nb_obs_S_SS_during_ep_otherex = tab_otherex_during_ep[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_SS', 'Nb_subst_NS_WS']]
            tab_nb_obs_S_WW_during_ep_otherex = tab_otherex_during_ep[['Exon', 'dNdS', 'Lg_seq', 'GC12', 'GC3', 'Br', 'Br_lg', 'Nb_subst_S_WW', 'Nb_subst_NS_WS']]
            # expected
            # WS
            tab_randomS_WS_otherexon_name = tab_randomS_dir + other_exon + "_simul_distrib_subst_WS_S.csv"
            tab_randomS_WS_otherexon = pd.read_csv(tab_randomS_WS_otherexon_name, sep=',')
            tab_randomS_WS_during_ep_otherex = tab_randomS_WS_otherexon[tab_randomS_WS_otherexon['branches'].isin(br_ep_otherex)]
            tab_randomS_WS_during_ep_otherex = tab_randomS_WS_during_ep_otherex.rename(columns={'branches': 'Br'})
            # SW
            tab_randomS_SW_otherexon_name = tab_randomS_dir + other_exon + "_simul_distrib_subst_SW_S.csv"
            tab_randomS_SW_otherexon = pd.read_csv(tab_randomS_SW_otherexon_name, sep=',')
            tab_randomS_SW_during_ep_otherex = tab_randomS_SW_otherexon[tab_randomS_SW_otherexon['branches'].isin(br_ep_otherex)]
            tab_randomS_SW_during_ep_otherex = tab_randomS_SW_during_ep_otherex.rename(columns={'branches': 'Br'})
            # SS
            tab_randomS_SS_otherexon_name = tab_randomS_dir + other_exon + "_simul_distrib_subst_SS_S.csv"
            tab_randomS_SS_otherexon = pd.read_csv(tab_randomS_SS_otherexon_name, sep=',')
            tab_randomS_SS_during_ep_otherex = tab_randomS_SS_otherexon[tab_randomS_SS_otherexon['branches'].isin(br_ep_otherex)]
            tab_randomS_SS_during_ep_otherex = tab_randomS_SS_during_ep_otherex.rename(columns={'branches': 'Br'})
            # WW
            tab_randomS_WW_otherexon_name = tab_randomS_dir + other_exon + "_simul_distrib_subst_WW_S.csv"
            tab_randomS_WW_otherexon = pd.read_csv(tab_randomS_WW_otherexon_name, sep=',')
            tab_randomS_WW_during_ep_otherex = tab_randomS_WW_otherexon[tab_randomS_WW_otherexon['branches'].isin(br_ep_otherex)]
            tab_randomS_WW_during_ep_otherex = tab_randomS_WW_during_ep_otherex.rename(columns={'branches': 'Br'})
            # final tables for S after ep
            if exon == exons_otherex_durep[0] and other_exon == otherex_otherex_durep[0]:
                # WS
                tab_S_WS_during_ep_otherexons = pd.merge(tab_nb_obs_S_WS_during_ep_otherex, tab_randomS_WS_during_ep_otherex, how='left', on='Br')
                tab_S_WS_during_ep_otherexons = pd.merge(tab_S_WS_during_ep_otherexons, tab_ex_ep, how='left', on='Br')
                # SW
                tab_S_SW_during_ep_otherexons = pd.merge(tab_nb_obs_S_SW_during_ep_otherex, tab_randomS_SW_during_ep_otherex, how='left', on='Br')
                tab_S_SW_during_ep_otherexons = pd.merge(tab_S_SW_during_ep_otherexons, tab_ex_ep, how='left', on='Br')
                # SS
                tab_S_SS_during_ep_otherexons = pd.merge(tab_nb_obs_S_SS_during_ep_otherex, tab_randomS_SS_during_ep_otherex, how='left', on='Br')
                tab_S_SS_during_ep_otherexons = pd.merge(tab_S_SS_during_ep_otherexons, tab_ex_ep, how='left', on='Br')
                # WW
                tab_S_WW_during_ep_otherexons = pd.merge(tab_nb_obs_S_WW_during_ep_otherex, tab_randomS_WW_during_ep_otherex, how='left', on='Br')
                tab_S_WW_during_ep_otherexons = pd.merge(tab_S_WW_during_ep_otherexons, tab_ex_ep, how='left', on='Br')
            else:
                # WS 
                tab_exon_S_WS_during_ep_otherexons = pd.merge(tab_nb_obs_S_WS_during_ep_otherex, tab_randomS_WS_during_ep_otherex, how='left', on='Br')
                tab_exon_S_WS_during_ep_otherexons = pd.merge(tab_exon_S_WS_during_ep_otherexons, tab_ex_ep, how='left', on='Br')
                tab_S_WS_during_ep_otherexons = pd.concat([tab_S_WS_during_ep_otherexons, tab_exon_S_WS_during_ep_otherexons])
                # SW 
                tab_exon_S_SW_during_ep_otherexons = pd.merge(tab_nb_obs_S_SW_during_ep_otherex, tab_randomS_SW_during_ep_otherex, how='left', on='Br')
                tab_exon_S_SW_during_ep_otherexons = pd.merge(tab_exon_S_SW_during_ep_otherexons, tab_ex_ep, how='left', on='Br')
                tab_S_SW_during_ep_otherexons = pd.concat([tab_S_SW_during_ep_otherexons, tab_exon_S_SW_during_ep_otherexons])
                # SS 
                tab_exon_S_SS_during_ep_otherexons = pd.merge(tab_nb_obs_S_SS_during_ep_otherex, tab_randomS_SS_during_ep_otherex, how='left', on='Br')
                tab_exon_S_SS_during_ep_otherexons = pd.merge(tab_exon_S_SS_during_ep_otherexons, tab_ex_ep, how='left', on='Br')
                tab_S_SS_during_ep_otherexons = pd.concat([tab_S_SS_during_ep_otherexons, tab_exon_S_SS_during_ep_otherexons])
                # WW
                tab_exon_S_WW_during_ep_otherexons = pd.merge(tab_nb_obs_S_WW_during_ep_otherex, tab_randomS_WW_during_ep_otherex, how='left', on='Br')
                tab_exon_S_WW_during_ep_otherexons = pd.merge(tab_exon_S_WW_during_ep_otherexons, tab_ex_ep, how='left', on='Br')
                tab_S_WW_during_ep_otherexons = pd.concat([tab_S_WW_during_ep_otherexons, tab_exon_S_WW_during_ep_otherexons])
            
            

if exons_post_ep:
    tab_S_WS_after_ep.to_csv(gene + '_tab_S_WS_after_ep.csv', index=False)
    tab_S_SW_after_ep.to_csv(gene + '_tab_S_SW_after_ep.csv', index=False)
    tab_S_SS_after_ep.to_csv(gene + '_tab_S_SS_after_ep.csv', index=False)
    tab_S_WW_after_ep.to_csv(gene + '_tab_S_WW_after_ep.csv', index=False)
    
if exons_otherex_durep:
    tab_S_WS_during_ep_otherexons.to_csv(gene + '_tab_S_WS_during_ep_otherexons.csv', index=False)
    tab_S_SW_during_ep_otherexons.to_csv(gene + '_tab_S_SW_during_ep_otherexons.csv', index=False)
    tab_S_SS_during_ep_otherexons.to_csv(gene + '_tab_S_SS_during_ep_otherexons.csv', index=False)
    tab_S_WW_during_ep_otherexons.to_csv(gene + '_tab_S_WW_during_ep_otherexons.csv', index=False)

            
