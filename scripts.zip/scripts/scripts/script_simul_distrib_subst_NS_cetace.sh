#! /bin/bash

# Arguments ###

EXON=$1
TRIBE=$2
NB_SIMUL=$3

# Script ###


#if [[ ! -e Br_lg_tables/${GENE}_br_len.csv ]] ;then
#cd Br_lg_tables ;
#~/bin/num_br_lg/tpn ~/Murinae/${TRIBE}/Phylogeny/gene_tree/${GENE}_tree.treefile ${GENE}_br_len.csv ;
#cd .. ;
#fi


echo -e "exon : $EXON"
echo -e "nb simul : $NB_SIMUL"

#cd distrib_NS
python3 ~/scripts/simul_distrib_subst_NS_V2.py ~/${TRIBE}/Detecting_gBGC/Detection/episodes/${EXON}_episodes_detection.csv ~/${TRIBE}/Impact_episodes_NS/${EXON}_stat_nb_subst_NS.csv ~/${TRIBE}/Randomisations/Br_lg_tables/${EXON}_br_len.csv $EXON $NB_SIMUL
#cd ..
